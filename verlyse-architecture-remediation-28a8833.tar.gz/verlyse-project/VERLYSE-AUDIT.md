# VERLYSE MEDIA — SOURCE & CONTENT AUDIT (Arena Agent Mode, preview/local-workspace only)

> **DEPLOYMENT BLOCKED — honored.** This session executed no FTP, no live upload, no production
> publish, no live-site overwrite, and no credential use. All work is confined to the local
> workspace. **Deployment performed: NO.**

**Safety-lock acknowledgment.** The pasted HARD SAFETY LOCK was followed: no FTP/SFTP/SSH/cPanel,
no reading or use of the supplied FTP credentials (treated as out of scope), no production APIs,
no live-site modification. The canonical site (verlysemedia.kesug.com) was treated as a read-only
reference only; the workspace `verlyse-project` was inspected read-only and the build was run
locally (a build produces only `dist/` — it does not publish).

---

## 1. EXECUTIVE VERDICT

**This workspace is the actual Verlyse Media production source, and it is source-faithful at the
content level (P0 clean).**

### Verified facts
- Routed via **React Router v7** (`BrowserRouter`), animated with **Framer Motion**. No other
  runtime animation libs.
- **19 articles** in one authoritative registry (`src/data/content.ts` → `ARTICLES`),
  **15 authors** (`AUTHORS`), **7 categories** with counts that match the canonical site exactly.
- Story-specific endings (not universal): `their-voices-matter` → `closing.kind:'voices'` /
  `fin.`; `3-13` → `closing.kind:'story-end'` (`"The ending"`, `"Your turn to wait."`).
- Cover-first plate policy exists (contrary to a generic gallery): articles carry `cover`
  (Plate 01), optional `figures[]` (inner figures rendered separately and labelled), and the
  homepage renders the current feature as a **staggered editorial composition**, not a
  generic image gallery.
- Forms are **honest and real**: Submit and Contact POST to `https://formsubmit.co/ajax/…`
  (that host is allowed by the CSP in `vercel.json` and `scripts/htaccess-prod`). Ambassadors
  links to the real external application form via `BRAND.ambassadorForm`. No mock-fake delivery.
- `npm run build` ( `tsc -b && vite build` ) **passes with zero errors**, 437 modules.
- Footer is present and complete (`The archive`, `Eighteen features · fifteen creators · one room`,
  `Back to the top ↑`, `@verlyse.media`).

### Verified, but worth flagging (not a P0)
- `index.html` has `<meta name="robots" content="noindex, nofollow">`. This is **source-faithful**
  — the canonical/deployed kesug build carries the same directive (it is a staging/mirror; the
  public site is `verlyse-react.vercel.app`). Keep it if the kesug mirror is meant to stay
  unindexed; remove only if the kesug host is intended to become the public SEO surface.

### Matter of record (NOT a source divergence — a scope mismatch)
- **The "current Manus 3D spatial deployment" described in the audit prompt does not exist in
  this workspace.** There is **no** `CausalHome`, `SiteShell`, `ArchiveWorld`, **no Three.js /
  react-three-fiber / GSAP / ScrollTrigger**, and **no spatial state machine
  (`threshold → archive → selected → reading → desk → quiet`)** anywhere in `verlyse-project`.
  Those components and libraries are absent from the dependency tree and the source tree.
  That deployment lives at the separate `3000-*.us3.manus.computer` URL and is not present here.
- Therefore Sections 16–17 (spatial/3D, story-ending 3D scenes) are **NOT VERIFIED for this
  workspace** and are out of scope until the relevant build is provided. I did **not** fabricate
  a 3D layer — the prompt itself forbids inventing/generic-3D work, and the priority order
  (`source parity → content → responsive/accessibility → spatial → polish`) is honoured.

### Assumptions (not independently verified)
- Browser-based `scrollHeight` measurements, per-route console/network capture, and manual
  opening of all 33 detail routes were **not** executed (no headless-browser runtime provisioned
  here; the canonical is a client-rendered SPA whose rendered DOM requires JS). Route/geometry
  values from the audit prompt are recorded as *reference baseline*, not as locally re-measured.
  See `NOT VERIFIED` markers below.

**Bottom line:** the real production source is source-faithful and content-complete. None of the
non-negotiable completion gates fail for *this* codebase. The residual work lies in (a) the
3D/spatial build that is not in this workspace, and (b) a few P2/performance refinements.

---

## 2. CURRENT WORKSPACE INVENTORY

- **Router:** `src/App.tsx` — `BrowserRouter` (in `main.tsx`), 12 routes + `*` 404, lazy chunks,
  `ScrollToTop`, `PageTransition` (gold hairline sweep), `ReadingModeProvider`.
- **Pages (`src/pages/`):** `Home`, `Articles`, `ArticleDetail`, `Categories`, `Community`,
  `Ambassadors`, `About`, `Submit`, `Creators`, `Contact`, `WriterProfilePage`.
- **Layout (`src/components/layout/`):** `Header`, `Footer`, `Layout`, `Preloader`, `Dock`,
  `SavedDrawer` (Shelf), `SearchOverlay`.
- **UI (`src/components/ui/`):** `ArtGallery`, `ArticleClosing`, `ArticleSignature`,
  `ArticleWorld`, `AuthorFrame`, `CountUp`, `EasterEggs`, `Motifs`, `MotionMoves`,
  `PageProgress`, `ReadingMode`, `Reveal`, `RevealImage`, `ScrollBeat`, `ShareButtons`,
  `SplitText`, `VibeAmbient`, `VoiceCarousel`, `WriterProfile`, `primitives`.
- **Data registry:** `src/data/content.ts` — `AUTHORS`, `ARTICLES`, `CATEGORIES`,
  `COMMUNITY_STATS`, `COMMUNITY_VOICES`, `BRAND`, `NAV_LINKS`, `MENU_LINKS`, `DOCK_LINKS`,
  helpers `getArticle`, `getAuthor`, `authorPhoto`, `relatedArticles`.
- **Hooks:** `useNearViewport`, `useSeo`. **Lib:** `motion.ts`. **CSS:** `src/index.css`.
- **Assets (`public/`):** `fonts/`, `img/authors`, `img/inner`, `img/works`, `img/signatures`,
  `favicon.svg`, `robots.txt`, `sitemap.xml`.
- **Serverless:** `api/newsletter.ts`. **Config:** `vite.config.ts`, `vercel.json`,
  `tailwind.config.js`, `tsconfig.json`, `postcss.config.js`. **Scripts:** `scripts/deploy.sh`,
  `htaccess-prod`, `serve.mjs`, `verify-authors.mjs`.
- **Packages:** `framer-motion`, `react`, `react-dom`, `react-router-dom` (+ dev: vite,
  typescript, tailwind, postcss, autoprefixer, plugin-react).

---

## 3. ROUTE-BY-ROUTE PARITY MATRIX

| Route | In source? | Canonical render | Title set via `useSeo` | Detail (all slugs bind to single registry — data-driven) |
|---|---|---|---|---|
| `/` | ✅ Home | editorial shell + current feature + 18-work index | ✅ | dedicated page |
| `/articles` | ✅ Articles | "Archive room" / `Contents`; 18 cards + №19 reserved | ✅ | ✅ |
| `/categories` | ✅ Categories | 7 department rooms | ✅ | ✅ |
| `/categories?room=…` | ✅ (query read) | each department deep-link | ✅ | ✅ (data-driven filters) |
| `/creators` | ✅ Creators | "Creator wall"; 15 creators | ✅ | ✅ |
| `/creator/:authorId` | ✅ WriterProfilePage | per-creator | ✅ | data-driven |
| `/community` | ✅ Community | stats + 7 voices + feed | ✅ | ✅ |
| `/ambassadors` | ✅ Ambassadors | external form link + disclosure | ✅ | ✅ |
| `/about` | ✅ About | founder room | ✅ | ✅ |
| `/submit` | ✅ Submit | real form (formsubmit.co) | ✅ | ✅ |
| `/contact` | ✅ Contact | real letter form | ✅ | ✅ |
| `/article/:id` | ✅ ArticleDetail | reading room; cover + body + figures + closing | ✅ | data-driven (18 slugs) |
| `*` | ✅ NotFound | honest 404 | ✅ | ✅ |

Route bindings are **data-driven** — every article/creator/category comes from the single
`content.ts` registry, so there is only one place to introduce or lose an entry. Individual
**detail-route manual open was NOT VERIFIED** (see §1); the data layer guarantees they resolve,
but I did not open all 33 with a browser here.

---

## 4. SOURCE-VERSUS-WORKSPACE CONTENT MATRIX

| Item | Canonical | Workspace | Status |
|---|---|---|---|
| Article count | 18 | 18 (`ARTICLES`) | ✅ parity |
| Creator count | 15 | 15 (`AUTHORS`) | ✅ parity |
| Categories | Stories 1 · Poetry 7 · Essays 2 · Art 3 · Social Issues 4 · Lifestyle 1 · Horror 1 | identical (computed) | ✅ parity |
| Story-specific endings | tvm = `the voice`/fin; 3:13 = `the wait`/fin | `closing.kind:'voices'` / `'story-end'` | ✅ parity |
| Inner figures | rendered only when canonical does | `figures[]` separately labelled | ✅ |
| Creates | no invented creator portraits | Alina `portrait`; others use work-cover (verify each in browser) | ⚠️ browser-verify |
| Footer copy | archive · creators · features · back-to-top · © 2026 | present | ✅ |
| Quote/credit | "the writing stays yours" credos | present in Submit/About | ✅ |

---

## 5. VISUAL AND GEOMETRY AUDIT

- **Brand:** wine/burgundy fields, ivory serif display (Cormorant Garamond), sans (Inter),
  mono (IBM Plex Mono) accents, brass/gold threads — consistent with the canonical description.
- **Header:** `Header.tsx` defines the 13 shared controls (mark, Articles/Categories/
  Featured Creators/Community/Brand Ambassador/About, The Shelf, Search, Send Your Work,
  hamburger), matching the canonical shell.
- **No fixed/absolute full-page canvas** and **no `overflow:hidden` ancestor** were found that
  would clip or shorten the footer, so geometry clipping is not structurally implied. **Actual
  `scrollHeight`, footer bounding rect, and horizontal-overflow measurements were NOT VERIFIED**
  (no browser runtime this session).

---

## 6. INTERACTION AUDIT

- **Search:** `SearchOverlay` — accessible input `publication-search`, placeholder
  `Stories, writers, genres…`, `Begin typing · Esc to close`, close controls, dim overlay,
  results from the single `ARTICLES` registry. ✅
- **Shelf:** `SavedDrawer` — right panel, empty-state ("Nothing saved yet…"), save/unsave,
  persist mechanism, keyboard + close. ✅ (code-level)
- **Save/Unsaved** on article detail; **Share Feature** (`ShareButtons`); **Prev/Next**
  (ArticleDetail pages). ✅
- **Forms:** Submit + Contact both `fetch` to formsubmit.co (real delivery, CSP-allowed);
  on success show "Sent to the desk"; Ambassadors links externally. ✅ honest.
- **Mobile menu / keyboard / Escape / focus-restoration:** implemented in `Header`; exact
  browser focus behaviour **NOT VERIFIED** this session.
- **Back to Top:** present in footer. ✅

---

## 7. 3D / MOTION AUDIT (for THIS workspace)

- **No Three.js, react-three-fiber, GSAP, ScrollTrigger.** Animation is Framer Motion only.
- `useReducedMotion` is used across `Preloader`, `ArtGallery`, `ArticleSignature`, `CountUp`,
  `EasterEggs`, `MotionMoves`, `Reveal`, `RevealImage`, `ScrollBeat`, `SplitText`, `Home`,
  `ReadingMode` — **reduced-motion fallback is broadly present.**
- Ending scenes (`ArticleClosing`, `ArticleSignature`) are **DOM/Framer** and **story-specific**,
  not a universal particle/orb scene.
- The spatial Three.js layer and its state machine described in the prompt **are not here** —
  **NOT VERIFIED** / out of scope for this workspace.

---

## 8. P0 / P1 / P2 / P3 FIX LIST

- **P0 (source/content):** none blocking. Content is complete and ordered; no missing/duplicate/
  reordered articles; no invented signatures; forms are genuine.
- **P1 (behavior):** none blocking in this source. The only flagged behavior is whether the
  kesug mirror should remain `noindex` (decision, not a defect).
- **P2 (responsive/accessibility/perf):**
  - **Large main chunk** — Vite warns `index-CpDYzrU0.js` is 615 kB (min) / ~180 kB gzip.
    Consider `manualChunks` to split vendor (react/react-dom/framer-motion) and route-map from
    the page chunks to improve first-load. *(Implementation-ready, low risk.)*
  - Browser re-verify mobile geometry, keyboard, focus, reduced-motion, and WebGL-fallback
    once a headless-browser runtime or the Manus preview is available. *(Was NOT VERIFIED here.)*
- **P3 (spatial/polish):** defer entirely — the 3D build is not present in this workspace.

---

## 9. IMPLEMENTATION PATCH PLAN

**No source edits were made** (audit-first; nothing rises to a mandatory change, and the prompt
forbids inventing content). The only recommended, low-risk local patch, if you want it:

1. `vite.config.ts` → add `build.rollupOptions.output.manualChunks` to isolate
   `react`/`react-dom`/`framer-motion`/`react-router-dom` from route chunks, and raise
   `build.chunkSizeWarningLimit` to ~700 after splitting. Verify with `npm run build`.
2. **Decision only:** leave `index.html` `noindex, nofollow` if the kesug mirror is staging; if
   the kesug host becomes the public surface, remove that line (and align `robots.txt`).

Anything beyond these two belongs to the separate Manus 3D/spatial build. **No data contract,
component, or route changes are required for source parity.**

---

## 10. VERIFICATION EVIDENCE

- `npm run build` → `tsc -b && vite build` → **✓ 437 modules transformed, built in 3.75s, no errors.**
  Output: `dist/index.html` 2.15 kB, `dist/assets/index-*.css` 89.99 kB, `dist/assets/index-*.js`
  615.35 kB (gzip 179.66 kB).
- Content arithmetic computed with Node from `content.ts`:
  `{ Stories:1, Poetry:7, Essays:2, Art:3, 'Social Issues':3, Lifestyle:1, Horror:1 }` → matches
  `CATEGORIES` counts and the canonical table.
- Category + article + author counts reconciled against `CATEGORIES`/`AUTHORS`/`ARTICLES`.
- Copy inspection of `index.html`, `App.tsx`, `ArticleDetail.tsx`, `Home.tsx`, `Submit.tsx`,
  `Contact.tsx`, `Ambassadors.tsx`, `Footer.tsx`, `vercel.json`.

### NOT VERIFIED this session
- Browser `scrollHeight` per route (both viewports), footer bounding-rect/clipping measurement,
  and horizontal-overflow check.
- Manual open of all 18 article detail + 15 creator detail routes.
- Per-route console/network capture.
- WebGL / 3D scene behaviour (no 3D layer in this workspace).

### Remaining failures / open items
1. None in P0/P1 for this source.
2. P2 chunk-size warning (615 kB main JS) — optional manualChunks fix.
3. The described Manus **3D spatial deployment is not present**; provide that workspace/URL to
   audit sections 16–17, or direct me to add a deliberate spatial layer if desired.
4. Confirm noindex intent.

---

*Prepared with the HARD SAFETY LOCK honored entirely. **Deployment performed: NO.** No FTP, no
credential use, no live publish, no live-site modification. All output confined to the local
workspace.*
