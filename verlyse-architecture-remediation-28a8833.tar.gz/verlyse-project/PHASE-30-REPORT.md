# PHASE 30 — GLOBAL ART-DIRECTION AUDIT
**Question: does Verlyse Media feel like ONE extraordinary physical literary institution that happens to be a website — or a collection of independently designed routes?**

**Status: AUDIT COMPLETE — NO CODE CHANGES. Awaiting user review & explicit authorization before any polish.**

Verified in real Chromium (headless 'new', swiftshader) against the approved boards: Phase 25 (`/home/user/p25-shots/`, dossier `d1–d4`, room `r1–r4`), Phase 27 (`/home/user/p27-shots/`, nine rooms, annotation rail cropped), and the standing design system (P19 MATERIALS · DESIGN SYSTEM). 12 canonical routes × desktop 1440×900 / tablet 768×1024 / mobile 390×844, plus reduced-motion and WebGL-off on six key routes. Data: `audit/phase30-inspection.json`, captures `audit/shots/phase30/`.

---

## 1 · Route-by-route score (coherence + board fidelity)

| Route | Room | Score | Verdict |
|---|---|---|---|
| `/` | entrance | **A−** | Wine hall opens on the brass wordmark; the one board place where the impl actually *exceeds* the board's ivory presence at the foot of the page (3.1% vs 0.4% in that strip — harmless, reads as the house footer plate). |
| `/articles` | archive | **B** | The folio shelf is a working, keyboard-accessible composition (validated 274/0/14). The board draws ivory folio *cards*; the impl draws gold-hairline folio *rows* on wine. Functional and deliberate — but it is the impl's biggest visual divergence from its board after the colophon/desk pair. |
| `/article/…` | reading | **A** | Phase-29 green. The single documented divergence (board draws the reading column ivory; the *protected canonical article* is wine with ivory type) is unchanged and required by the brief. Room furniture conforms to `r1–r4` exactly. |
| `/creators` | wall | **B+** | Ivory is present where it matters (the `#F2EADA` portrait mattes, 190px frames). Board's larger left plate (408×267) is not reproduced; the small photo mattes carry the same paper idea. |
| `/creator/…` | dossier | **A** | Phase-29 green against `d1–d4`: standing ivory dossier sheet, brass inner hairline, overlapping portrait plate, cream featured-folio plate, ghost monogram. 50.7% ivory, the paperiest room — correctly so. |
| `/ambassadors` | people | **A−** | 12 diamond medallions verified live (242×181, gold hairlines, ivory numerals). The board's wide ivory panel in the gallery region is not reproduced — medallions sit as outline diamonds on wine. |
| `/categories` | wings | **B+** | Seven arched door facades, real departments/counts, keyboard-navigable (← → / Esc). Rendered as gold-line ghost arches on wine; the board's tall ivory door plates are not reproduced. |
| `/community` | commons | **B+** | Reel of voice cards (bordered wine cards). The board's ivory card row at the top is not reproduced; composition otherwise coherent. |
| `/about` | colophon | **C** | **The biggest single fidelity gap.** The room's own motif — "the layered editorial sheets" — is implemented at **5% opacity** (`bg-[#F8F6F2]/[0.05]`), so the sheets are effectively invisible and the room reads as a bare wine hall. Board region: **85.6% ivory; impl: 0.9%**. |
| `/submit` | desk | **C+** | The submission letter floats on the wine canvas with **no paper sheet at all** (no light-bg element >80px at any viewport). Board region: **85.8% ivory; impl: 0.4%**. Its sibling — the `/contact` letter — *does* sit on a full-opacity ivory sheet, so the two "letter" forms in the site are inconsistent with each other. |
| `/contact` | correspondence | **B** | The ivory letter sheet exists (650×943, `rgb(242,234,218)`, α=1) — but it starts at **y=646 of 900 on desktop, y=1353 on tablet, y=1314 on mobile**: below the fold at every viewport, where the board centers it at y≈16–72% of the frame. Paper present, placement off. |
| `/room` | keeping | **A+** | Untouched. 89/89 regressions. Deliberately the charcoal-toned chamber; its uniqueness is intentional and its board (`P25`) is consistent with it. |

---

## 2 · Penpot fidelity score — **76 / 100**

Desktop whole-page ivory %, board vs impl (Phase-27 rail cropped):

| Room | Board | Impl | Δ |
|---|---|---|---|
| colophon | 22.2 | 0.6 | **+21.6** |
| archive | 20.0 | 0.2 | **+19.8** |
| desk | 19.5 | 0.5 | **+19.0** |
| correspondence | 27.7 | 12.6 | +15.1 (sheet exists — placement) |
| commons | 11.7 | 1.8 | +9.9 |
| entrance | 10.3 | 0.5 | +9.8 |
| wall | 9.5 | 2.2 | +7.3 |
| people | 6.3 | 0.6 | +5.7 |
| wings | 4.2 | 0.4 | +3.8 |

Region-level evidence (the decisive check — the boards' ivory is **contiguous paper**, verified by blob analysis: e.g. colophon sheets = two solid 96k/65k-px rectangles, not text bars):

| Board region | Board ivory | Impl ivory |
|---|---|---|
| colophon sheets (x8–56%, y14–61%) | 85.6% | **0.9%** |
| desk form sheet (x28–84%, y16–51%) | 85.8% | **0.4%** |
| letter sheet (x28–72%, y16–72%) | 97.9% | 1.4% (sheet below fold) |
| archive card rows (two bands) | 58.3% / 56.2% | 0.0% / 0.1% |
| people gallery panel | 93.6% | 0.0% |
| commons card reel (top) | 84.2% | 1.3% |
| wall plate | 93.7% | 3.1% |
| wings door plate | 88.2% | 0.2% |

**Diagnosis (root cause, not speculation):**
- **Colophon:** DOM-confirmed `bg-[#F8F6F2]/[0.05]` on all three sheets — the paper is present in the DOM but at 5% alpha. Either a mistyped opacity or an over-ghosted treatment that defeats the board's solid-sheet intent.
- **Desk:** the `<form>` container carries no background class at all (`flex max-w-[640px] flex-col gap-10`). The board's form sheet was not carried into the impl, while Contact's was.
- **Archive / wings / people / commons / wall:** the boards place solid ivory objects; the impl renders these rooms as **wine + gold hairline line-work** (folio rows, ghost arches, outline medallions, wine voice cards, small photo mattes). These are consistent with each other and deliberate — they form the site's actual material language — but they are uniformly *less papery* than the approved boards.
- **Verified paper that IS present:** dossier 50.7% (Phase 29 green vs `d1` 64.5% — same composition family, portrait photograph accounts for most of the delta); reading room (documented canonical-article exception); correspondence letter sheet (α=1); wall photo mattes.

---

## 3 · Global coherence score — **92 / 100**

One institution: **yes.** Every route shares the same DNA and no route invents a foreign language:
- One wine-canvas material (the same layered wine gradients across all wine rooms), one brass hairline system, one ivory serif + mono-kicker typography, one diamond motif, one header/footer, one page-transition vocabulary, and the entrance → room → next-room flow.
- The differences that exist are **intentional tonal rooms**, not style drift: charcoal Keeping Room (deliberately unique tone), ivory-heavy Dossier (the paperiest room), quiet charcoal Reading Room, gold-ghost Wings, outline-medallion People.
- **Nothing on any route is objectively broken, glitchy, or orphaned** (see §11 P0 = none).
- The one coherence wrinkle is internal, not cross-room: the two "letter" forms (`/submit`, `/contact`) treat their paper differently — desk has none, correspondence has a full sheet. That single inconsistency is what drags the score from ~95 to 92.

---

## 4 · Desktop (1440×900)
All 12 routes: exactly **1×`h1`**, **zero horizontal overflow**, zero console errors, zero failed image requests. Compositions hold their boards' geometry at full width. The two P1s are visible here most sharply: colophon reads as three gold-outlined voids on wine; the desk form floats without paper.

## 5 · Tablet (768×1024)
All routes clean (1×h1, ox=0, no console errors, no failed requests). Intentional recompositions, never scaled desktop (verified in earlier phases and reconfirmed this walk). The correspondence sheet sits at y=1353 — the full sheet is below the fold; desktop at least showed its top 254px.

## 6 · Mobile (390×844)
All routes clean (1×h1, ox=0, console clean, no failed requests). Letter sheet at y=1314 (below fold); colophon sheets still 5% alpha (region ivory 0.5% vs board's sheet); desk still sheetless. Mobile benefits most from the P1 fixes, since below-fold paper is even harder to discover.

## 7 · Typography
Serif (display + body italic voice) and mono (kickers, folios, meta) across all 12 routes; ratio verified per route (e.g. entrance 109 serif / 191 mono elements; correspondence 45/49; keeping 60/50). No route substitutes a third family. `h1` headings, `kicker`/`eyebrow` pattern, and the brass `·`/`—` separators are uniform. The colophon's ivory text on near-invisible sheets is the only place type loses its backing.

## 8 · Material (materials language)
Wine canvas, brass hairlines, ivory paper, charcoal chamber — four materials, repeated everywhere. The board places paper in nine of the ten wine rooms; the impl currently shows solid paper in **three** (dossier, correspondence, reading-column furniture) plus matte-size paper on the wall. The pattern is consistent, which is why coherence is high — but it is consistently *below* the board's paper presence, which is the fidelity gap.

## 9 · Motion
Entrance/scroll reveals (`whileInView`, once, eased `cubic-bezier(0.16,1,0.3,1)`), the brass reading thread, medallion selection states, doors receding — all communicate spatial/editorial intent; none are decorative loops. **Reduced-motion verified pixel-identical** on all six probed routes (diff 0.00–0.02 — the 0.02 is the reading room's reader-position mark, matching the reduced board `r4`). **WebGL-off verified identical** (diff 0.00). No perpetual animation anywhere.

## 10 · Accessibility
- Structure: 1×h1/route, real `<button>`/`<Link>`/`<form>` semantics, `aria-current`, labelled controls, `aria-hidden` decorative ghost text only (the Contact h1's doubled textContent is decorative stroke text — not a bug).
- Keyboard: folio shelf, wing doors, medallions are real focusable elements with `focus-visible` gold outlines; `←/→` and `Esc` room patterns intact.
- Focus/overflow at all viewports: clean. No images failed anywhere; no console errors under reduced or WebGL-off.

---

## 11 · Ranked issues

**P0 — none.** Nothing is objectively broken on any route at any viewport.

**P1 — clearly weak / inconsistent (2):**
1. **Colophon sheets at 5% opacity** (`src/pages/About.tsx` — `bg-[#F8F6F2]/[0.05]`, three sheets). The room's named motif is invisible; board region 85.6% ivory vs 0.9%. Fix is contained to one file: raise sheet opacity toward solid paper and re-tint the in-sheet type (currently `text-ivory/90` — on solid ivory it must become wine/charcoal) with contrast checked.
2. **Desk form has no paper sheet** (`src/pages/Submit.tsx` — form container `flex max-w-[640px] flex-col gap-10`, no background). Board region 85.8% vs 0.4%; and its sibling `/contact` letter has a full-opacity sheet, so the two letter-forms are inconsistent. Fix mirrors Contact's sheet container; the field styles (`field-label`/`field-input`) are already shared and ivory-compatible.

**P2 — polish opportunities (2):**
1. **Correspondence sheet placement** (`src/pages/Contact.tsx`): sheet starts y=646 desktop / 1353 tablet / 1314 mobile — below the fold everywhere, where the board centers it. Compress the 70vh hero or raise the sheet so the paper is the arrival.
2. **(User's call, optional)** Board paper-parity on archive/wings/people/commons/wall (add solid ivory card/plate surfaces beneath existing content). This is *not* recommended by default — those rooms are deliberate ghost-line compositions that are consistent with each other and working (validated), and per the mandate a route changes only for a demonstrable reason.

**P3 — leave alone:** archive folio-row list (keyboard composition, board cards = alternative but not broken); wings ghost arches; people outline medallions; commons wine voice cards; wall's small mattes (board's big plate not required); entrance; keeping room; dossier; reading room; all typography, motion, accessibility behavior.

---

## 12 · Exact files needing change (if polish is authorized)
- `src/pages/About.tsx` — P1-1 (sheet opacity + in-sheet text colors).
- `src/pages/Submit.tsx` — P1-2 (form sheet wrapper, mirroring Contact).
- `src/pages/Contact.tsx` — P2-1 (letter placement: hero/sheet balance).

All three are **non-protected**. No protected file, no `/room`, no `src/data/content.ts`, no dependency, no route/URL change is involved. No new dependencies, no new effects, no new visual language.

## 13 · Protected files that must remain untouched
`src/App.tsx`, `src/index.css`, `src/lib/motion.ts`, `src/components/spatial/SpatialArchive.tsx`, `src/components/spatial/StoryEnding3D.tsx`, `src/components/ui/ArticleClosing.tsx`, `src/components/ui/ArticleWorld.tsx`, `src/components/ui/Motifs.tsx`, `src/components/ui/VibeAmbient.tsx`, `src/pages/ArticleDetail.tsx`, `package.json`, `package-lock.json`, `src/pages/Room.tsx` (13 files, `/tmp/protected-baseline.md5`), plus `/room` (89/89). None of the Phase-30 targets are in this set.

---

## 14 · Recommendation

**Yes — a small, targeted polish is justified; a broad one is not.**

Justified (demonstrable reason exists — board delta + internal inconsistency):
- **P1-1 colophon sheets** — the room's core motif is invisible against its approved board.
- **P1-2 desk sheet** — missing paper vs board *and* vs its sibling form.
- **P2-1 correspondence placement** — paper exists but arrives below the fold everywhere.

Not justified by the evidence (deliberate, consistent, working — P3): re-papering archive/wings/people/commons/wall. Those ghost-line compositions are *the* site's coherent material language; changing them to chase board ivory would be "replacing working compositions just to be different."

If the authorizer prefers maximum conservatism, even P1-1 could be argued as "intended ghost aesthetic" — but the code comment names the sheets as the room's substance, and the board (visual authority) draws them solid. **The two P1s are the only changes that would raise both fidelity and coherence scores materially, and each is contained to a single non-protected file.**

**STOPPED HERE per Phase-30 mandate: no code changes until the user reviews this audit and explicitly authorizes the polish.**
