# PHASE 24 — THE READING ROOM · Completion Report

**Route:** `/article/:id` · **Identity:** Verlyse Media — Where Vision Becomes A Voice · **Mode:** Arena/local dev only, no deployment.

The canonical article route is now a spatial READING ROOM built **around** the protected `ArticleDetail` implementation — never by rewriting it.

---

## 1 · Verdict

**PHASE 24 COMPLETE AND GREEN.** The article route reads as a physical Verlyse reading room: the reader enters through the existing wine threshold ("Folio №NN · Reading"), the room settles behind the folio, and the canonical article — untouched — reads inside it. Verified in real Chromium at **64/64** (×2 stable), with every retained suite green and all 15 protected files checksum-identical.

## 2 · Why the Reading Room feels spatial

"3D" here is **spatial hierarchy**, not effects — three planes composed around the reading column:

- **BACK** — a fixed deep-wine architectural field (radial "lamp" light + dark floor, `#3B0D17 → #2A0F18 → #1C070E`), two faint brass wall rules at the gutters, one horizontal shelf rule, and a **distant ghost folio numeral** (`№ {NN}`) engraved behind the reading column. Purely CSS — no canvas, no WebGL.
- **MID** — the folio's shelf marks: a vertical brass ledger at the left gutter ("The Reading Room — Folio №01"), the folio's index at the right ("Social Issues · № 01 / 19"), corner registration ticks, and a **brass thread** that draws down the left edge as the reader advances toward the ending — the thread of this folio.
- **FRONT** — the protected article: hero, metadata, body column, figures, ending, conversations, Up Next. Always on top (`z-[2]` over `z-0` room).

Depth is perceived, not manufactured: the room planes barely drift (`back 0.07 · ghost 0.11 · mark 0.03` per 1600px of scroll, capped), the article column never moves, and the thread grows with reading progress. Enter → read → leave; folio → room → archive.

## 3 · What changed

**`src/components/reading/ReadingRoom.tsx` (new, ~120 lines)** — the whole room. It reads `useParams`, derives the folio number from the authoritative registry (`ARTICLES.findIndex + 1`), renders the three planes, and passes `children` (the canonical article) through untouched. Reduced motion collapses every plane to a quiet static composition; WebGL is never required (CSS only).

**`src/App.tsx` (2 lines)** — import + route wrap:
`<Route path="/article/:id" element={<PageTransition …><ReadingRoom><ArticleDetail /></ReadingRoom></PageTransition>} />`
Nothing else. The existing wine threshold (PageTransition) is preserved exactly.

## 4 · Files created / modified

| File | Kind |
|---|---|
| `src/components/reading/ReadingRoom.tsx` | **created** — the room shell |
| `src/App.tsx` | modified (2 lines: import + wrap) |
| `audit/phase24-reading-room-validate.mjs` | **created** — 64-check real-Chromium harness |
| `audit/phase24-reading-room-results.json` | generated results |
| `audit/shots/24-reading-{1440,768,390,reduced,nogl,mid-scroll}.png` | captured evidence |

## 5 · Protected-file integrity

`md5sum -c /tmp/protected-baseline.md5` (regenerated pre-edit): **15/15 OK, 0 diffs.** `ArticleDetail.tsx`, `ArticleWorld.tsx`, `ArticleClosing.tsx`, `Motifs.tsx`, `VibeAmbient.tsx`, `StoryEnding3D.tsx`, `SpatialArchive.tsx`, `motion.ts`, `index.css`, `package.json`, `package-lock.json`, `vite.config.ts`, `src/lib/three/*` — all byte-identical. No new dependencies, no new canvas, no Three.js added.

## 6 · Desktop 1440×900

Strongest room: ghost folio numeral behind the column, shelf marks in the gutters, thread drawing down the edge, brass wall rules, wine field. Verified: back field renders (radial+linear), ghost `№ 01` with engraved stroke, ledger + index markers, thread unspooled at rest (scaleY≈0) and drawn at 70% scroll (scaleY>0.5), restrained parallax (back ≈28px, ghost ≈44px at scroll 400), content paints above the room, one H1, no overflow, keyboard focus visible, console clean. Capture: **0% pure black, 71% deep wine** (23A homepage was 89% black).

## 7 · Tablet 768×1024

Depth simplified: shelf marks and ghost recede (lg-gated), the wine room remains behind the reading column. Verified: one H1, no overflow, room simplified, console clean. Capture: 1% black, 76% wine.

## 8 · Mobile 390×844

A vertical reading space, one plane at a time: no miniature desktop 3D — markers, ghost and thread hidden; the folio → title → content hierarchy preserved. Verified: one H1, no overflow, body readable, room collapsed, console clean. Capture: 0% black, 78% wine.

## 9 · Reduced motion

The same room with zero motion: no parallax (planes `transform: none`), thread static at full length, no entrance animation, 0 running animations (≤1 allowed). Content, folio, markers, article, images, links all present. Capture: 0% black, wine dominant.

## 10 · WebGL-off

Complete publication with WebGL unavailable: no canvas in the DOM, one H1, `#ending` chamber intact, the room's ledger still reads, console clean, no blank states. The protected `StoryEnding3D` recedes as designed; the CSS room carries the space.

## 11 · Article flow result

Verified on all three canonical folios — **№01 `their-voices-matter`, №05 `hope-becomes-mythology`, №19 `mir-raza-ali`**:
- deep URL resolves & canonical URL intact · document title carries Verlyse Media · exactly one H1 (the title) · author credited · folio number on the room's ledger · body paragraphs intact with **no duplication** (whitespace-normalized matching, NEWS-UPDATE cards accounted for) · images intact (cover rendered, no failed `/img/` requests) · `#ending` chamber intact · Up Next links to another folio · no horizontal overflow · keyboard focus visible · console clean.
- **History:** archive → folio pulled → **Back restores the archive (19 folios)** → **Forward returns to the room**. Deep links, search, category filters untouched (C + L suites green).

## 12 · Validation counts

| Suite | Result |
|---|---|
| `npx tsc --noEmit` | ✅ 0 errors |
| `npm run build` | ✅ 6.15s |
| **NEW `phase24-reading-room-validate.mjs`** | ✅ **64 / 64** (×2 stable) |
| `phase21-c-validate.mjs` | ✅ 24 / 24 |
| `phase21-de-validate.mjs` | ✅ 7 / 7 (one transient timing flake re-run green) |
| `phase21-ghijk-validate.mjs` | ✅ 45 / 45 |
| `phase205-validate-v2.mjs` (/room) | ✅ 89 / 89 |
| `phase21-l-audit.mjs` | ✅ 272 PASS / 0 FAIL / 16 INFO |
| `quality-visible.mjs` | ✅ ROUTE MISMATCHES: none |
| Protected checksums | ✅ 15 / 15 identical |

## 13 · Screenshots

`audit/shots/24-reading-1440.png` (room at rest) · `24-reading-mid-scroll.png` (thread drawn, ghost visible mid-article) · `24-reading-768.png` · `24-reading-390.png` · `24-reading-reduced.png` · `24-reading-nogl.png`. Results: `audit/phase24-reading-room-results.json`.

## 14 · Performance observations

Pure CSS + three `useTransform` scroll hooks in the shell — no canvas, no WebGL, no new dependencies. The room adds negligible cost; the lazy `StoryEnding3D` chunk and route splitting are unchanged. No perpetual animation (the thread and parallax are scroll-driven only).

## 15 · Remaining observations (honest)

- **What was visually verified in real Chromium:** the CSS room — wine field, brass rules, ghost folio, shelf marks, thread — via DOM/computed-style assertions and screenshots; captures show deep-wine dominant, 0% black at rest.
- **Sandbox/WebGL limitation:** the protected `StoryEnding3D` scene composites dark in the sandbox's software WebGL (as with every earlier phase), so the *ending chamber's* pixels can't be certified here — its presence is asserted programmatically (`#ending` intact) and it renders in a real browser. The room itself never depends on WebGL.
- The article body remains the dominant layer; the room is deliberately quieter than the homepage entrance.

## 16 · Deployment status

**No deployment.** Arena/local dev only — no Vercel, no InfinityFree, no DNS, no FTP, no production credentials touched.

---

*VERLYSE MEDIA is a publication that happens to exist in space — the reader pulled a folio from the archive, entered the room that holds it, and read it in the wine light.*
