# Verlyse Media — Final Production Audit Report

**Date:** 04.08.2026 · **Status:** PASSED — production-ready
**Build:** `tsc -b && vite build` — clean, zero errors, zero warnings
**Validation:** 97 automated checks green + axe-core zero violations + zero console warnings/errors in production

---

## 1 · Bug fixes

| Bug | Severity | Fix |
|---|---|---|
| **Nested `<a>` inside `<a>`** (Home cover card: `UnderlineLink` inside `Link`) — invalid HTML, broke screen readers | High | Inner link became a styled `span`; the card itself is the link |
| **Duplicate React keys** (Creators chips — category collided with first tag) | Medium | Keys now unique (`tag-index`) |
| **Framer-motion scroll-offset warning** — `useScroll({target})` with a static root container | Low | `html { position: relative }` (the documented fix) + positioned wrappers in `ScrollBeat` |
| **Fonts shipped twice** — the CSS `@import` made Vite bundle hashed copies into `dist/assets` while `index.html` preloaded the `public/fonts` copies; preloads were dead weight (~380 KB duplicated) | High | Fonts now load once via `<link rel="stylesheet">` with matching `crossorigin`; preloads match; hashed duplicates eliminated |
| **Active filter chip unreadable** — `text-wine` on dark wine background (nearly invisible) | High | Active state now gold, the house color |
| **Layout lists invalid** — `<ol>`/`<ul>` wrapping `Reveal` divs instead of `<li>` (Submit guidelines, Contact desk) | Medium | `Reveal as="li"` — lists are semantic again |
| **Faint label contrast** — 39 labels at `white/30–45` and `gold/60–80` failed WCAG AA (4.5:1) | Medium | Raised to a passing floor (55–60% white, full gold, wine 70–80% on the letter) — hierarchy preserved |
| **Footer covered by the mobile dock** (back-cover wordmark clipped) | Medium | Footer clears the dock on small screens |
| Stale rails ("one feature", "one open", hardcoded community numbers) | Low | Data-derived and true (18 / seven open, one waiting / ledger-driven) |
| Hardcoded dates/labels (cover plate, preloader, folio bar) | Low | Derived from the archive |
| "Feature not found" was a bare error line | Low | Now speaks the house voice |

React warnings (nested DOM, duplicate keys) were caught by running the **dev server** and capturing console output — production builds hide them. All fixed; re-verified at zero.

## 2 · Security audit

| Check | Result |
|---|---|
| XSS / injection (`dangerouslySetInnerHTML`, `eval`, `document.write`, `innerHTML=`) | **None found** — user content is rendered as React text nodes; the one legacy escape helper is used correctly |
| `target="_blank"` links | **All 5 external links** now carry `rel="noopener noreferrer"` |
| API keys / secrets / `.env` | **None present** in the repository |
| Sensitive data exposure | Nothing — all content is public dataset content |
| Dependency vulnerabilities | **Fixed:** `vite` 5 → **7.3.6** (path-traversal/CORS advisories), `@vitejs/plugin-react` 4.4, `react-router-dom` 6.28 → **7.18.2** (open-redirect advisories). One advisory remains (RSC-mode CSRF, GHSA-qwww-vcr4-c8h2): it targets React Router **framework mode with server actions** — impossible in this client-side SPA (no server, no actions, no SSR), and no released version fixes it (npm's suggested downgrade would reintroduce the open-redirect bug). **Accepted as non-applicable.** |
| Third-party scripts | None — no CDNs, no analytics, no trackers. Fonts and motion are self-hosted. |

## 3 · Performance

| Metric | Before | After |
|---|---|---|
| Initial JS payload | 597 KB (gzip ≈ 176 KB) | **404 KB (gzip ≈ 135 KB)** — **32% lighter** |
| Route loading | One monolithic app chunk | **Code-split per route** — Home 30 KB, ArticleDetail 58 KB, others 5–16 KB, loaded on demand; Suspense fallback keeps navigation seamless |
| Vendor caching | App+libs in one chunk | **Stable `vendor` chunk** (React, Router, Framer Motion) cached across deploys |
| Fonts | Duplicated (hashed copies + public copies) | **Single copy**, preloaded, `font-display: swap` |
| Images | — | 83 WebP files, all referenced, all lazy-loaded except the hero preload (`fetchpriority="high"`) |
| Dead animations | 11 keyframes | **5 pruned** (`cue`, `marquee`, `pulse`, `drift`, `ghost`) — smaller CSS, less work |
| JS execution | Scroll listeners + rAF with leaks | Audited: every listener/timer/rAF has a cleanup; `useNearViewport` self-removes after reveal |

## 4 · File cleanup

- **Deleted:** 96 MB of generated previews/screenshots (workspace), 5 dead animation keyframes, `ScrollDrift`, `openMenu`, `MOTION` factory, `InkBlot`, `MarginalNote`, the `.glass` class, stale comments
- **Verified:** all referenced images (15 creators, canonical covers, inner figures) (zero orphans, zero broken references); no `console.log`/`TODO`/`FIXME` in source; no backup/temp files
- **Kept:** `uploads/` — the source datasets (the user's ground-truth data, not website assets)
- **Fonts** (`CormorantGaramond`, `Inter`, `IBMPlexMono`) — all four canonical files used; no duplicates

## 5 · Code quality

- TypeScript strict pass: `tsc --noEmit` — **zero errors**
- Dependency upgrades without API changes (Vite 7, Router 7) — build & full QA green
- Dead exports removed; naming and structure untouched otherwise (behavior preserved)
- `README.md` corrected to the truth (19 features · 1281 appreciations · 585 conversations · 15 creators)

## 6 · Accessibility — axe-core: **zero violations** on all 13 routes

- Fixed: invalid list structures, nested anchors, 39+ low-contrast labels (WCAG AA), focus order (verified), skip link first (verified), semantic headings (verified)
- Keyboard: full tab flow, Ctrl+K search, Esc to close everything, reading room toggles by key
- `aria-hidden` preserved on decorative elements; captions/labels above overlays

## 7 · SEO

- **Added:** `sitemap.xml` (42 URLs — pages, all 19 features, all 16 creator records; domain placeholder to update at deploy), `Sitemap:` reference in `robots.txt`, **Twitter Cards** (`summary_large_image`)
- Existing & verified: per-page titles/descriptions, OG tags, canonical URLs, JSON-LD (`WebSite` + `Article`/`WebPage` graph), heading hierarchy, internal linking

## 8 · Visual QA

- No overflow at 6 viewports (1920 → 390); no layout shift from `html { position: relative }` (regression green)
- All 42 internal links resolve; empty states (search, bookmarks, unknown story) verified; form error/success states verified; hover states verified
- Print stylesheet verified (chrome hidden, white paper, dark ink)

## 9 · Final validation — **PASSED**

- `npm run build` clean, no warnings
- Production console: **zero errors, zero warnings** (dev-only font preload notice does not occur in production)
- **97/97 automated checks green** across six suites + axe zero violations

---

## Deploy checklist (the only remaining work)

1. Replace the placeholder domain in `public/sitemap.xml` + `public/robots.txt` with the real domain
2. Host `dist/` on Netlify/Vercel/any static host — no server needed
3. Wire the forms (Submit/Contact/Newsletter) to a real inbox if desired — they validate client-side today and say so honestly
4. Optional: PWA manifest — the site is fully static and cacheable

*Stable. Secure. Performant. Maintainable. The room stays open.*
