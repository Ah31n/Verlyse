# PHASE 31 — Deployed-Site ↔ Penpot Fidelity Closure Audit

Date: 2026-09-03  
Deployment: **not performed** (per phase instruction)  
Runtime reference: `https://verlyse-react.vercel.app/`  
Implementation target: `/home/user/verlyse-project`

## Executive result

The repository already contains the Phase 28/29 Penpot remediation described by the supplied Phase 31B gap matrix: ivory entrance sheet, ivory archive folios, and an ivory selected Wings door are present in the current implementation. I verified these against the exported P27 board renders and the live local Chromium renders rather than relying on DOM text alone.

The only safe technical remediation required in this pass was removal of the unconditional `DaDY7WRkw0y-1.webp` image preload from `index.html`. It was being preloaded on every route even though it is specific to the first feature.

No protected file was changed. No Vercel configuration was changed. No deployment was made.

## Authoritative board identity

Penpot file identity available in the workspace:

- P27 file: `New File 1`, Penpot file UUID `c828d3cf-7d4e-8145-8008-8ef0c4255e55`
- P27 frames: exact stable frame names `P27 / <ROUTE FAMILY> — <VIEW>`
- P25 frames: exact stable frame names `P25 / THE DOSSIER — <VIEW>` and `P25 / THE READING ROOM — <VIEW>`

The supplied Penpot export contains stable frame names and the P27 file UUID, but does not contain individual Penpot frame UUIDs. No frame UUIDs were inferred or fabricated. The authoritative names used were:

| Route | P27 frame family |
|---|---|
| `/` | `P27 / THE ENTRANCE — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/articles` | `P27 / THE ARCHIVE — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/categories` | `P27 / THE WINGS — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/creators` | `P27 / THE CONTRIBUTOR WALL — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/ambassadors` | `P27 / THE PEOPLE — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/community` | `P27 / THE COMMONS — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/about` | `P27 / THE COLOPHON — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/submit` | `P27 / THE EDITORIAL DESK — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/contact` | `P27 / THE CORRESPONDENCE DESK — DESKTOP|TABLET|MOBILE|REDUCED` |
| `/creator/:id` | `P25 / THE DOSSIER — DESKTOP|TABLET|MOBILE|REDUCED MOTION (STATIC)` |
| `/article/:id` | `P25 / THE READING ROOM — DESKTOP|TABLET|MOBILE|REDUCED MOTION (STATIC)` |
| `/room` | P19 Keeping Room reference; distinct route, not copied |

## Gap matrix

| Route | Desktop | Tablet | Mobile | Reduced | Structural / visual result | Severity |
|---|---|---|---|---|---|---|
| Entrance `/` | Pass | Pass | Pass | Pass | Ivory feature sheet, centered threshold, folio bar, invitation/action hierarchy present | — |
| Archive `/articles` | Pass | Pass | Pass | Pass | 19 ivory folios, shelf rows, selected plate, search/filter/keyboard states present | — |
| Wings `/categories` | Pass | Pass | Pass | Pass | Seven doors, selected ivory door, receded non-selected doors, real category folios | — |
| Contributor Wall `/creators` | Pass | Pass | Pass | Pass | 16 registry contributors, focus/selection, dossier transition | — |
| People `/ambassadors` | Pass | Pass | Pass | Pass | Team clusters, numbered medallions, open-seat language and record dialog | — |
| Commons `/community` | Pass | Pass | Pass | Pass | Reel → ledger → voice → letter sequence | — |
| Colophon `/about` | Pass | Pass | Pass | Pass | Archive/imprint sheet treatment and colophon hierarchy | — |
| Editorial Desk `/submit` | Pass | Pass | Pass | Pass | Writer → work → piece → desk submission composition | — |
| Correspondence `/contact` | Pass | Pass | Pass | Pass | Letter → seal → send composition and validation states | — |
| Dossier `/creator/:id` | Pass | Pass | Pass | Pass | P25 dossier room, real contributor data, portrait/folio plates | — |
| Reading Room `/article/:id` | Pass | Pass | Pass | Pass | P25 room furniture around protected canonical article; thread, ledger, Up Next | — |
| Keeping Room `/room` | Pass | Pass | Pass | Pass | Distinct P19 archive/reference experience preserved | — |

## Deployed runtime audit

A direct Chromium audit was run against the actual Vercel URL across representative canonical, article, creator, `/room`, tablet, mobile, and reduced-motion routes: **60 records**.

Result:

- Runtime/page errors: **0**
- Failed requests: **0**
- Horizontal overflow: **0**
- Missing H1: **0**
- Tested viewports: 1440×900, 768×1024, 390×844, reduced 1440×900
- Evidence: `audit/phase31-deployed-runtime.json`

The deployed runtime still contains the old unconditional image preload because deployment was explicitly prohibited. The repository fix is ready but intentionally unpublished.

## Local visual/fidelity validation

`node audit/phase31b-visual-validate.mjs`

- **74 PASS / 0 FAIL / 0 INFO**
- Entrance sheet position, headline, and folio bar pass
- Archive: 19 folios, all ivory, selection, filtering, search, Esc, arrow navigation pass
- Wings: seven doors, selected ivory door, receding non-members, Esc return pass
- Desktop/tablet/mobile/reduced checks pass

`node audit/phase28-global-validate.mjs`

- **17 PASS / 0 FAIL / 4 INFO**

`node audit/phase205-validate-v2.mjs`

- **89 PASS / 0 FAIL** for `/room`

`npm test`

- Route matrix: 51 routes × 3 viewports
- Console/page/network errors: 0
- Horizontal overflow routes: 0
- Interaction suite: all checks passed
- Assets: **40/40 resolved**
- The first concurrent run showed timing flakes in the legacy validator; the standalone reruns passed the affected Wings/global checks. This is test-run concurrency sensitivity, not a rendered route failure.

## Technical findings

### THREE.Clock

No `THREE.Clock` or equivalent editable integration usage was found in the source. The protected spatial implementation was not changed.

### GPU ReadPixels

`readPixels` occurs only in the existing audit probe `audit/_probe28c.mjs`; it is not in the application runtime path. No rendering architecture change was made.

### Static preload

Fixed in `index.html` by removing the unconditional preload for `/img/works/DaDY7WRkw0y-1.webp`. The feature data still loads the image when the feature requires it.

### Their Voices Matter ending

The existing deterministic, story-specific ending and timing behavior passed the interaction audit. It was not removed or weakened.

## Files modified in this phase

- `index.html` — removed route-global first-feature image preload
- `PHASE-31-DEPLOYED-FIDELITY-REPORT.md` — this evidence report

Earlier-session visual fixes already present in the working tree were not reworked in this phase.

## Protected files verified unchanged

- `src/components/spatial/*`
- `src/lib/three/*`
- `src/components/ui/ArticleClosing.tsx`
- `src/components/ui/ArticleWorld.tsx`
- `src/components/ui/Motifs.tsx`
- `src/components/ui/VibeAmbient.tsx`
- `src/pages/ArticleDetail.tsx`
- `src/lib/motion.ts`
- `src/index.css`
- `package.json`
- `package-lock.json`
- `vite.config.ts`
- `src/pages/Room.tsx`

## Final status

### Implemented

- Confirmed and validated existing P27/P25 fidelity remediation
- Removed unnecessary global static image preload
- Verified deployed runtime behavior without publishing changes
- Verified P19 `/room` regression at 89/89

### Remaining P0

- None found.

### Remaining P1

- None found in the audited P27/P25 route families.

### Remaining P2/P3

- Pre-existing informational bundle-size warning for the Three.js chunk
- Legacy audit scripts can be sensitive to concurrent browser runs
- Individual Penpot frame UUIDs are not present in the supplied export; stable file UUID plus exact frame names are recorded above

### Build

`npm run build` — passed; only the pre-existing large-chunk advisory remains.

### Deployment

Not performed, as required. The production Vercel deployment remains unchanged.
