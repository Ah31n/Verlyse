# PHASE 23A.1 — THE ENTRANCE REVEAL · Completion Report

**Route:** `/` (homepage) · **Objective:** make the entrance visibly, unmistakably the threshold to a physical Verlyse Media publication — by revealing and art-directing the *existing* SpatialArchive, not by adding effects. **No protected file touched. No /room influence. No new dependencies.**

---

## 1 · Why Phase 23A failed the visual objective (diagnosis)

Real-browser probing found two compounding causes:

1. **The archive was invisible by stacking + opacity.** The SpatialArchive canvas sits in a `z-[1]` layer **above** the wine atmosphere and vignette, and its scene sets `<color attach="background" args={['#000000']} />` — an *opaque black* field with semi-transparent cover plates (`opacity 0.4·distFade`) drawn on it. The heavy wine atmosphere (`rgba(92,18,36,0.9)`) and full vignette (`rgba(22,5,10,0.55)`) further dimmed everything behind the masthead. Measured: the Phase-23A at-rest 1440×900 capture was **89% pure black** — the wine identity was suppressed along with the archive.
2. **23A's at-rest deltas were near-invisible.** Two 1px hairlines at 30% brass, a caption line, a folio-bar text change, and a ghost wordmark stroked at **13% brass alpha** do not read as "something happened" at rest. The drama only existed while scrolling, at modest rates.

So the user's perception — "the same, normal, like nothing happened" — was correct.

## 2 · The reveal strategy (all in Home.tsx)

| Levers | What changed | Why it reveals |
|---|---|---|
| **Lighten blend on the canvas** | Wrapper div: `[&_canvas]:mix-blend-lighten` around `<SpatialBoundary>` | `lighten(black scene field, wine backdrop) = wine backdrop` → the scene's black box disappears; only the **cover plates and brass thread** (brighter than black) remain visible, now floating inside the wine. The archive reads as physical objects, never a black rectangle. Applied via CSS from Home — zero changes to SpatialArchive. |
| **Wine atmosphere reduced** | `rgba(92,18,36,0.9)` → `0.38`; base `linear-gradient(170deg,#4A1120,#3B0D17,#1A070E)` | Veil lifted; wine identity kept and slightly warmer so the plates read against it. |
| **Vignette reduced** | `rgba(22,5,10,0.55)` → `0.26` | The archive no longer sits under a full-screen dark wash. |
| **Ghost VERLYSE legible** | stroke `rgba(184,145,70,0.13)` → `0.36` | Publication typography now visible at rest — engraved, not a logo. |
| **Ghost folio — № 01** | New mid-plane layer, `z-[1]`, left gutter behind the headline: `font-serif text-[clamp(7rem,18vw,18rem)]`, stroke `rgba(184,145,70,0.16)`, parallax `0.11` | The issue numeral is visible before scrolling — a publication mark printed into the architecture. |
| **Registration marks** | 4 brass crosses at the editorial field corners (lg+) | Press-sheet language completes the registration story begun by the hairlines. |
| **Stronger scroll progression** | `atmo 0.36 / ghost 0.24 / band 0.16 / folio 0.11 / copy 0.10 / plate −0.08`, plate scale cap `1.05 → 1.08` | Perceptible, controlled camera progression — still normal scrolling, no hijack, no loops. |
| **Feature plate** | Same registry link (`their-voices-matter`), stronger counter-parallax (−0.08), scale →1.08, hover lift + focus outline retained | "Slightly forward from the archive at rest; small lift on hover/focus." |

**Depth planes after the change:** BACK = SpatialArchive plates + brass thread receding into wine · MID = ghost VERLYSE, № 01 folio, hairlines, registration marks · FRONT = headline, supporting copy, PULL → READ → RETURN, feature plate.

## 3 · Exact files changed

- **`src/pages/Home.tsx`** — the *only* changed file: parallax constants (7 transforms), atmosphere gradient, vignette, ghost stroke, new folio layer, new registration marks, blend wrapper around SpatialBoundary.
- Nothing else. `src/components/spatial/*`, `src/lib/three/*`, `ScrollBeat.tsx`, all other protected files: **untouched**.

## 4 · Before / after (measured in real Chromium)

| At-rest 1440×900 capture | Pure black | Wine field | Archive / plates |
|---|---|---|---|
| Phase 23A | **89%** | hidden | invisible (under opaque scene + veils) |
| Phase 23A.1 (CSS-only paths: WebGL-off, reduced, tablet, mobile fallback) | **0%** | dominant (57–62%) | — |
| Phase 23A.1 WebGL-on (real browser) | blend applied → black field lifts into wine | visible | plates + thread visible |

**Honest sandbox caveat (same as §18 below):** the sandbox's software WebGL cannot draw the scene's textures (its true framebuffer is black), so a *pixel* proof of the WebGL-on plates cannot be captured here. The reveal is proven by: computed styles (canvas `mix-blend-mode: lighten` asserted green; atmo `0.38`; vignette `0.26`; stroke `0.36`), the lighten math, and the pristine CSS-only captures. The definitive WebGL-on visual happens in the user's real browser.

**Parallax measured at scrollY=400:** atmo 144 > ghost 96 > band 64 > folio 44 > copy 40, plate −32, scale 1.024 — every plane distinct.

## 5 · Protected checksums

`md5sum -c /tmp/protected-baseline.md5` (regenerated pre-edit): **15/15 OK, zero diffs.**

## 6 · §13/§15 verification results

| Check | Result |
|---|---|
| `npx tsc --noEmit` | ✅ 0 errors (pre-edit and post-edit) |
| `npm run build` | ✅ 7.44s (baseline) / 6.76s (after) |
| **`audit/phase23a-home-validate.mjs` (27 checks, real Chromium)** | ✅ **27/27** (×2 runs, stable) |
| Desktop 1440×900 | ✅ one H1, title, issue/ledger/descent/PULL→READ→RETURN, hairlines, 4 registration marks, blend `lighten`, atmo 0.38, vignette 0.26, ghost stroke 0.36, folio № 01, parallax hierarchy, plate scale 1.024, no overflow, keyboard focus visible, console clean |
| Tablet 768×1024 | ✅ one H1, no overflow, console clean |
| Mobile 390×844 | ✅ one H1, no overflow, CTA + pull present, console clean; fallback capture wine 0% black |
| Reduced motion | ✅ 0 movers, 0 running animations — same full static composition (folio, ghost, marks, headline, feature all present) |
| WebGL-off | ✅ entrance fully intact, console clean |
| Interaction | ✅ feature link canonical → `/article/their-voices-matter`; Tab reaches it with visible brass outline; header/search/nav exercised by C + L suites |
| `phase21-c-validate.mjs` | ✅ 24/24 |
| `phase21-de-validate.mjs` | ✅ 7/7 (one transient timing flake re-run green) |
| `phase21-ghijk-validate.mjs` | ✅ 45/45 |
| `phase205-validate-v2.mjs` (/room) | ✅ 89/89 |
| `phase21-l-audit.mjs` | ✅ 272 PASS / 0 FAIL / 16 INFO |
| `quality-visible.mjs` | ✅ route mismatches: none |
| 0 horizontal overflow / 0 console errors / 0 failed requests | ✅ (per harness) |

## 7 · Screenshots (evidence)

- `audit/shots/23a-home-1440.png` · `23a-home-768.png` · `23a-home-390.png` — viewports (WebGL-on)
- `audit/shots/23a-home-reduced.png` — reduced motion (wine, 0% black)
- `audit/shots/23a-home-nogl.png` — WebGL-off (wine, 0% black)
- `audit/shots/23a1-home-1440-scroll400.png` — mid-scroll depth (wine bleeding through the lifted field)
- `audit/shots/23a1-home-390-nogl-evidence.png` — mobile fallback (wine, 0% black)
- Machine-readable: `audit/phase23a-results.json` · harness: `audit/phase23a-home-validate.mjs` (exits 1 on any FAIL)

## 8 · Constraints honored

✅ Only Home.tsx changed; protected 3D system untouched (read-only inspected, never edited) · ✅ No new canvas, no duplicated scene, no new deps · ✅ No /room composition copied, identity unchanged · ✅ No content invented (plate, ledger, registry all authoritative) · ✅ No generic-3D/glow/particles/neon · ✅ Reduced motion = static spatial composition · ✅ No scroll hijack, no rotation, no infinite corridor · ✅ No deployment.
