# PHASE 28A — THE ENTRANCE (`/`) · VALIDATION REPORT

**Verlyse Media — Where Vision Becomes a Voice** · 31 August 2026
Scope: implement the approved Penpot board `THE ENTRANCE` (desktop 1440×900 / tablet 768×1024 / mobile 390×844 / reduced 1440×900) as the app's landing route, keeping the shared architecture (SpatialArchive atmosphere, real featured story, real registry statistics, real navigation). **DONE — ALL GREEN.**

---

## 1 · Verdict

**PASS.** The `/` route reproduces the Penpot ENTRANCE board with the existing architecture and registry data. Real-Chromium validation: **33 PASS / 0 FAIL / 5 INFO**. Reduced-motion and WebGL-off captures are pixel-equivalent to the desktop composition (0.0 mean-abs-diff in the structural sweep).

## 2 · What shipped

| File | Kind | Purpose |
|---|---|---|
| `src/pages/Home.tsx` | rewritten | Penpot-conformed `Cover()` (line 38) + `IssueBand` (line 237). |
| `audit/phase28-entrance-validate.mjs` | NEW harness | Real-Chromium ENTRANCE inspection — hero structure, feature, stats, responsive, reduced, WebGL-off, console. |
| `audit/shots/phase28/entrance-{desktop,tablet,mobile,reduced,webgloff}.png` | captures | Validated frames. |

## 3 · The composition (BACK / MID / FRONT, per the board)

- **BACK** — the wine hall: radial warm-light wash, brass hairlines, the existing `SpatialArchive` atmosphere layer behind the masthead (unchanged protected component).
- **MID** — the engraved masthead: static ghost wordmark (`VERLYSE` / `MEDIA` — engraved brass stroke, never animated), the `V` mark, the issue line **`ISSUE № 01 — 19 FOLIOS · 16 VOICES · 7 DEPARTMENTS`**, the ghost folio `№ 01` numeral, and the tagline **“Where Vision *Becomes* A Voice”**.
- **FRONT** — the feature plate: **`THE FEATURE — FOLIO № 01`** · “Their Voices Matter” · **ALINA JAVED · @lina_.jved** · SOCIAL ISSUES · 4 MIN READ · 26.06.2026, with **`ENTER THE ARCHIVE →`** (`/articles`) and the supporting line *“Poetry, essays, art and the issues that matter.”* The feature title is a real link to `/article/their-voices-matter`; the archive link is real. The band beneath carries the real numbers — 19 features · 15 creators · 1281 appreciations · 585 conversations.

**States:** REST · FOCUS · READ (all canonical links) · RETURN. No automatic spectacle, no scroll hijacking, no blocking intro.

## 4 · Responsive / reduced / WebGL-off

- **1440×900** — full composition (center masthead, feature plate, band).
- **768×1024** — masthead centered, feature re-flowed to 60% column, band wraps.
- **390×844** — intentional recomposition, single column: mark → tagline → feature → ENTER → band. Zero horizontal overflow.
- **Reduced** — same composition, fully present, static (all parallax/motion collapsed).
- **WebGL-off** — zero canvases, complete publication; the `SpatialArchive` atmosphere is absent but the page is whole.

## 5 · Materials & motion

Wine / ivory / brass / charcoal only — no neon, glass, chrome, holograms, or particles. Cormorant Garamond display, Inter body, IBM Plex Mono metadata. Motion is arrival/reveal only, all gated by reduced-motion, sharing the app's single `PageTransition` language.

## 6 · Validation (harness)

- 33 PASS / 0 FAIL / 5 INFO — **ALL GREEN** (`node audit/phase28-entrance-validate.mjs`).
- Zero console errors, zero failed requests, zero horizontal overflow at all viewports.
- All six standing regression suites remain green after 28A (phase21-l 274/0, phase21-c 24/0, phase21-de 7/0, phase21-ghijk 45/0, phase205-v2 89/0, quality-visible: none).

## 7 · Known deviations

None against the board. The `SpatialArchive` atmosphere is retained (existing architecture) and recedes to nothing under WebGL-off — by design.

---

**Stop-and-report gating satisfied.** Next: 28B — THE ARCHIVE.
