# PHASE 19 — THE KEEPING ROOM · PENPOT DESIGN GATE

**STATUS: DESIGN GATE COMPLETE — awaiting approval before any implementation change.**
Penpot is the design source of truth. No Figma used. No deployment. `/room` vertical slice already exists and is untouched.

---

## 1. The Penpot artifact

File page set **"P19 · THE KEEPING ROOM"** — 16 pages, each a single frame at origin (1440×900 desktop, 768×1024 tablet, 390×844 mobile):

| # | Page / frame | PRIMARY | SECONDARY | AMBIENT |
|---|---|---|---|---|
| 00 | **MATERIALS · DESIGN SYSTEM** | the system board | — | palette/type/plate/thread |
| 01 | **ARRIVAL** | "The Keeping Room" title + ENTER | ghost folio **19** | wine threshold, dim edge plates, brass rule |
| 02 | **ARCHIVE DISCOVERY** | plate **№01 Their Voices Matter** (brightest, brass edge) | plates 19/18…02 receding on the arc | brass thread, charcoal room |
| 03 | **ARTICLE FOCUS** | №01 plate enlarged, face-on | neighbour plates as dark silhouettes | dim room, thread brightens |
| 04 | **FOCUS SETTLE** | settled №01 plate (title/byline/date) | two faint edge plates | ENTER → / RETURN ← |
| 05 | **ARTICLE ENTRY** | article hero "Their Voices Matter" on wine | VERLYSE masthead | room fades to the page |
| 06 | **READING** | canonical article body (Alina Javed) | pull quote, progress rule | note: ArticleDetail owns reading |
| 07 | **ENDING** | closing line + signature "— Alina Javed" | ghost **01** | room re-forms, wine dark |
| 08 | **NEXT** | **№19 Mir Raza Ali** plate (newest) | dimmed №01 / №02 | "next on the thread" |
| 09 | **RETURN** | archive restored, №01 marked **READ ✓** | neighbouring plates | attention released |
| 10 | **CATEGORY** | Poetry — 7 folio plates on the thread | category count | "never becomes a list view" |
| 11 | **CREATOR DOSSIER** | "Alina Javed" contributor record | her 2 folios listed + open rows | dossier = canonical creator route |
| 12 | **SEARCH** | search field "voice" + №01 result | dimmed plates behind | overlay over the room, ESC returns |
| 13 | **AMBASSADORS / PEOPLE** | 8 real contributor cards | numbered medallions | **decision: ROOM → canonical /ambassadors** |
| 14 | **TABLET 768×1024** | №01 + №19, two-column portrait shelf | next four plates | composed for portrait, not scaled |
| 15 | **MOBILE 390×844** | one plate in hand — **№19 Mir Raza Ali** | №01 / №09 stacked below | reduced depth, thread runs vertical |

Every frame carries a mono state-label (`STATE · NN / 15 · …`) describing the interaction/decision.

---

## 2. Design system (board 00)

- **Type:** Cormorant Garamond (display/title/pull-quote) · Inter (sparing body) · IBM Plex Mono (folio labels, metadata, +tracking).
- **Material:** charcoal room `#161412`, wine panel/deep/main `#1E0B12/#2A0F18/#5C1224`, ivory plate `#F8F6F2`, cream/paper edge, brass thread `#B89146` / brass-hi `#D9B978` / brass-dim, faint type, ink.
- **Spatial elements:** ivory editorial plates (1–3px brass hairline, upright, contact shadow), a single ruled brass thread, reader-lamp warm key light, depth via neighbour attenuation (scale + opacity + arc), REST/HOVER/FOCUS/SELECTED plate states.
- **Editorial elements:** folio №, category, byline, contributor, signature, tags — all mono/quiet.
- **Interaction states documented:** idle/rest, hover (lifts, thread glows), focus (centred, others recede), selected/entered, reading, returning, reduced-motion.

## 3. Content discipline

Real registry only — nothing invented. Featured **№01 Their Voices Matter / Alina Javed / Social Issues**; newest **№19 Mir Raza Ali / Verlyse Media**. Registry order unchanged. Real contributor names across discovery, category (Poetry folios 05/09/11/15/16/17/18…), dossier (Alina Javed's two folios), and ambassadors.

## 4. Route / scope decisions

- **Reading** → canonical **ArticleDetail**; the room hands off, never duplicates.
- **Ending** → established StoryEnding3D / ArticleClosing / signature language; room fades back in.
- **Search** → sophisticated **overlay over the dimmed room** (not forced into 3D); ESC returns.
- **Ambassadors/People** → **ROOM → canonical `/ambassadors`**; the spatial archive is an entrance/discovery layer, not a replacement for canonical routes.
- Tablet and mobile are **intentional compositions** (portrait shelf; one-plate-in-hand), not scaled desktop.

## 5. Tool allocation

- **Penpot** — sole design surface (this gate).
- **OriginKit / Watermelon / Kokonut / Coconut / Vengeance / Skiper** — reviewed as references only; none imported; Verlyse identity preserved. No component showcase.
- **GSAP** — reserved for choreographed transitions (focus, settle, entry, return) in the existing isolated `/room` slice. **Anime.js** — lightweight micro-interactions only; never both on the same motion. No animation soup.
- **Three.js** — already isolated in `src/components/room` + `src/lib/room`; spatial only where editorially meaningful. Zero new dependencies.

## 6. The two critical tests

- **Test A (remove 3D):** every frame is a deliberate editorial composition — serif hierarchy, brass rules, ivory plates, mono metadata, real bylines — it still reads as a highly-designed publication. **PASS.**
- **Test B (remove Verlyse type/materials/story):** there are no blobs, particles, neon, glassmorphism, or generic WebGL hero; the structure is an archive of titled folios on a brass thread. It does not read as a generic AI-3D site. **PASS.**
Graceful 2D fallback (no-WebGL) is inherent: plates + thread + type carry the design.

## 7. Validation surface (implementation, already built in `/room`)

1440×900 / 768×1024 / 390×844; normal + `prefers-reduced-motion`; WebGL available/unavailable; keyboard; deep links; hard refresh; console/overflow checks. Protected files remain byte-identical; nothing deployed.

---

**DESIGN GATE COMPLETE.** Awaiting approval. No further implementation until approved.
