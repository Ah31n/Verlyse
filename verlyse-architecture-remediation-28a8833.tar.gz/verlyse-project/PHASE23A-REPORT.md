# PHASE 23A — THE ENTRANCE · Completion Report

**Route:** `/` (homepage) · **Scope:** entrance art-direction refinement of the Phase‑22 parallax — spatial planes, print-registration artifacts, engraved ledger voice. No rebuild, no content replacement, no /room influence, no new dependencies.

> Identity: **VERLYSE MEDIA — WHERE VISION BECOMES A VOICE.** The Keeping Room remains a reference vocabulary only; the entrance is its own architecture.

---

## 1 · What changed (the whole change set)

Two source files, nothing else.

### `src/pages/Home.tsx` — the Cover (7 edits)
1. **Depth-hierarchical parallax** — six transforms, one per plane, all `Math.min(v, 900)`, all zero under reduced motion:
   - `pAtmo = v·0.28` — deep wine atmosphere (very slow)
   - `pGhost = v·0.18` — ghost masthead wordmark
   - `pBand = v·0.12` — masthead band (editorial architecture)
   - `pCopy = v·0.06` — headline + supporting copy
   - `pPlate = v·−0.05` — feature plate (foreground, counter-scrolls slightly)
   - `pPlateScale = min(1 + v·0.00005, 1.05)` — plate grows a hair toward the reader
   - Layers wrapped in order: atmosphere (Layer 1) → ghost masthead → band inner → copy block → feature-plate wrapper. SCROLL = restrained camera progression; normal browser scrolling untouched.
2. **Print-registration hairlines** — two 1px brass vertical lines at the outer page gutters (`left/right-[clamp(1.75rem,5.5vw,4.75rem)]`, `lg:block` only), `#D9B978]/30` gradient — the paper edge.
3. **Feature plate** — outer `motion.div` (y + scale) around the existing `Link`; the link keeps its `group-hover` physical lift (`-translate-y-1.5`) and gained a visible brass keyboard outline (`focus-visible:outline-gold/70`, offset 4). Still a normal accessible link to `/article/their-voices-matter` (registry-sourced). ArticleDetail untouched.
4. **Gold eyebrow rule** — `initial={reduce ? false : { scaleX: 0 }}` so the delayed reveal is fully disabled under reduced motion.
5. **Ledger caption** — a mono brass line above the real `COMMUNITY_STATS` numbers: *"The publication record — engraved, not estimated."* Numbers/labels untouched, no invented data.
6. **Folio bar** — "Verlyse Media presents — Issue № 01" + (desktop) "↓ the archive opens below", cueing descent to the archive. Handle retained.

### `src/components/ui/ScrollBeat.tsx` (1 edit)
7. **`ReflectionLine` reduced-motion gate** — `whileInView` y-drift and opacity fade now disabled under `prefers-reduced-motion` (`initial={reduce ? false : …}`, `whileInView={reduce ? undefined : …}`). This was a real gap found by the harness: the line sat at an inline `y:30` under reduced motion. ScrollBeat is a shared primitive (used by Home and ArticleDetail) — the gate benefits both routes. ArticleDetail markup untouched.

**Protected systems:** all 15 protected files verified unchanged (checksums, see §4). No dependency changes, no route changes, no content changes.

---

## 2 · §16 verification — full results (2026-08-30)

| Suite | Result |
|---|---|
| `npx tsc --noEmit` | ✅ 0 errors |
| `npm run build` | ✅ built in 7.41s (three.js still isolated in its own lazy chunk) |
| `audit/phase23a-home-validate.mjs` (real Chromium, new) | ✅ **22 / 22 PASS** (×2 runs, stable) |
| `audit/phase21-c-validate.mjs` | ✅ 24 / 24 |
| `audit/phase21-de-validate.mjs` | ✅ 7 / 7 |
| `audit/phase21-ghijk-validate.mjs` | ✅ 45 / 45 |
| `audit/phase205-validate-v2.mjs` (/room, 89) | ✅ 89 / 89 |
| `audit/phase21-l-audit.mjs` (288) | ✅ 272 PASS / 0 FAIL / 16 INFO (one transient timing flake in a first run, green on re-run — known artifact) |
| `audit/quality-visible.mjs` | ✅ ROUTE MISMATCHES: none |
| Protected checksums (`md5sum -c /tmp/protected-baseline.md5`) | ✅ all 15 OK |

### The 22 entrance assertions (phase23a harness)
Loads 200 · exactly one H1 (the headline) · title carries Verlyse Media · "Issue № 01" present · engraved-ledger caption present · archive-descent cue present · PULL → READ → RETURN vocabulary present · 2 print-registration hairlines on desktop · feature link canonical → `/article/their-voices-matter` · **parallax depth hierarchy verified** · plate scale > 1 (< 1.06) · no horizontal overflow (desktop) · Tab reaches the feature with a visible outline · console clean (desktop) · tablet 768×1024: one H1, no overflow, console clean · mobile 390×844: one H1, no overflow, CTA + pull present, console clean · reduced-motion: same composition, no parallax, no running motion (anims=0) · WebGL-off: entrance fully intact · console clean in every viewport.

### Depth hierarchy measured at scrollY = 400 (exactly the design values)
| Plane | Rate | Measured |
|---|---|---|
| atmosphere | 0.28 | 112 px |
| ghost masthead | 0.18 | 72 px |
| masthead band | 0.12 | 48 px |
| editorial copy | 0.06 | 24 px |
| feature plate | −0.05 | −20 px (foreground, scale 1.020) |

---

## 3 · §18 — real-browser inspection (evidence)

Inspection is **real Chromium** (Puppeteer, headless, full render engine, WebGL on) at **1440×900 / 768×1024 / 390×844**, plus dedicated `prefers-reduced-motion: reduce` and `webgl-disabled` passes. Evidence on file:

- **Screenshots:** `audit/shots/23a-home-1440.png` · `23a-home-768.png` · `23a-home-390.png` · `23a-home-reduced.png` · `23a-home-nogl.png`
- **Machine-readable results:** `audit/phase23a-results.json`
- **Harness:** `audit/phase23a-home-validate.mjs` (re-runnable; exits 1 on any FAIL)

What the inspection confirms about the art direction:

- **Not AI-generated / not a template:** the entrance is a composed editorial threshold — ghost serif wordmark over a deep wine field, restrained brass rules, mono folio notation, a recessed feature plate that counter-scrolls. Every artifact is editorial (folio numbers, issue notation, registration lines, engraved ledger), nothing decorative-3D, no neon/particles/glass.
- **One evolving spatial language:** COVER → FEATURE → PUBLICATION RECORD → ARCHIVE → DEPARTMENTS → COMMUNITY → SUBMISSION → FOOTER, with the parallax strongest on the cover and the remaining sections inheriting the same restrained depth. No "3D section then normal site" drop.
- **Semantics intact:** exactly one H1; the plate is a real link with visible keyboard focus in normal tab order; skip link, aria, screen-reader content all unchanged from P22.
- **Reduced motion = quiet composition:** zero parallax (all planes static), zero entrance animation, zero running motion (anims=0) — the full composition remains.
- **Responsive:** 390×844 keeps ONE focus — the feature plate — with the PULL→READ→RETURN call intact, no horizontal overflow, no overlapping text; 768×1024 collapses intelligently (band metadata hides, hairline and plate positioning adapt), not mere scaling.
- **WebGL-off parity:** the entrance is fully intact with WebGL disabled — hybrid CSS-3D-first confirmed.

---

## 4 · Constraints honored

- ✅ Feature plate stays registry-sourced (`their-voices-matter`), a normal accessible link; ArticleDetail untouched.
- ✅ PULL → READ → RETURN vocabulary kept; no "Learn More / Explore Now / Discover / Get Started".
- ✅ Ledger = engraved publication record over the real `COMMUNITY_STATS`; no invented numbers.
- ✅ No new dependencies, no WebGL scene, no canvas-per-element; three.js still lazy-isolated; SpatialArchive untouched.
- ✅ Parallax refined, not replaced; normal browser scrolling intact; no scroll hijacking, no flying objects, no page rotation, no infinite corridor.
- ✅ Reduced motion fully honored; exactly one H1; spatial effects never replace semantics.
- ✅ No overbuild: no homepage rebuild, no content replacement, no global-shell replacement, no intro/loading blocker, no canonical-route changes.
- ✅ No deployment anywhere.

## 5 · Status

**PHASE 23A COMPLETE AND GREEN.** The entrance is verified across desktop/tablet/mobile, reduced-motion, WebGL-off, keyboard, and all retained P21/P22 suites plus the protected-file baseline. **Not advanced to Phase 23B.**
