# Verlyse Media — Workspace

## Single working copy: `~/verlyse-project/`
The entire editable source (React 18 + TypeScript + Vite 7 + Tailwind 3 + Framer Motion + Router 7),
cloned from `https://github.com/Ah31n/Verlyse.git` (extracted from the `workspace-*.zip` in that repo).

The old **deployed-mirror copy** (compiled bundles / duplicate static assets in the workspace root)
was **removed** — it's reproducible via `npm run build` and re-deploying, so it was redundant.

### Source layout
```
verlyse-project/
├─ index.html · vite.config.ts · tailwind.config.js · tsconfig.json · vercel.json · package.json
├─ api/newsletter.ts            Vercel serverless route (newsletter + contact)
├─ scripts/                     deploy.sh · htaccess-prod · serve.mjs · verify-authors.mjs
├─ public/                       fonts/ · img/ · favicon.svg · robots.txt · sitemap.xml
└─ src/
   ├─ main.tsx · App.tsx · index.css · lib/motion.ts
   ├─ data/content.ts           article/category/author/work content
   ├─ hooks/                    useNearViewport.ts · useSeo.ts
   ├─ components/layout/        Dock, Footer, Header, Layout, Preloader, SavedDrawer, SearchOverlay
   ├─ components/ui/            ArtGallery, ArticleClosing, ArticleSignature, ArticleWorld, AuthorFrame,
   │                            CountUp, EasterEggs, Motifs, MotionMoves, PageProgress, ReadingMode,
   │                            Reveal, RevealImage, ScrollBeat, ShareButtons, SplitText, VibeAmbient,
   │                            VoiceCarousel, WriterProfile, primitives
   └─ pages/                    About, Ambassadors, ArticleDetail, Articles, Categories, Community,
                               Contact, Creators, Home, Submit, WriterProfilePage
```

## Build / run / deploy
- `npm install` → `npm run dev` (dev) · `npm run build` (→ `dist/`) · `npm run preview`
- Deploy to InfinityFree **verlysemedia.kesug.com**: build, then upload `dist/*` to `htdocs/`
  (see `scripts/deploy.sh` for the intended flow) via FTP `ftpupload.net:21` (credentials are supplied at run time via `FTP_USER`/`FTP_PASS` environment variables — the original FTP account was leaked and is revoked; see `scripts/`).
- Production host also exists on Vercel as `verlyse-react.vercel.app`.

## Notes
- `src/data/content.ts` has 4 distinct artwork entries that reuse one identical image file
  (`DbQMFVEitsU-3` = `DbYa5WSE5wf-10` = `DbaNAZTk5X9-5` = `Dbf7jnBk3ho-5`). These are **not**
  true duplicates — each is part of a different work's slide set. Left intact.
- Security: rotate the InfinityFree FTP password (it was pasted in chat).
