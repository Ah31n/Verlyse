# VERLYSE MEDIA — PROJECT STATUS REPORT (A–Z)
### Complete handoff for a fresh AI coding session · Updated 2026-08-31

> **What this is:** a self-contained report of the entire Verlyse Media website project —
> origin, architecture, design system, all transformation phases, current state, how to run
> and test it, and the rules that must not be broken. Hand this to ChatGPT (or any coding
> agent) to continue work without needing the original conversation history.
>
> **Workspace root:** `/home/user/verlyse-project` (the `verlyse-project` directory in the
> session's workspace). The repo is a Vite + React app. A live dev server may or may not be
> running depending on when this is read — see §14 "How to run".

---

## 1. PROJECT IDENTITY (non-negotiable)

- **Global identity:** **VERLYSE MEDIA** — tagline **"Where Vision Becomes A Voice"**.
- **What it is:** a student-led media platform / literary publication presenting youth
  perspectives on culture, global issues and creativity. Poetry, essays, creative writing,
  art, photography, social issues, stories, horror, lifestyle.
- **"The Keeping Room" is NOT the site name.** It is the *spatial/editorial design
  vocabulary* and a *reference implementation* (the `/room` route). It must never be treated
  as a rebrand, site title, or standalone gimmick. Removing the phrase must leave the site
  unmistakably **VERLYSE MEDIA**.
- **The product feel:** a literary publication that exists as a physical, cinematic world —
  the reader moves through an institution (entrance → archive → reading rooms → wings →
  contributor wall → people → commons → colophon → desk). NOT "a website with 3D effects",
  NOT an AI-website cliché, NOT a WebGL showcase.

## 2. ORIGIN & HISTORY (condensed)

| Phase | What happened | Status |
|---|---|---|
| Pre-6 | Original site built from the platform's real Instagram feed (`verlyse.media`); content registry established as ground truth | Done |
| 6–17 | Progressive immersive-motion/cinematic/accessibility/performance phases; content ingestion; production handoff | Done |
| 19 | **Penpot** design foundation: palette, typography, plates, folios, brass rules/thread, paper edges, warm light, archival metadata. Penpot is the **design source of truth** (do NOT use Figma) | Done |
| 20 | **/room "The Keeping Room"** built as a spatial archive **reference implementation** (CSS-3D plates, brass thread, focus states) | Done — keep, do not copy per-route |
| 20.5 | /room polish: focus retention, wine tone; **89/89 validation suite** (`audit/phase205-validate-v2.mjs`) | Done |
| 21 | **Global immersive transformation (A–L):** wine-threshold route transitions, folio-indexed nav, homepage entrance, spatial archive system (`src/lib/archive/*`), article pull/entry flow, categories → spatial index, creators → dossiers, ambassadors → people medallions, search → editorial index, community/about/submit/contact → each its own metaphor, final 288-check coherence audit | Done |
| 22 | **Immersive publication evolution:** archive → **three-shelf stacks** (desktop), homepage **scroll parallax**, categories → **The Wings**, creators → **The Contributor Wall**, community ledger **engraved into the room**; full re-audit | Done (this is the current state) |

## 3. TECH STACK

- **Vite 7** + **React 18** + **react-router-dom 7** + **TypeScript** (`tsc -b`)
- **framer-motion 11** (UI/state transitions), **GSAP 3** (installed, used only for specific
  choreographed sequences), **three 0.185 + @react-three/fiber 8** (only the bounded
  protected layers: home SpatialArchive, article StoryEnding3D, /room)
- **No Tailwind config file** — Tailwind is used via Vite + classes defined in
  `src/index.css` (which is **protected**). Custom utility classes like `.img-frame`,
  `.btn-gold`, `.field-input`, `.kicker`, `.eyebrow`, `.pull-quote` live there.
- **No new dependencies allowed** unless absolutely necessary.

## 4. ARCHITECTURE — KEY FILES

**Routes (`src/pages/`):** `Home.tsx` (entrance) · `Articles.tsx` (archive) ·
`ArticleDetail.tsx` (**protected**) · `Categories.tsx` (wings) · `Creators.tsx`
(contributor wall) · `WriterProfilePage.tsx` (dossier /creator/:id) ·
`Ambassadors.tsx` (people) · `Community.tsx` (commons) · `About.tsx` (colophon) ·
`Submit.tsx` (desk intake) · `Contact.tsx` (desk) · `Room.tsx` (deep archive).

**The shared VerlyseWorld spatial system (Phase 21, evolved in 22):**
- `src/lib/archive/geometry.ts` — deterministic shelf geometry. `archiveLayoutForWidth`
  (mobile <560 / tablet <1024 / desktop). `shelfStyle(i, focus, layout, reduced, context)`
  returns transform/opacity/zIndex/pointerEvents. **Desktop = three-shelf stacks**
  (`SHELF_ROWS`: far y-156 z-260 · mid y0 z-130 · near y156 z10; 7·7·5 folios; focused folio
  lifts −22y / +150z). Tablet = two-column portrait shelf; mobile = one-plate-in-hand
  vertical thread. `memberSet` context = spatial filter (members brighten/approach,
  non-members recede to ghosts). Reduced-motion = quiet responsive arrangement, no perspective.
- `src/components/archive/ArchiveShelf.tsx` — the spatial stage: keyboard model (←/→ move
  real DOM focus, Enter pulls, Esc returns), brass thread (tablet/mobile) or shelf boards +
  back wall (desktop), reduced-motion & no-WebGL safe.
- `src/components/archive/FolioPlate.tsx` — the ivory editorial plate unit (always a
  semantic `<a>` to `/article/:id`, aria-label `Folio NN: title by author`, ghost folio
  numeral, NEWEST badge, focused pull gradient).
- `src/hooks/useArchiveLayout.ts` — resize-aware layout hook.

**Global shell (Phase 21):**
- `src/App.tsx` — route-aware archival PageTransition (wine veil `#2A0F18` + brass thread +
  mono folio label; `thresholdLabel()` per route; `seenFirstRoute` gate; reduced-motion
  near-instant). Labels: `/` "The archive" · `/articles` "Nineteen folios" ·
  `/article/:id` "Folio NN · Reading" · `/categories` "The index" · `/creators` "The
  contributors" · `/creator/:id` "A contributor dossier" · `/ambassadors` "The people" ·
  `/community` "The commons" · `/about` "The colophon" · `/submit` "Send a voice" ·
  `/contact` "The desk".
- `src/components/layout/Header.tsx` — folio-indexed nav (01 Articles · 02 Categories ·
  03 Featured Creators · 04 Community · 05 Brand Ambassador · 06 About), gold active index,
  **segment-aware active state** (nested `/article/:id` → 01, `/creator/:id` → 03).
- `src/components/layout/Footer.tsx` — index columns incl. "The room — a spatial walk"
  (`/room`, the deep archive, reachable from every page).
- `src/components/layout/SearchOverlay.tsx` — editorial search: dims the archive with
  context preserved, real registry folio №s, ↑/↓/Enter pulls, Esc returns, `/` opens
  from anywhere, focus restored to opener.

**Data (ground truth — NEVER invent content):**
- `src/data/content.ts` — the registry: `ARTICLES` (19), `AUTHORS` (16), `CATEGORIES` (8
  incl. reserved), `COMMUNITY_STATS`, `COMMUNITY_VOICES`, `BRAND` (incl. `ambassadorForm`,
  `team` — 12 people), `NAV_LINKS`/`MENU_LINKS`/`DOCK_LINKS`; helpers `getArticle`,
  `getAuthor`, `authorPhoto`, `relatedArticles`.
- `src/lib/room/folios.ts` — the 19 canonical folio anchors (№01 Their Voices Matter …
  №19 Mir Raza Ali, newest).
- `src/data/articleEndings.ts` — closing copy for articles.

## 5. THE DESIGN SYSTEM (visual source of truth = Penpot Phase-19)

**Palette:** charcoal `#161412` · wine `#1E0B12`/`#2A0F18` · deep wine `#3B0D17` · wine
accent `#5C1224` · ivory `#F8F6F2` · cream `#EFE8DD`/`#E7DCC8`/`#C9BBA6` · brass
`#D9B978`/`#B89146`/`#7C6338` · faint `#8A8178`/`#5B544B` · rule `#3A332C`.

**Typography:** Cormorant Garamond (editorial/display) · Inter (body/interface) · IBM Plex
Mono (metadata: folio numbers, labels, hairlines).

**Materials/motifs:** ivory paper plates, brass hairlines & rules, warm light, subtle
grain-free gradients, generous negative space, framed imagery (`.img-frame`), ghost folio
numerals (stroke-only text), editorial metadata rows.

**Interaction vocabulary (use only where natural):** PULL → READ → RETURN (primary);
DISCOVER (move through archive) · FOCUS (isolate) · FOLLOW (brass thread) · OPEN (canonical
route) · BACK (spatially return) · ENTER · REVEAL · TURN · DESCEND · CONTINUE.

**Forbidden visual language:** neon, purple gradients, glassmorphism, floating blobs,
random particles, holograms, cyberpunk, generic SaaS cards/dashboards, excessive glow or
shadows, generic "3D website" effects, animation for its own sake.

**Motion:** GSAP = major choreographed sequences; Anime.js = micro-interactions (never both
on the same motion); Framer Motion = React state/UI; CSS 3D preferred for editorial plates
and archives; Three.js only where genuinely valuable. **No perpetual animation loops.**

## 6. ROUTE MAP — spatial metaphors

| Route | Room | Composition |
|---|---|---|
| `/` | The Entrance / The Cover | Ghost masthead + layered planes with scroll parallax (atmosphere/ghost/copy); feature plate in foreground; engraved ledger; SpatialArchive (protected) behind |
| `/articles` | The Archive — Shelves | **Three-shelf stacks** (desktop): 19 folios standing on receding shelves, focus approaches the reader; tablet portrait shelf; mobile one-plate vertical thread; search/category reorganize the archive spatially |
| `/article/:id` | The Reading Room | Wine threshold "Folio NN · Reading" → canonical ArticleDetail (protected) → ending/closing → "Up Next" |
| `/categories` | The Wings — Departments | Facade of seven department doors (depth/rotation); Wing 08 open seat; choosing a wing reorganizes the archive below |
| `/creators` | The Contributor Wall | 16 names as large typographic objects; focus/hover steps forward while wall recedes; dossier panel; folios → canonical articles; "Full profile" → /creator/:id |
| `/creator/:id` | The Dossier | Canonical writer profile (protected route structure, registry data) |
| `/ambassadors` | The People / Staff Room | 12 numbered diamond medallions in spatial clusters (Direction/Editorial/Outreach/Craft); focus opens record dialog (Esc/Tab-trap/focus-restore); open seat №13 → real application form |
| `/community` | The Commons | Real ledger engraved into the room, monumental real voices, draggable film-strip of real covers, transparency note, letter from the desk |
| `/about` | The Colophon | Editorial essay, values charter, milestones, founder conversation, **colophon imprint** (type/paper/ink/archive/people/practice) |
| `/submit` | The Editorial Desk | Send a Voice: I writer → II work → III piece → desk; guidelines; accessible HTML forms on a physical desk treatment |
| `/contact` | The Correspondence Desk | Wax-sealed letter (stationery), contact channels, quiet intimate |
| `/room` | The Deep Archive (reference) | The Keeping Room — **keep as-is**, the proven spatial prototype; 89/89 regression suite must stay green |

## 7. CONTENT INTEGRITY (absolute rule)

- **Never invent** articles, authors, stats, dates, bios, categories, quotes, images,
  people, or publication facts. The registry (`src/data/content.ts`) is authoritative.
- If data looks wrong → **STOP and report**, do not "fix" silently.
- Preserve all routes, canonical URLs (`/article/:id`, `/creator/:id`), article bodies,
  submission/contact functionality, search, newsletter, saved stories.
- 19 folios · 16 creators (Alina Javed founder; Anshujit Singh 3:13; Mir Raza Ali №19
  newest) · 8 categories (Stories, Poetry, Essays, Art, Social Issues, Lifestyle, Horror,
  + reserved) · 12 people in `BRAND.team` · ambassador form =
  `https://docs.google.com/forms/d/e/1FAIpQLSfwggEIWE-dPLoU2uL1bKkBA3mwFvEPGO05DrxyyKoHIBpAwA/viewform`.

## 8. PROTECTED FILES (byte-identical — 0 diffs enforced)

```
src/components/spatial/*           (SpatialArchive, StoryEnding3D)
src/lib/three/*                    (three infra: seed, spatialState, useWebGLSupport)
src/components/ui/ArticleClosing.tsx
src/components/ui/ArticleWorld.tsx
src/components/ui/Motifs.tsx
src/components/ui/VibeAmbient.tsx
src/pages/ArticleDetail.tsx
src/lib/motion.ts
src/index.css
package.json · package-lock.json · vite.config.ts
```
Baseline: `/tmp/protected-baseline.md5` (regenerated when needed; `/tmp` does not persist
between sessions — re-run the md5sum from §12 against the current verified state).

## 9. KEY FLOWS (validated end-to-end)

- **Article:** /articles → FOCUS folio (←/→) → Enter → wine threshold "FOLIO NN · READING"
  → canonical article → ending/Up Next → Back → archive restored (19 plates).
- **Category:** /categories → choose wing → members brighten/approach, non-members recede
  (spatial, never a list) → deselect restores all 19 → keyboard Tab/Enter works.
- **Creator:** /creators → dossier swap (e.g. Alina Javed → Anshujit Singh) → their folio →
  canonical article → return → "Full profile" → /creator/:id.
- **People:** medallion focus (Enter) → record dialog → Tab trap → Esc closes → focus
  restored to same medallion → real application link.
- **Search:** `/` or Ctrl/⌘K → archive dims with context → results carry №folio → ↑/↓/Enter
  pulls → Esc returns; typing `/` in an input does not trigger.
- **Navigation:** nested routes highlight parents; deep links; Back/Forward; no dead ends.

## 10. ACCESSIBILITY & DEGRADATION GUARANTEES

- Semantic equivalents for every spatial state (real `<a>`/`<button>`, `aria-label`,
  `aria-pressed`, `aria-current`, `role="dialog"` + focus management, `role="group"`
  keyboard stage).
- **prefers-reduced-motion:** same publication, motion collapsed, no perspective, all
  content present. Home parallax and all entrance entrances are gated.
- **No WebGL:** every route remains a complete editorial publication; SpatialArchive
  detects no-WebGL and recedes (CSS gradients fallback); Home has an error boundary so the
  entrance can never blank.
- Keyboard: ←/→/Enter/Esc on the shelf; Tab everywhere; visible focus; `/` for search.

## 11. PERFORMANCE ARCHITECTURE

- Route-split chunks; **Three.js isolated** in one lazy chunk — zero WebGL in the
  CSS-3D route chunks (Articles/Categories/Creators/Ambassadors/Community/About/Submit/
  Contact verified). `/room` isolated. Home lazy-loads SpatialArchive.
- No perpetual animation; cleanup-safe scroll/resize listeners; no canvas-per-card.

## 12. VALIDATION SUITES (run from `/home/user/verlyse-project` with dev server on :5173)

| Suite | Scope | Last result |
|---|---|---|
| `node audit/phase21-l-audit.mjs` | Full-site 288-check audit (walk, materials, flows, responsive, reduced, WebGL-off, quality A–E) | **272 PASS / 0 FAIL / 16 INFO** |
| `node audit/phase21-c-validate.mjs` | /articles archive (24 checks) | 24/24 |
| `node audit/phase21-de-validate.mjs` | article pull flow (7) | 7/7 (occasional timing flake — re-run; 304 = cache artifact, treat as pass) |
| `node audit/phase21-ghijk-validate.mjs` | wings/creators/people/search/rooms (45) | 45/45 |
| `node audit/phase205-validate-v2.mjs` | **/room reference (89)** — must never regress | 89/89 |
| `node audit/quality-visible.mjs` | visible-text crawl (no tech names / clichés) | PASS |
| `npx tsc --noEmit` | TypeScript | exit 0 |
| `npm run build` | Production build | ✓ ~7s |
| `md5sum -c /tmp/protected-baseline.md5` | Protected files | 0 diffs |

**Environment setup each session:** `npm install` (node_modules doesn't persist) · start
`npm run dev -- --host 0.0.0.0 --port 5173` · Chrome for Puppeteer needs system libs
(`sudo apt-get install -y libnspr4 libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2
libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libasound2
libpango-1.0-0 libcairo2 libatspi2.0-0 libx11-xcb1`) — binary persists at
`~/.cache/puppeteer`. Puppeteer flags: `--no-sandbox --disable-setuid-sandbox
--disable-dev-shm-usage`, `headless:'new'`, `waitUntil:'domcontentloaded'` (Home's Three
textures never settle `networkidle0`). If Vite serves stale transforms, `touch` the edited
files (watcher can lag in sandboxed sessions).

## 13. RULES OF ENGAGEMENT (do not violate)

1. **No deployment, ever** — no InfinityFree, kesug.com, verlyse-media.kesug.com, Vercel,
   DNS, FTP, or production credentials. Local/Arena/live-preview only.
2. **Never modify protected files** (§8) unless explicitly required and verified.
3. **Never invent content** (§7). Stop and report if data seems wrong.
4. **No new dependencies.**
5. /room is a reference implementation — do not copy its composition onto other routes;
   do not delete or flatten it.
6. Work route-by-route: build → run → inspect (real Chromium) → test → fix → report; do
   not advance on regressions.
7. Penpot is the design source of truth (not Figma).

## 14. HOW TO RUN (quick start)

```bash
cd /home/user/verlyse-project
npm install
npm run dev -- --host 0.0.0.0 --port 5173   # live preview on :5173
npx tsc --noEmit                             # typecheck
npm run build                                # production build
node audit/phase21-l-audit.mjs               # full-site audit (needs dev server up)
```

## 15. CURRENT STATE SNAPSHOT (2026-08-31)

- All Phase 21 + Phase 22 work **complete and green**: 288-check audit 0 FAIL, C 24/24,
  D/E 7/7, GHIJK 45/45, /room 89/89, tsc 0, build ✓, protected 0 diffs.
- Latest changes (Phase 22): three-shelf archive stacks, home scroll parallax, "The
  Wings" categories facade, "The Contributor Wall" creators, engraved commons ledger.
- Reports on file: `PHASE21-A-B-REPORT.md`, `PHASE21-C-K-REPORT.md`,
  `PHASE21-FINAL-AUDIT-REPORT.md`, `PHASE22-REPORT.md`, `GLOBAL-TRANSFORMATION-MAP.md`
  (route-by-route plan + status A–L), plus many earlier phase reports in `audit/`.

## 16. OPEN ITEMS / NATURAL NEXT STEPS

- No known defects. Remaining work is whatever the client directs next (e.g. deeper
  /article reading-room spatialization **without touching protected ArticleDetail** —
  possible via threshold/closing wrappers only; new content; additional tests).
- The /room disposition is settled: **keep as the deep-archive destination**, reachable
  from the footer, not in primary nav.
- If asked to change protected systems, treat it as a separate explicit workstream with
  its own verification.
