# Phase 21 — Slices C→K: The Keeping Room across the whole publication

*Verlyse Media — one immersive editorial world, route by route. Built → run → inspect → test → fix → report, per slice. No deployment. Protected files untouched (0 checksum diffs).*

---

## 1. Summary of results

| Suite | Scope | Result |
|---|---|---|
| `phase21-c-validate.mjs` | Slice C — /articles spatial archive | **24 / 24 PASS** |
| `phase21-de-validate.mjs` | Slices D/E — pull → threshold → article → back → return | **7 / 7 PASS** (×3 runs) |
| `phase21-ghijk-validate.mjs` | Slices G H I J K + responsive/reduced/WebGL-off | **45 / 45 PASS** |
| `phase205-validate-v2.mjs` | /room reference implementation regression | **89 / 89 PASS** |
| `md5sum -c /tmp/protected-baseline.md5` | 15 protected files | **0 diffs** |
| `tsc --noEmit` | TypeScript | exit 0 |
| `npm run build` | Production build | ✓ 6.16s |

Quality tests (visible-text crawl of all 12 routes): no visible “Three.js / WebGL / GSAP / Anime.js / MCP / AI website / neon / particles / glassmorphism / gradient blob”; every page title carries **Verlyse Media**; “The Keeping Room” appears only as the house practice line in the About colophon and on the untouched /room.

---

## 2. What changed, slice by slice

### C — /articles: the main archive (completed, then re-validated 24/24)
- New shared VerlyseWorld system: `src/lib/archive/geometry.ts`, `src/components/archive/FolioPlate.tsx`, `src/components/archive/ArchiveShelf.tsx`, `src/hooks/useArchiveLayout.ts`.
- `Articles.tsx` rebuilt: all **19 registry folios** on the brass thread as ivory plates — desktop arc, tablet two-column shelf, mobile one-plate vertical thread. Search + category reorganize the shelf **in place** (members brighten/approach, non-members recede to ghosts); editorial index, №20 reserved entry and closing footer retained.
- **Real bug found & fixed** (genuine a11y/P1 keyboard defect, not a test artifact): the shelf’s roving `tabIndex` changed the *visual* focus but not the DOM focus — ArrowRight moved the highlight but Enter pulled the *wrong folio* (browser focus stayed on the first plate). Fixed by moving real DOM focus via `linkRef` on arrows; the D/E harness now proves Enter hands off to the correct canonical article (№19 → `/article/mir-raza-ali`).
- Slice-C harness initial run: 22/24. Two fails were a real geometry conflict (visibility cap hiding far *member* plates during a filter) — fixed by making filter state override visibility in `geometry.ts` — plus two test-expectation artifacts (category membership must be read from plate text, bright threshold 0.3). Final: **24/24**.

### D/E — article pull/entry + reading integration (7/7)
- Verified the full flow: focus №19 → Enter → the wine threshold announces **“FOLIO 19 · READING”** → canonical ArticleDetail (`/article/mir-raza-ali`) renders → Back returns to `/articles` with all 19 plates restored → console clean. No duplicated body; ArticleDetail untouched (protected).

### G — /categories: the spatial index (not another card grid)
- The eight rooms (seven open + Room 08 drawn closed) become **door-plates that select a department**. Selecting a room reorganizes the spatial archive beneath it: matching folios brighten/approach on the same brass thread, the rest recede to ghosts (7 bright / 12 ghosts for Poetry), the heading restates the count (“7 folios on the thread”), deselect restores all 19. Keyboard: Tab reaches a room button, Enter selects.

### H — /creators: contributor archive + dossiers
- Replaced the card grid with an archival **name index** (16 real contributors, numbered, folio counts from the registry) + a **dossier panel** (canonical portrait, role, handle, bio, and their folios as plates on the thread → canonical article). “Full profile →” hands off to `/creator/:id`. Dossier swaps verify: Alina Javed → Anshujit Singh. All data from the registry; nothing invented.

### I — /ambassadors: the room of people
- The people become an **archival gallery of numbered diamond medallions** (the same diamond that signs every feature), grouped spatially into Direction / Editorial / Outreach / Craft. The 13th diamond is the **open seat** — the next ambassador, linked to the real application form. Selecting a medallion **FOCUSes** it and opens the person’s record as a dialog.
- **A11y fix added during validation**: the record dialog now has Escape-to-close, focus moved to the close button on open, focus restored to the medallion on close, and a Tab trap.

### J — search: the index placed above the dimmed archive
- Search (Ctrl+K, ⌘K, or **/**) is an editorial operation: the archive **dims but keeps its context** (“opened from the rooms…”), and the results are the **index above it**, each carrying its real registry folio № (№05 Hope Becomes Mythology…). Keyboard: ↑/↓ move the roving index, **Enter pulls the folio** to the canonical article, Esc returns and restores focus to the opener. `/` opens from anywhere unless you are typing.

### K — the four rooms, each its own metaphor (no copies of /articles)
- **/community — The Commons**: real ledger numbers, monumental voices from the feed, the draggable film-strip reel of the 19 real covers, and a letter from the desk. (Retained — already distinct.)
- **/about — The Colophon**: added the missing **colophon imprint** — set in Inter / Cormorant Garamond / IBM Plex Mono; paper & ink (ivory, charcoal, wine, brass); the archive opened 26.06.2026; the twelve people; the practice (“every voice credited, every tool disclosed, nothing invented”). Real facts only.
- **/submit — Send a Voice**: writer → work → piece, delivered to the desk, credited by name. (Retained.)
- **/contact — The Desk**: the wax-sealed letter and the desk’s channels. (Retained.)
- Distinct headings across all four verified.

### Responsive / reduced-motion / no-WebGL (all pass)
- Mobile 390×844: /categories keeps all 19 plates, no overflow; mobile vertical thread from Slice C.
- Tablet 768×1024: /creators, no overflow.
- prefers-reduced-motion: same 12 medallions, same publication (no perspective, quiet arrangement).
- WebGL off: /community still a full publication, console clean.

---

## 3. Files created / modified this phase

**New (shared VerlyseWorld):**
- `src/lib/archive/geometry.ts` — deterministic shelf geometry (arc / tablet shelf / mobile thread), filter-aware member/non-member states, reduced-motion quiet arrangement
- `src/components/archive/FolioPlate.tsx` — ivory editorial plate unit (semantic `<a>`, aria-label, ghost numeral)
- `src/components/archive/ArchiveShelf.tsx` — spatial stage: brass thread, keyboard attention (←/→/Enter/Esc), real DOM-focus sync, visibility limits
- `src/hooks/useArchiveLayout.ts` — resize-aware layout state

**Rewritten routes:**
- `src/pages/Articles.tsx` (C), `src/pages/Categories.tsx` (G), `src/pages/Creators.tsx` (H), `src/pages/Ambassadors.tsx` (I)
- `src/pages/About.tsx` (K — colophon imprint added)

**Upgraded:**
- `src/components/layout/SearchOverlay.tsx` (J — registry folio №s, context line, ↑/↓/Enter, `/` opener)
- `src/components/layout/Header.tsx`, `src/pages/Home.tsx`, `src/App.tsx` (Phase A/B — unchanged this slice, still green)

**Audit:**
- `audit/phase21-c-validate.mjs`, `audit/phase21-de-validate.mjs`, `audit/phase21-ghijk-validate.mjs` + `-results.json`
- `audit/quality-visible.mjs` (visible-text quality crawl), screenshots in `audit/shots/`

---

## 4. Protected files — untouched
`src/components/spatial/*`, `src/lib/three/*`, `ArticleClosing.tsx`, `ArticleWorld.tsx`, `Motifs.tsx`, `VibeAmbient.tsx`, `src/pages/ArticleDetail.tsx`, `src/lib/motion.ts`, `src/index.css`, `package.json`, `package-lock.json`, `vite.config.ts` — 0 checksum diffs.

## 5. Next — Slice L
Full-site coherence walk + final regression audit (all suites already green), then decide /room disposition. No deployment.
