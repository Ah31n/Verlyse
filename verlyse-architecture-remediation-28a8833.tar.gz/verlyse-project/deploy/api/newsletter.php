<?php
/**
 * Verlyse Media — "The Verlyse Letter" newsletter signup (InfinityFree mirror).
 *
 * PHP port of the Vercel serverless function api/newsletter.ts:
 * adds an email to the Buttondown subscriber list. The API key lives ONLY in
 * this server-side file — never in client code. InfinityFree has no Node
 * runtime, so kesug.com serves this PHP endpoint at /api/newsletter
 * (see .htaccess rewrite in this directory).
 *
 * Contract (identical to the Vercel function):
 *   POST { "email": "…" }  →  201 {"ok":true}
 *                              200 {"ok":true,"duplicate":true}
 *                              200 {"ok":true,"blocked":true}
 *                              400 {"error":"invalid-email"}
 *                              405 {"error":"method-not-allowed"}
 *                              429 {"error":"too-many-requests"}
 *                              502 {"error":"provider"}
 */

// Single source of truth for the key on this host.
const BUTTONDOWN_API_KEY = '5ffb1d92-d4a3-4510-bcbc-e1105275ef15';

const RATE_LIMIT = 10;          // requests per window per IP
const RATE_WINDOW_MS = 60000;   // 1 minute

function header_json() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Content-Type: application/json');
}

function json_out($code, $body) {
    http_response_code($code);
    header_json();
    echo json_encode($body);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    header_json();
    http_response_code(204);
    exit;
}
if ($method !== 'POST') {
    json_out(405, array('error' => 'method-not-allowed'));
}

// --- client IP + sliding-window rate limit (per-IP counter file) ---
function client_ip() {
    $fwd = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : '';
    if ($fwd !== '') {
        $first = trim(explode(',', $fwd)[0]);
        if ($first !== '') return $first;
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
}

function rate_limited($ip) {
    // Sanitize: only the IP string is ever used in a filename.
    $id = md5($ip);
    $dir = sys_get_temp_dir();
    $file = $dir . '/verlyse-nl-' . $id . '.json';
    $now = (int) (microtime(true) * 1000);
    $count = 0; $resetAt = 0;
    if (is_file($file)) {
        $raw = @file_get_contents($file, false, null, 0, 0, null);
        if ($raw === false) $raw = '';
        $rec = json_decode($raw, true);
        if (is_array($rec) && isset($rec['count'], $rec['resetAt'])) {
            $count = (int) $rec['count'];
            $resetAt = (int) $rec['resetAt'];
        }
    }
    $fh = fopen($file, 'c+');
    if ($fh !== false) {
        if (flock($fh, LOCK_EX)) {
            if ($resetAt <= $now) {
                $count = 1; $resetAt = $now + RATE_WINDOW_MS;
            } else {
                $count += 1;
            }
            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, json_encode(array('count' => $count, 'resetAt' => $resetAt)));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }
    return $count > RATE_LIMIT;
}

if (rate_limited(client_ip())) {
    json_out(429, array('error' => 'too-many-requests'));
}

// --- validate email (same rule as the client and the Vercel function) ---
$body = file_get_contents('php://input');
$data = json_decode($body, true);
$email = is_array($data) && isset($data['email']) ? strtolower(trim((string) $data['email'])) : '';
if (!preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email)) {
    json_out(400, array('error' => 'invalid-email'));
}

if (BUTTONDOWN_API_KEY === '' || BUTTONDOWN_API_KEY === '__PENDING__') {
    json_out(503, array('error' => 'not-configured'));
}

// --- deliver to Buttondown ---
$ch = curl_init('https://api.buttondown.email/v1/subscribers');
curl_setopt_array($ch, array(
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(array('email_address' => $email)),
    CURLOPT_HTTPHEADER => array(
        'Authorization: Token ' . BUTTONDOWN_API_KEY,
        'Content-Type: application/json',
    ),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
));
$response = curl_exec($ch);
if ($response === false) {
    curl_close($ch);
    json_out(502, array('error' => 'provider'));
}
$status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

if ($status >= 200 && $status < 300) {
    json_out(201, array('ok' => true));
}

// Duplicate addresses are not an error — the address is already on the list.
if ($status === 400 || $status === 409) {
    if (preg_match('/already|exist|subscribed|duplicate|collision/i', (string) $response)) {
        json_out(200, array('ok' => true, 'duplicate' => true));
    }
    // Provider spam firewall declined the address (spam-trap / disposable).
    if (preg_match('/blocked|firewall|spam/i', (string) $response)) {
        json_out(200, array('ok' => true, 'blocked' => true));
    }
}
json_out(502, array('error' => 'provider'));
