# PHASE 19 — THE KEEPING ROOM · FULL A–Z HANDOFF REPORT

**Project:** Verlyse Media (React 18 + Vite + TypeScript + Tailwind, react-router, framer-motion, three.js).
**Phase objective:** redesign Verlyse as an *immersive spatial editorial publication* — "The Keeping Room": 19 real feature articles rendered as ivory editorial plates on a restrained brass thread inside a dark archive; the reader's attention drives focus. Vocabulary: **PULL → READ → RETURN**. Must feel like entering a physical archive, NOT a generic WebGL/AI 3D site.
**Working order:** DESIGN FIRST (in Penpot) → review → implement → validate. **No Figma. No deployment. No production changes.**
**Date of report:** 2026-08-30.

---

## 1. Final status at a glance

- **DESIGN GATE: COMPLETE.** A real **Penpot** artifact exists with **16 frames** (1 design-system board + 15 states incl. tablet & mobile), each visually verified by PNG export.
- **Implementation (`/room` vertical slice): BUILT in an earlier step and left untouched/isolated.** It was already present and verified; this session did not modify it.
- **Build: PASSES** (`tsc -b && vite build` → `✓ built in ~7s`). Room is a lazy **14.2 kB** chunk; `three` (770 kB) is code-split and **not imported by the room slice**.
- **Protected files: present and unmodified** (checksums recorded — §8).
- **Dependencies:** installed with `npm ci` (lockfile honored, zero added/changed).
- **Deployment:** none. Nothing touched on InfinityFree / kesug.com / Vercel / DNS.

---

## 2. What the design contains (the 16 Penpot frames)

Penpot file, page set named **"P19 · THE KEEPING ROOM"** — 16 pages, one frame each:

| # | Frame | PRIMARY attention | SECONDARY | AMBIENT |
|---|---|---|---|---|
| 00 | MATERIALS · DESIGN SYSTEM | system board | — | palette/type/plate/thread/lighting/format |
| 01 | ARRIVAL | "The Keeping Room" title + PRESS ENTER | ghost folio **19** | wine threshold, dim edge plates, brass rule |
| 02 | ARCHIVE DISCOVERY | plate **№01 Their Voices Matter** (brightest, brass edge) | plates 19/18…02 receding on an arc | brass thread, charcoal room |
| 03 | ARTICLE FOCUS | №01 plate enlarged face-on | neighbour plates as dark silhouettes | dim room, thread brightens |
| 04 | FOCUS SETTLE | settled №01 plate (title/byline/date) | two faint edge plates | ENTER → / RETURN ← |
| 05 | ARTICLE ENTRY | article hero on wine | VERLYSE masthead | room fades to the page |
| 06 | READING | canonical article body (Alina Javed) | pull quote, progress rule | note: ArticleDetail owns reading |
| 07 | ENDING | closing line + signature "— Alina Javed" | ghost **01** | room re-forms |
| 08 | NEXT | **№19 Mir Raza Ali** plate (newest) | dimmed №01 / №02 | "next on the thread" |
| 09 | RETURN | archive restored, №01 marked **READ ✓** | neighbouring plates | attention released |
| 10 | CATEGORY | Poetry — 7 folio plates on the thread | category count | "never becomes a list view" |
| 11 | CREATOR DOSSIER | "Alina Javed" contributor record | her 2 folios + open rows | dossier = canonical creator route |
| 12 | SEARCH | search field "voice" + №01 result | dimmed plates behind | overlay over the room, ESC returns |
| 13 | AMBASSADORS / PEOPLE | 8 real contributor cards | numbered medallions | decision: ROOM → canonical `/ambassadors` |
| 14 | TABLET 768×1024 | №01 + №19, two-column portrait shelf | next four plates | composed for portrait, not scaled |
| 15 | MOBILE 390×844 | one plate in hand — №19 Mir Raza Ali | №01 / №09 stacked below | reduced depth, thread vertical |

Every frame carries a mono state-label (`STATE · NN / 15 · …`) documenting the interaction/decision.

**Design system (board 00):**
- Type: **Cormorant Garamond** (display/title/pull-quote), **Inter** (sparing body), **IBM Plex Mono** (folio labels/metadata, +tracking).
- Palette: charcoal room `#161412`; wine panel/deep/main `#1E0B12 / #2A0F18 / #5C1224`; ivory plate `#F8F6F2`; cream `#EFE8DD`; paper edge `#E7DCC8`; brass `#B89146` / brass-hi `#D9B978` / brass-dim `#7C6338`; faint `#8A8178`; rule `#3A332C`; ink `#241D18`.
- Spatial: ivory editorial plates (1–3px brass hairline, upright, contact shadow), a single ruled brass thread, warm reader-lamp key light, depth via neighbour attenuation (scale + opacity + arc). Plate states REST / HOVER / FOCUS / SELECTED.
- Editorial: folio №, category, byline, contributor, signature, tags — all mono/quiet.
- Interaction states: idle/rest, hover, focus, selected/entered, reading, returning, reduced-motion.

**Content discipline:** real registry only, nothing invented. Featured **№01 Their Voices Matter / Alina Javed / Social Issues**; newest **№19 Mir Raza Ali / Verlyse Media**. Registry order unchanged. Real authors/categories used in discovery, category (Poetry folios), dossier (Alina Javed's two folios) and ambassadors.

**Route/scope decisions documented in-frame:**
- Reading → canonical **ArticleDetail** (room hands off, never duplicates).
- Ending → established StoryEnding3D / ArticleClosing / signature language.
- Search → **overlay over the dimmed room** (not forced into 3D); ESC returns.
- Ambassadors/People → **ROOM → canonical `/ambassadors`**; the room is an entrance/discovery layer, not a replacement.
- Tablet/mobile are **intentional compositions** (portrait shelf; one-plate-in-hand), not scaled desktop.

**Tool allocation:** Penpot = sole design surface. OriginKit/Watermelon/Kokonut/Coconut/Vengeance/Skiper reviewed as references only, none imported. GSAP reserved for choreographed transitions; Anime.js for micro-interactions (never both on one motion). Three.js stays isolated in the room slice; zero new deps.

**Two critical tests — both PASS:**
- Test A (remove 3D): every frame is a deliberate editorial composition (serif hierarchy, brass rules, ivory plates, mono metadata, real bylines) → still a highly-designed publication.
- Test B (remove Verlyse type/materials/story): no blobs/particles/neon/glassmorphism/generic WebGL hero; structure is titled folios on a brass thread → does not read as a generic AI-3D site. Graceful no-WebGL 2D fallback is inherent.

---

## 3. The hard problem (and its root cause + fix) — for the AI handoff

This is the part worth knowing if the work is continued.

**Symptom:** Boards created through the Penpot MCP `execute_code` plugin API existed in the document model (correct names, positions, fills, fonts, parent links) but **exported blank** — only the board's own background fill rasterized; child rectangles/text did not. The very first board built in the original session (the Materials board) rendered fully; everything built later did not.

**Things ruled out (each tested):**
- Not page position / off-canvas (cloned a rendering board far off-canvas → still rendered).
- Not stale session alone (a full tab-reload + reconnect with a brand-new connection id did not fix new shapes).
- Not fonts/helpers (Materials used the same helper and rendered; a diagnostic board showed text geometry/`growType` wrapping correctly).
- Not "first board per call" (two boards in one call both blank).
- Cloning a rendering board rendered the *cloned* children, but children *newly created and added* to the clone did **not** rasterize.

**Root cause (empirically established):**
1. **Newly-created child shapes rasterize at *page-absolute* coordinates**, not board-relative. A child placed at board-local `(x,y)` lands at page `(x,y)`. So a child only lines up with its board if the **board sits at page origin (0,0)**. On an offset board (e.g. the materials column at x=1840), children render at the wrong page location and get clipped → blank export.
2. **`clipContent=true` + children outside the board's page-bounds = clipped to nothing.** With `clipContent=false`, children appeared (proving they existed) but were offset.
3. Text needs a **settle delay (~1s) after creation** before `board.export()` rasterizes it (fonts/wrapping commit asynchronously); exporting immediately after building dropped the text even when rects rendered.

**Working solution (reliable, repeated for all 15 frames):**
- Put **one frame board per Penpot page, at page (0,0)**, sized to the viewport (1440×900 / 768×1024 / 390×844).
- Set the board **`clipContent=true`** (children then render *and* clip exactly to frame bounds → clean exact-size PNG).
- Build all content with board-local coordinates (== page coordinates since board is at origin).
- **Wait ~1.2s after the last shape, then call `await board.export({type:'png',scale})`** in a *separate* MCP call from the build (two-phase: build call, then export call) to avoid intermittent in-call export hangs.
- Decode the exported PNG byte array to base64 manually inside Penpot (`btoa` existed but a hand-rolled base64 over the byte array was used for reliability) and write the file in Node.

Result: every frame exports as an exact-size RGB PNG with full content.

**Operational notes:**
- Creating many pages in a tight loop can make the in-call `export` hang (page sprawl). Mitigation: build a frame → export it in its own call → retry export once or twice if it returns empty; periodically delete scratch/duplicate pages via `page.remove()`.
- The MCP stream URL lives in `/home/user/.mcp.json` under `mcpServers.penpot.url` (`https://design.penpot.app/mcp/stream?userToken=…`). The Penpot tab must stay open with **File → MCP Server → Connect**.

---

## 4. Where everything lives (workspace paths)

**Penpot build tooling** (in `/home/user/.figma-oauth/`):
- `pp-helpers.js` — `PP` helper: palette `PP.C`, font consts (`SERIF/SANS/MONO`), methods `board/rect/text/rule/plate`.
- `pp-frame-header.js` — `newFrame(label,w,h,bg)` (creates a fresh page + one board at 0,0 with clip=true), `exportB64()`, shared `FOLIOS` array (the 19 real articles), `kicker()/tag()/card()`.
- `pp-build-run.mjs <body.js>` — runs a frame **build** (no export).
- `pp-export-page.mjs <out.png> [scale]` — **exports** the board on the current page to PNG.
- `pp-frame-run.mjs` — combined build+export (used early).
- `fr/f01.js … fr/f15.js` — one file per state frame (the actual frame content).
- `pp-a-materials.js` … `pp-e-1415.js` — earlier (offset-board) build scripts; superseded by the per-page `fr/` approach.

**Evidence images** (in `/home/user/p19-shots/`):
- `fr-00-materials.png` (== `new-materials.png`) — design-system board.
- `fr-01.png … fr-13.png` — 1440×900 desktop states.
- `fr-14.png` — tablet (1536×2048 @2x of 768×1024).
- `fr-15.png` — mobile (780×1688 @2x of 390×844).
- `sheet-a.png` (states 01–08) and `sheet-b.png` (09–15 + tablet/mobile) — contact sheets.

**Docs** (in `/home/user/verlyse-project/`):
- `PHASE19-PENPOT-DESIGN-GATE.md` — design-gate report (states, system, decisions, tests).
- `PHASE19-KEEPING-ROOM.md` — earlier Phase 19 report / `/room` spec reference.
- `PHASE19-HANDOFF-REPORT.md` — this file.

**Validation artifacts** (in `/home/user/p19-validation/`):
- `protected-checksums.txt` — md5 of all protected files (see §8).

**The `/room` implementation (built earlier, isolated, untouched this session):**
- `src/lib/room/` — `folios.ts` (real registry folios), `state.ts` (ARRIVAL→…→RETURN), `geometry.ts` (plate transforms + `layoutForWidth` for tablet/mobile).
- `src/components/room/` — `Room.tsx`, `Plate.tsx`, `BrassThread.tsx`.
- `src/pages/Room.tsx`; lazy route in `src/App.tsx` **outside** `<Layout>` (`isRoom` check at line ~62; `<Route path="/room">` at line ~70).
- Uses framer-motion (`useReducedMotion` honored) + react-router; **no `three` import** in the room slice (2D editorial composition → degrades gracefully with no WebGL).

---

## 5. Protected files (must never be modified)

Confirmed present at their real paths and untouched:
- `src/components/spatial/SpatialArchive.tsx`
- `src/components/spatial/StoryEnding3D.tsx`
- `src/components/ui/ArticleClosing.tsx`
- `src/components/ui/ArticleWorld.tsx`
- `src/components/ui/Motifs.tsx`
- `src/components/ui/VibeAmbient.tsx`
- `src/pages/ArticleDetail.tsx`
- `src/lib/motion.ts`
- `src/index.css`
- `package.json`, `package-lock.json`, `vite.config.ts`
- (Also protected: `src/components/spatial/*`, `src/lib/three/*`.)

No camera choreography or production spatial-system changes were made. All new spatial work is isolated under `src/components/room/` + `src/lib/room/`.

---

## 6. Build result

```
npm ci   → added 262 packages from lockfile (no dependency changes)
npm run build  →  tsc -b && vite build  →  ✓ built in ~7s
  Room-*.js            14.20 kB │ gzip  4.63 kB   (lazy)
  ArticleDetail-*.js   56.80 kB │ gzip 13.24 kB   (lazy)
  three-*.js          770.45 kB │ gzip 203.46 kB  (code-split, not in room path)
  motion-*.js         122.86 kB │ gzip 40.91 kB
```
Only warning: the pre-existing `three` chunk > 700 kB (expected; it's already dynamically imported and unrelated to the room slice). No TypeScript errors.

---

## 7. Validation status (§20/§22 of the directive)

- **Build result:** PASS (§6).
- **Protected-file integrity:** recorded checksums; no edits made (§5, §8).
- **Three breakpoints (1440×900 / 768×1024 / 390×844):** designed frame-by-frame in Penpot and exported (§2). The `/room` code already uses `layoutForWidth` for responsive composition.
- **Reduced motion:** room uses framer-motion `useReducedMotion`; design documents a reduced-motion state.
- **WebGL unavailable:** the room slice is 2D (no `three` import) → it renders as a flat editorial archive by construction; canonical routes are unaffected.
- **Keyboard / deep links / hard refresh / console errors / overflow / failed requests:** these runtime browser checks were **not** re-run this session (dev server not left running). They were verified in the earlier `/room` session; re-run with `npx vite --host 0.0.0.0 --port 5199` and exercise `/room` if a fresh pass is wanted.
- **Deployment:** none.

---

## 8. Protected-file checksums (md5, baseline)

```
ba4f8b4a63cff9883875365f68ecf55a  src/components/spatial/SpatialArchive.tsx
074074b853441f6ea51a88ce7938a9a5  src/components/spatial/StoryEnding3D.tsx
4df70edf30c8d400a995927c8a5a48b8  src/components/ui/ArticleClosing.tsx
084fb3fea912fd800be828f8ec11a2d6  src/pages/ArticleDetail.tsx
ee1236f72c985afe5e62cad410dc63ce  src/components/ui/ArticleWorld.tsx
12c4962853e0b00d4021f36485e7bbe1  src/components/ui/Motifs.tsx
f52fcea816a600d621314e92bc41708d  src/components/ui/VibeAmbient.tsx
43ab8cc376a3cdccb5031529bf3a5b07  src/lib/motion.ts
4a50893d8046e86c50928f306e19d6b3  src/index.css
c0c71e667d77af71de4ae3742a9fd2b7  package.json
a66edfdda7793645fa00835f9a5c38d5  package-lock.json
108eae41e2acfb8c3f96a55bcf3db849  vite.config.ts
```

---

## 9. Final acceptance questions

- Could this have been designed specifically for Verlyse? **YES** — real registry, Cormorant/brass/ivory system, archival metaphor throughout.
- Does the spatial system improve editorial storytelling? **YES** — attention isolates one voice; the thread carries the reader PULL→READ→RETURN.
- Does it feel like a publication, not a tech demo? **YES.**
- Does the reader understand what to do? **YES** — PRESS ENTER, PULL THE PLATE, NEXT ON THE THREAD, ESC to return.
- Beautiful without WebGL? **YES** — the room is a 2D editorial composition; frames pass Test A.
- Mobile / tablet intentionally designed? **YES** — distinct portrait compositions, not scaled desktop.
- Existing Verlyse systems preserved? **YES** — protected files untouched; ArticleDetail/StoryEnding/Ambassadors remain canonical.
- Deployed anything? **NO.**

**Guiding order maintained:** Verlyse first · publication second · spatial third · motion fourth · technology last.
