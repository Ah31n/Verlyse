# PHASE 29 — VERLYSE MEDIA · DOSSIER + READING ROOM IMPLEMENTATION REPORT

**Verlyse Media — Where Vision Becomes A Voice** · 1 September 2026
Scope: implement the two approved Phase-25 Penpot spaces — **THE DOSSIER** (`/creator/:id`) and **THE READING ROOM** (`/article/:id`) — faithfully, using the registry as content authority and the existing architecture as canonical. No redesign, no reinterpretation, no deployment. **DONE — ALL GREEN.**

---

## 1 · Verdict

**PASS.** Both spaces were inspected against their approved Phase-25 boards, verified in real Chromium at all four viewports (1440×900 / 768×1024 / 390×844 / reduced), and validated by new Phase-29 harnesses plus every standing regression suite. The implementation carries forward the Phase-26 build (which reproduced these boards), now hardened by this phase's independent harnesses, the corrected **mobile RETURN placement** (board-mandated order), and the **quiet mobile/tablet Reading-Room furniture** (faint rule, small ghost folio, thread stub, fold cue) that was missing.

## 2 · Files created

| File | Purpose |
|---|---|
| `audit/phase29-dossier-validate.mjs` | 29A harness — all 16 creator routes, Alina's record, second-creator/no-hardcoding probe, tablet/mobile/reduced/WebGL-off, keyboard. |
| `audit/phase29-reading-room-validate.mjs` | 29B harness — canonical routes, BACK/MID/FRONT, scroll thread, tablet/mobile/reduced/WebGL-off, history. |
| `audit/shots/phase29/` (12 captures) | `dossier-{desktop,tablet,mobile,reduced,webgloff,focus}.png` · `reading-{desktop,tablet,mobile,reduced,webgloff,thread}.png` |

## 3 · Files modified

| File | Change |
|---|---|
| `src/components/dossier/DossierRoom.tsx` | Mobile RETURN moved to the end of the dossier (board's mandated mobile order); top-left `← THE CONTRIBUTOR WALL` now `md:`-only. |
| `src/components/reading/ReadingRoom.tsx` | Added the board's quiet mobile furniture (faint rule, small ghost folio `№ NN`, thread stub, dog-eared fold cue `Up next ↓`) and the tablet's single wall rule. |

No other source files changed. All 13 protected files + `/room` remain **byte-identical**.

## 4 · Protected-file status

`/tmp/protected-baseline.md5` (13 entries: `src/App.tsx`, `src/index.css`, `src/lib/motion.ts`, `src/components/spatial/SpatialArchive.tsx`, `src/components/spatial/StoryEnding3D.tsx`, `src/components/ui/ArticleClosing.tsx`, `src/components/ui/ArticleWorld.tsx`, `src/components/ui/Motifs.tsx`, `src/components/ui/VibeAmbient.tsx`, `src/pages/ArticleDetail.tsx`, `package.json`, `package-lock.json`, `src/pages/Room.tsx`) — **`md5sum -c` ALL OK**. The canonical article (`ArticleDetail.tsx`) was **not** modified; the Reading Room wraps it exactly as before. `/room` regression: **89/89**.

## 5 · Penpot fidelity assessment

- **THE DOSSIER (29A):** verified against `d1–d4` renders. Pixel/region analysis confirms the same composition family: a **standing ivory dossier sheet** (center 95% ivory) with **brass inner hairline**, the **portrait plate overlapping the sheet's left edge** (real registry photograph for Alina, monogram fallback otherwise), the **cream featured-folio plate overlapping the right edge** (`OPEN FOLIO →`), the **ghost monogram** engraved far behind, and the wine room with warm upper wash + brass lamp glow + dark floor + faint wall rules. Real data only — RECORD 01/16, `@lina_.jved`, real bio, №01 *Their Voices Matter* + №05 *Hope Becomes Mythology*; and **no hardcoding**: all 16 `/creator/:id` routes resolve, Zuha Farhan renders her own dossier with monogram fallback and her own first folio (№12).
- **THE READING ROOM (29B):** verified against `r1–r4`. The canonical article is the dominant FRONT; the room holds it: **BACK** wine architecture (lamp wash, dark floor, faint brass wall rules, ghost `№ 01` engraved behind the column), **MID** left vertical ledger `THE READING ROOM — FOLIO № 01`, right index `SOCIAL ISSUES · № 01 / 19`, corner registration ticks, the brass **thread** that draws with the reader plus the **reader-position mark**, and the **Up Next folio standing in the right gutter** (№12, canonical `related[0]`). The one documented difference is unchanged from Phase 26: the board draws the reading column in ivory; the canonical (protected) article is a wine publication with ivory type — the FRONT stays the untouched canonical article as the brief requires, and the room furniture conforms to the board exactly.
- **Reduced-motion boards (d4/r4):** verified pixel-near-identical to the settled desktop composition (dossier 0.0 diff; reading room 0.022 — the only delta is the reader-position mark, which the reduced board omits).

## 6 · Desktop (1440×900)

Both rooms full composition: dossier = wide wine room with sheet + two overlapping plates + vertical record ledger (`THE DOSSIER — RECORD № 01 / 16`); reading room = full architecture with ledger/thread/gutter. Zero horizontal overflow, zero console errors, zero failed image requests, one `h1` per page, canonical URLs.

## 7 · Tablet (768×1024)

Intentional recompositions, never scaled desktop: dossier = one wall rule, portrait overlaps the sheet edge, featured folio horizontal, compressed metadata; reading room = simplified room with the single wall rule, gutter folio recedes, article intact. One `h1`, no overflow, console clean, no failed image requests.

## 8 · Mobile (390×844)

**Dossier — mandated order verified:** `DOSSIER → NAME → ROLE/HANDLE → PORTRAIT → BIO → FEATURED FOLIO → RETURN`, with the RETURN now at the end of the sheet (corrected this phase). Minimal wine room, zero horizontal overflow, one focus target at a time.
**Reading room — vertical literary space:** quiet room (faint rule, small ghost folio `№ 01`, thread stub, fold cue `Up next ↓`) above the article; body readable, `#ending` intact, zero overflow.

## 9 · Reduced-motion result

Same compositions, movement removed: no parallax, no entrance transforms, thread static and full, no reader-position mark (per the r4 board), all content and navigation present. Verified content-complete at both routes with zero overflow and zero console errors; pixel-verified static against the settled desktop frame.

## 10 · Accessibility result

- One `h1` per route; canonical URLs intact; real links everywhere (`← THE CONTRIBUTOR WALL`, `OPEN FOLIO →`, gutter Up Next).
- Visible brass focus (`focus-visible` outlines) on all controls, verified in the harness.
- Archive keyboard grammar unchanged (`← → ↑ ↓`, Enter, Esc — the `/articles` phase-21 suite is 24/0).
- History: Back/Forward through the archive to the Reading Room verified.
- The global transition veil is `aria-hidden` and fixed — excluded from layout and focus.
- Reduced-motion media feature respected on both rooms.

## 11 · Validation counts

| Suite | Result |
|---|---|
| `phase29-dossier-validate.mjs` (new) | **28 PASS / 0 FAIL / 5 INFO** |
| `phase29-reading-room-validate.mjs` (new) | **33 PASS / 0 FAIL / 6 INFO** |
| `phase26-dossier-validate.mjs` (regression) | **26 / 0** |
| `phase26-reading-room-validate.mjs` (regression) | **63 / 0** |
| `phase21-c-validate.mjs` | **24 / 0** |
| `phase21-de-validate.mjs` | **7 / 0** |
| `phase21-ghijk-validate.mjs` | **45 / 0** |
| `phase205-validate-v2.mjs` (`/room`, mandatory) | **89 / 89** |
| `phase21-l-audit.mjs` (full-site) | **274 / 0 / 14 INFO** |
| `quality-visible.mjs` | **route mismatches: none** |

## 12 · TypeScript result

`./node_modules/.bin/tsc --noEmit` — **0 errors**.

## 13 · Build result

`npm run build` — **✓ built in 5.05 s** (pre-existing chunk-size advisory only).

## 14 · /room regression result

`phase205-validate-v2.mjs` — **89 / 89**. The Keeping Room is untouched (byte-identical) and remains the deep archive; neither route copies its composition.

## 15 · Known deviations

1. **Reading-column ivory vs wine** (unchanged from Phase 26, documented): the board draws the article as an ivory column; the protected canonical `ArticleDetail` is wine-dominant with ivory type. The FRONT is the canonical article per the brief; the room furniture conforms to the board.
2. **Canonical dispatch precedes the title on mobile** — the article's own `DISPATCH — 26.06.2026` kicker sits above the `h1`. The brief forbids rewriting the canonical article, so this order is preserved and the harness verifies FOLIO → TITLE → BODY among the room's own in-flow elements.
3. **Mobile order check uses the room's ghost folio** (`№ 01`) as the FOLIO marker — the article itself carries no separate in-flow folio line on mobile; the quiet-room furniture provides it per the board.
4. `phase29` harnesses assert exact registry content; where the registry lacks a portrait (e.g. Zuha Farhan), the monogram fallback + `the monogram` caption is the approved behaviour.

## 16 · Deployment status

**ABSOLUTELY NONE.** Local dev server only (`localhost:5173`); no DNS, hosting, Vercel, FTP, or production environment touched. Do not deploy.

---

**PHASE 29 COMPLETE — THE DOSSIER and THE READING ROOM implemented to the approved Phase-25 boards; every Phase-29 harness, standing regression, typecheck, and build green; protected files byte-identical; `/room` 89/89; no deployment.**
