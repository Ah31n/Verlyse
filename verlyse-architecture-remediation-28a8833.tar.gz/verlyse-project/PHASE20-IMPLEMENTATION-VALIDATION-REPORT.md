# PHASE 20 — The Keeping Room: Implementation + Validation Report

**Project:** Verlyse Media (global brand / publication / website)
**Layer:** The Keeping Room — immersive spatial discovery at `/room` only
**Positioning, as built:** *“VERLYSE MEDIA — The Keeping Room.”* The room is a Verlyse Media experience. It is **not** the site title, not a rebrand, not the homepage.
**Date:** 2026-08-30
**Method:** Implement the approved Phase-19 Penpot frames as source of truth → validate in a real browser (Playwright/Chromium) across viewports, accessibility modes, and the full vertical flow. No redesign. No deployment.

---

## 1. Brand & scope compliance (hard rules)

| Rule | Status | Evidence |
|---|---|---|
| Verlyse Media remains the global brand; room is branded *beneath* it | ✅ | Header reads `VERLYSE MEDIA` over `THE KEEPING ROOM` on every state/viewport; `<main aria-label="The Keeping Room — a Verlyse Media spatial archive">` |
| `/room` is spatial discovery/entrance only | ✅ | Reading always hands off to canonical `/article/:id`; room never renders article body |
| ArticleDetail & canonical systems untouched | ✅ | All 12 protected files byte-identical (§7) |
| No `/search` route replaced — search is an in-room overlay, ESC returns | ✅ | Search is a dimmed-room modal; its escape hatch links to canonical `/articles` (no `/search` route exists) |
| Category stays spatial — “never becomes a list” | ✅ | State 10 keeps folios on the brass arc; members bright, non-members recede to ghosts (no list layout) |
| Creator dossier links to canonical creator route | ✅ | Dossier panel → `/creator/:authorId`; People → `/ambassadors` |
| No new dependencies | ✅ | React, react-router-dom, framer-motion only; `package.json`/lock unchanged |
| No deployment / no credentials | ✅ | Work performed in local dev/build only |

**Edit scope (only these changed):** `src/lib/room/folios.ts`, `src/lib/room/state.ts`, `src/lib/room/geometry.ts`, `src/components/room/Room.tsx`, `src/components/room/Plate.tsx`. (`BrassThread.tsx`, `pages/Room.tsx`, `App.tsx` required no changes.) No protected file was edited.

---

## 2. What was implemented (gap closure vs. Phase-19 baseline)

The Phase-19 baseline already delivered states **01 Arrival → 02 Discovery → 03 Focus → 04 Settle**. Phase 20 added the remaining beats and discovery layers from the Penpot gate:

1. **Full PULL → READ → RETURN loop.** Pulling a plate marks the folio **READ ✓**, plays a short wine “opening” transition (state 05), then routes to the canonical article. A `sessionStorage` return-marker (`verlyse-room-return`) records which folio was open; on mount the room reads it and reforms at **state 07 Ending** (“the story returns to its place”). From there **NEXT** (state 08, previews folio №19) and **RETURN** (state 09, archive restored, thread counts “N folios read · the thread remembers”). READ badges persist across the article handoff for the session.
2. **State 10 · Category (spatial filter).** Category chips in discovery filter the brass thread in place — matching folios stay on the arc at full presence, non-members fade to near-invisible ghosts with pointer events removed. It is emphatically spatial; the header states *“the room never becomes a list.”* `geometry.ts` gained a `category` branch via a new `RoomTransformContext`.
3. **State 11 · Creator dossier.** A left-hand archival panel for the focused contributor lists their folios and offers **Full profile →** (canonical `/creator/:authorId`) and **Back to the room**. The author’s folios gather toward a centre shelf in 3D (`dossier` transform branch); non-members fly out.
4. **State 12 · Search overlay.** Dimmed-room modal (opened by the Search link or the `/` key), live title/author/category match (`searchFolios`, capped 6), Enter opens the top result, Esc returns. Explicitly an overlay over canonical search/browse.
5. **Data layer.** `Folio` now carries `authorId` (from the registry); added `CATEGORIES` (first-seen order), `foliosByAuthor(authorId)`, `searchFolios(query)`.
6. **State model.** Added overlay states `category` / `dossier` with labels/hints; they are deliberately **excluded** from `STATE_ORDER` so linear `nextState/prevState` never routes through them.
7. **Responsive composition (intentional, not scaled).**
   - **Desktop 1440×900:** horizontal brass thread, full-depth arc, left-aligned frame-01 arrival.
   - **Tablet 768×1024 portrait:** portrait shelf / two-column feel, reduced depth; arrival centred to clear the chrome.
   - **Mobile 390×844:** one-plate-in-hand, **vertical brass thread**, reduced depth, and — per frame 15 — **opens on the newest folio №19 (Mir Raza Ali)** with the NEWEST badge; secondary category chips are hidden on small screens to keep the composition quiet.
8. **Accessibility.** Full keyboard map (←/→ choose, Enter/pull, ↓/↑ focus↔discovery, `/` search, Esc backs out and closes modals), visible focus, `role="dialog"`/`aria-modal` on search, aria labels, and complete `prefers-reduced-motion` support (transitions collapse to near-instant; 3D perspective disabled).

---

## 3. The vertical flow (validated end-to-end)

`ARRIVAL → DISCOVERY → FOCUS → SETTLE → ENTRY → canonical ArticleDetail → ENDING → NEXT → RETURN`

Captured live (Playwright):
- PULL on folio №01 navigated to **`/article/their-voices-matter`** (canonical ArticleDetail).
- Browser **Back** returned to **`/room`**, which remounted at **Ending** with №01’s title/byline.
- **Return to archive** restored the thread; №01 now carries a brass **READ ✓** badge and the footer reads *“1 folio read · the thread remembers.”*
- Screenshots: `loop-06-article.png`, `loop-07-ending.png`, `loop-09-return.png`.

---

## 4. Validation matrix (all executed in Chromium via Playwright)

| # | Check | Viewport / mode | Result |
|---|---|---|---|
| 1 | Arrival (01) fidelity + brand order | desktop / tablet / mobile | ✅ `desktop-01`, `tablet-01`, `mobile-01` |
| 2 | Discovery (02) shelf/thread | all three | ✅ `*-02-discovery` |
| 3 | Focus (03) | all three | ✅ `desktop-03`, `tablet-03`, `mobile-03` |
| 4 | Settle (04) | desktop / tablet | ✅ `desktop-04`, `tablet-04` |
| 5 | Category spatial filter (10) | desktop | ✅ `desktop-10-category` — members bright, ghosts recede, never a list |
| 6 | Creator dossier (11) | desktop | ✅ `desktop-11-dossier` — Alina Javed, 2 folios, Full profile → `/creator/alina-javed` |
| 7 | Search overlay (12) | desktop | ✅ `desktop-12-search` — “voice” → Their Voices Matter; Esc returns |
| 8 | PULL→READ→RETURN loop | desktop | ✅ `loop-06/07/09`; READ ✓ persists |
| 9 | Horizontal **and** vertical overflow | every capture | ✅ **overflowX 0 / overflowY 0** everywhere |
| 10 | Console errors | every capture | ✅ **[]** |
| 11 | Failed network requests | every capture | ✅ **[]** |
| 12 | Reduced motion (`prefers-reduced-motion: reduce`) | desktop | ✅ `reduced-01/02`, 0 errors / 0 overflow |
| 13 | WebGL disabled (canvas WebGL context → null) | desktop | ✅ `webgloff-01/02`, 0 errors — room is pure CSS-3D/framer-motion, no `three` |
| 14 | Keyboard navigation | desktop | ✅ arrows/Enter/`/`/Esc drive all states and modals |
| 15 | Deep link / hard refresh on `/room` | desktop | ✅ HTTP 200, room remounts (`roomMounted: 1`) |
| 16 | Canonical routes resolve | desktop | ✅ `/article/their-voices-matter`, `/article/mir-raza-ali`, `/creator/alina-javed`, `/ambassadors` all 200 |
| 17 | Invalid article | `/article/does-not-exist-xyz` | ✅ Routed to app 200 shell; canonical not-found handling (no room change, no console error) |
| 18 | Mobile newest-first (frame 15) | mobile 390×844 | ✅ opens №19 Mir Raza Ali / Verlyse Media, NEWEST badge, “Pull folio 19” |

Screenshots are stored in `/home/user/p19-validation/shots/`.

---

## 5. Build & bundle

```
✓ 476 modules transformed.
dist/assets/Room-*.js   23.11 kB │ gzip: 6.94 kB
✓ built in ~6.6s
```

- `/room` is a **lazy** route → the room (and framer-motion) code-splits out of the main bundle.
- The room imports **no `three`/WebGL**; the large `three-*.js` chunk belongs to other pages and is not loaded on `/room`. WebGL-off is therefore inherently supported.
- TypeScript: `tsc --noEmit` → **0 errors**.

---

## 6. Design fidelity notes

Palette (wine/ivory/cream/gold/charcoal), Cormorant Garamond serif + Inter + IBM Plex Mono, the single brass thread (horizontal desktop/tablet, vertical mobile), ivory folio plates with ghost numerals, warm reader-lamp vignette, and the `.btn-gold/.btn-ghost/.btn-seal` system (reused from protected `index.css`, never edited) all match the approved frames. No neon, no particles, no generic-3D/AI aesthetic.

Two layout hardening fixes were made during validation (within scope, no design change): the arrival overlay was vertically centred on portrait/mobile so the large serif title clears the fixed header (desktop retains its frame-01 left alignment), and bottom control clusters gained mobile clearance and hide secondary category chips so controls never collide with the footer state line.

---

## 7. Protected-file integrity (byte-level)

`md5sum -c phase20-baseline-hashes.txt` → **all 12 protected files OK / unchanged**:

`SpatialArchive.tsx`, `StoryEnding3D.tsx`, `ArticleClosing.tsx`, `ArticleWorld.tsx`, `Motifs.ts`, `VibeAmbient.tsx`, `ArticleDetail.tsx`, `motion.ts`, `index.css`, `package.json`, `package-lock.json`, `vite.config.ts`.

No new dependency was installed; no production system, credential, or deployment target was touched.

---

## 8. Conclusion

The Keeping Room now implements the complete approved Penpot vertical — Arrival through Return — plus the Category, Creator-dossier, and Search discovery layers, as a **distinct spatial layer inside Verlyse Media**. It validates clean across all three intentional responsive compositions, reduced motion, WebGL-off, keyboard, deep-link/refresh, and the canonical article handoff/return, with **zero console errors, zero failed requests, and zero overflow** on every capture, all 12 protected files byte-identical, and a 6.94 kB gzip lazy chunk.

**No deployment performed.** Ready for the user’s review at the local dev server (`/room`).
