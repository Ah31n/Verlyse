# PHASE 19 — THE KEEPING ROOM

**Verlyse Media · spatial editorial archive.** Design first (Figma), implement second (`/room`), deploy never.
Priorities held: **Verlyse first · publication second · spatial third · motion fourth · technology last.**

Figma file: `QKhpsHWM1CDJa7vcl26dL7` ("Untitled") → page **"Phase 19 — The Keeping Room"**.
Link: https://www.figma.com/design/QKhpsHWM1CDJa7vcl26dL7/Untitled?node-id=0-1

---

## 1 · Design deliverables (Figma)

Built with the official Figma MCP (`use_figma`) over the authenticated session — **16 real frames**:

| # | Frame | Node | State |
|---|---|---|---|
| 00 | MATERIALS / DESIGN SYSTEM | `20:4` | palette, type, plate geometry, brass thread, lighting, material, metadata/contributors, interaction states, tablet & mobile adaptation |
| 01 | Arrival | `24:2` | threshold — archive dim, ghost 19, "PULL → READ → RETURN" |
| 02 | Archive Discovery | `24:16` | nineteen plates on the brass thread |
| 03 | Article Focus | `24:136` | one plate forward, room dim |
| 04 | Focus Settle | `24:153` | plate face-on, enter/return decision |
| 05 | Article Entry | `24:168` | room resolves into the article |
| 06 | Reading | `24:181` | canonical ArticleDetail + progress thread |
| 07 | Ending | `24:198` | close, room reforms |
| 08 | Next | `24:209` | newest plate offered — folio №19 Mir Raza Ali |
| 09 | Return | `24:228` | archive restored, read plate marked |
| 10 | Category Exploration | `24:311` | seven shelves |
| 11 | Creator Dossier | `24:351` | contributor + their plates |
| 12 | Search (Overlay) | `24:369` | room dims; canonical SearchOverlay |
| 13 | Ambassadors / People | `24:380` | people wall → /ambassadors |
| 14 | Tablet 768×1024 | `24:422` | intentional tablet composition |
| 15 | Mobile 390×844 | `24:504` | one plate legible, vertical thread |

**Design language** (derived from Verlyse's real tokens): charcoal `#161412`/wine `#1E0B12` room, ivory `#F8F6F2` plates, brass `#B89146` thread, Cormorant Garamond display + Inter body + IBM Plex Mono labels, ghost folio numerals, hairline rules, seal buttons. The 3D exists only to hold plates in readable space — a shelf, not a set-piece.

**Content**: uses the real registry — 19 folios in registry order; featured = №01 *Their Voices Matter*; newest = №19 *Mir Raza Ali* (remains folio №19). No data reordered or invented.

> **Note — Figma Starter write limit.** The Figma account is on the free Starter plan, which rate-caps `use_figma` **writes** (reads stay open). The first build (all 16 frames) landed; a refinement pass that tightens the Discovery/Tablet plate grid spacing is fully scripted (`.figma-oauth/step2-frames.js`) and ready to push the moment the write quota resets or the plan is upgraded. The implemented `/room` already reflects the corrected, non-overlapping arc.

## 2 · Tool allocation

- **Figma MCP** — primary visual environment (all frames above).
- **OriginKit MCP** — investigated (authenticated, 353 components). The catalog is dominated by high-motion Framer effects (blur/ring/sphere galleries, inkbleed cursors, starfield/typewriter effects) that directly contradict the quiet, archival brief → **nearly all discarded**. Two *patterns* retained conceptually and **re-implemented natively in Verlyse's language with zero new dependencies**: a restrained magnetic pull on the focused plate, and the archive's hover-to-preview emphasis. No OriginKit visual identity is imported.
- GSAP / Anime / Three.js / Watermelon·Kokonut·Coconut·Vengeance·Skiper UI — **not used**: the slice needs none; CSS-3D + framer-motion (already a dependency) carry the spatial feel. Avoided a needless 770 kB three chunk for this route.

## 3 · Implementation (`/room`, isolated)

New files only (no production spatial system touched):

```
src/components/room/Room.tsx        state machine + keyboard + overlays + handoff
src/components/room/Plate.tsx       editorial plate (ivory, brass hairline, ghost folio)
src/components/room/BrassThread.tsx the single binding rule (vertical on mobile)
src/lib/room/folios.ts              folio model derived from the canonical registry
src/lib/room/state.ts               PULL→READ→RETURN state machine
src/lib/room/geometry.ts            responsive CSS-3D plate placement
src/pages/Room.tsx                  full-screen page (mounted outside Layout)
```
`src/App.tsx` — one **additive** route: `/room` mounted outside the publication chrome (Header/Footer). Reading still hands off to the canonical **`/article/:id`** (ArticleDetail is never duplicated or touched).

Vertical slice wired end-to-end: **Arrival → Discovery → Focus → Settle → Entry → (canonical article) → Ending → Next → Return**, driven by keyboard (Enter / ← → / ↑ ↓ / Esc) and click/tap. Search and People link to the existing overlay and `/ambassadors` — the room is an entrance/discovery system, not a replacement for canonical routes.

## 4 · Test results

- **Build**: `tsc -b` clean; `vite build` ✓ (Room chunk **13.17 kB / 4.30 kB gzip**, contains **no WebGL/three**).
- **WebGL fallback**: by construction — no WebGL dependency; the room is CSS-3D and renders with hardware accel off.
- **Reduced motion**: `useReducedMotion` disables transitions/perspective; verified screenshot + flow.
- **Keyboard**: Enter advances, arrows move focus/selection, Esc returns — Playwright-verified.
- **Handoff**: read action navigates to `/article/:id` (verified URL change); no ArticleDetail duplication.
- **Console**: 0 errors across the flow.
- Screenshots in `/p19-shots`: `room-desktop.png` (1440×900), `room-tablet.png` (768×1024), `room-mobile.png` (390×844), `room-focus.png`, `room-reduced.png`.

Automated checks (all PASS): arrival heading · Enter→discovery · Arrow→focus 02 · Enter→settle/Read · Read→`/article/` handoff · no console errors · reduced-motion render.

## 5 · Protected-file integrity

Byte-diffed against the pristine uploaded archive:

```
IDENTICAL  src/components/spatial/ (dir)      IDENTICAL  src/lib/three/ (dir)
IDENTICAL  src/components/ui/ArticleClosing   IDENTICAL  src/components/ui/ArticleWorld
IDENTICAL  src/components/ui/Motifs           IDENTICAL  src/components/ui/VibeAmbient
IDENTICAL  src/pages/ArticleDetail            IDENTICAL  src/lib/motion.ts
IDENTICAL  src/index.css                      IDENTICAL  vite.config.ts
IDENTICAL  package.json (no new deps)         IDENTICAL  package-lock.json
PROTECTED_CHANGED_FLAG = 0
```

No camera choreography changes; no existing spatial system changes. **No deployment** — InfinityFree / kesug.com / Vercel / DNS untouched; everything lives in the sandbox live-review only.

## 6 · The critical design test

- *"If I removed the 3D, would this still feel like a carefully designed editorial publication?"* — **Yes**: the plates are ivory folios with serif titles, mono metadata, ghost numerals, and brass rules; hierarchy holds flat.
- *"If I removed the Verlyse typography/material language, would it look like another AI 3D site?"* — **No**: there are no blobs, particles, neon, glass, or generic WebGL hero; the only spatial element is an editorial shelf that dims around what you attend to.

Does this feel like **entering the Verlyse archive**? Yes.
