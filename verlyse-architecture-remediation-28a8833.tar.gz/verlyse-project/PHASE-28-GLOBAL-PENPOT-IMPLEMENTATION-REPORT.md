# PHASE 28 — GLOBAL PENPOT IMPLEMENTATION REPORT

**Verlyse Media — Where Vision Becomes a Voice** · 31 August 2026
Scope: implement the nine approved Phase-27 Penpot boards (ENTRANCE, ARCHIVE, WINGS, CONTRIBUTOR WALL, PEOPLE, COMMONS, COLOPHON, EDITORIAL DESK, CORRESPONDENCE DESK) into the existing React/Vite app, route by route, in the prescribed order — then the global coherence, responsive/reduced and full-site audit slices (28J/K/L). Penpot = visual authority; the registry (`src/data/content.ts`) = content authority; the existing architecture = canonical. No reinterpretation, no redesign, **no deployment**. **DONE — ALL GREEN.**

---

## 1 · Verdict

**PASS — every route implemented, every harness green, every standing regression suite green, typecheck and production build clean, protected files byte-identical.**

| Suite | Result |
|---|---|
| 28A entrance (`/`) | **33 / 0 / 5** |
| 28B archive (`/articles`) | **25 / 0 / 5** |
| 28C wings (`/categories`) | **19 / 0 / 4** |
| 28D wall (`/creators`) | **23 / 0 / 4** |
| 28E people (`/ambassadors`) | **24 / 0 / 4** |
| 28F commons (`/community`) | **25 / 0 / 4** |
| 28G colophon (`/about`) | **25 / 0 / 4** |
| 28H editorial desk (`/submit`) | **23 / 0 / 4** |
| 28I correspondence desk (`/contact`) | **28 / 0 / 4** |
| 28J/K/L global | **17 / 0 / 4** |
| Phase-21 L (full-site audit) | **274 PASS / 0 FAIL / 14 INFO** |
| Phase-21 C (archive regression) | **24 / 0** |
| Phase-21 D/E | **7 / 0** |
| Phase-21 GHIJK | **45 / 0** |
| `/room` (phase205-v2, mandatory) | **89 / 0** |
| `quality-visible.mjs` | **route mismatches: none** |
| `tsc --noEmit` | **0 errors** |
| `npm run build` | **✓ 6.59 s** |

## 2 · Route-by-route status

| # | Route | Board | Page | Status |
|---|---|---|---|---|
| 28A | `/` | THE ENTRANCE | `Home.tsx` | **DONE — ALL GREEN** (33/0) |
| 28B | `/articles` | THE ARCHIVE | `Articles.tsx` | **DONE — ALL GREEN** (25/0) |
| 28C | `/categories` | THE WINGS | `Categories.tsx` | **DONE — ALL GREEN** (19/0) |
| 28D | `/creators` | THE CONTRIBUTOR WALL | `Creators.tsx` | **DONE — ALL GREEN** (23/0) |
| 28E | `/ambassadors` | THE PEOPLE | `Ambassadors.tsx` | **DONE — ALL GREEN** (24/0) |
| 28F | `/community` | THE COMMONS | `Community.tsx` | **DONE — ALL GREEN** (25/0) |
| 28G | `/about` | THE COLOPHON | `About.tsx` | **DONE — ALL GREEN** (25/0) |
| 28H | `/submit` | THE EDITORIAL DESK | `Submit.tsx` | **DONE — ALL GREEN** (23/0) |
| 28I | `/contact` | THE CORRESPONDENCE DESK | `Contact.tsx` | **DONE — ALL GREEN** (28/0) |
| 28J | global coherence | — | audit + walk | **DONE — ALL GREEN** |
| 28K | responsive / reduced pass | all boards | sweeps | **DONE — ALL GREEN** |
| 28L | full-site visual audit | all boards | walk + captures | **DONE — ALL GREEN** |

The canonical walk `/` → `/article/their-voices-matter` → `/creators` → `/creator/alina-javed` → `/ambassadors` → `/categories` → `/community` → `/about` → `/submit` → `/contact` → `/room` verifies **one institution, visually distinct spaces** — 12/12 spaces distinct, each a different room of the same wine-and-ink architecture.

## 3 · Penpot fidelity assessment

Every route was built from its exact Penpot board text (ghost headers, subtitles, section labels, state rows, BACK/MID/FRONT planes, ANN notes) dumped from the Phase-27 evidence (`p27-texts.json`) and cross-checked against the board renders (`p27-shots/`). Headers, subtitles and section labels match the boards character-for-character; every structural placeholder was replaced with real registry values (19 ARTICLES, 16 AUTHORS, 7 CATEGORIES, 4 stats, voices, channels). The 28C compare vs `p27-wings-*` confirms the dark wine hall with brass doors and the stepped-forward story plate.

## 4 · Files created

| File | Purpose |
|---|---|
| `audit/phase28-entrance-validate.mjs` | 28A harness |
| `audit/phase28-archive-validate.mjs` | 28B harness |
| `audit/phase28-wings-validate.mjs` | 28C harness |
| `audit/phase28-wall-validate.mjs` | 28D harness |
| `audit/phase28-people-validate.mjs` | 28E harness |
| `audit/phase28-commons-validate.mjs` | 28F harness |
| `audit/phase28-colophon-validate.mjs` | 28G harness |
| `audit/phase28-desk-validate.mjs` | 28H harness |
| `audit/phase28-correspondence-validate.mjs` | 28I harness |
| `audit/phase28-global-validate.mjs` | 28J/K/L global harness |
| `audit/shots/phase28/*` | **43 captures** (per-route desktop/tablet/mobile/reduced, entrance & archive webgloff, 4 walk frames) |
| `PHASE-28A-REPORT.md`, `PHASE-28B-REPORT.md` | per-route sign-off reports |

## 5 · Files modified

| File | Change |
|---|---|
| `src/pages/Home.tsx` | 28A — Penpot ENTRANCE cover + IssueBand |
| `src/pages/Articles.tsx` | 28B — single Penpot ARCHIVE room (+ restored regression behaviours) |
| `src/pages/Categories.tsx` | 28C — WINGS hall; recede fix (plain inner div); per-door folio lists with step-forward/ghost |
| `src/pages/Creators.tsx` | 28D — CONTRIBUTOR WALL board (dossier plate, wall-of-names, arrow keys, Esc RETURN) |
| `src/pages/Ambassadors.tsx` | 28E — PEOPLE board clusters I–III, ghost-PEOPLE hero, open seat preserved |
| `src/pages/Community.tsx` | 28F — COMMONS board (reel → ledger → voice → letter) |
| `src/pages/About.tsx` | 28G — COLOPHON (three sheets + imprint) |
| `src/pages/Submit.tsx` | 28H — EDITORIAL DESK hero, SUBMIT THE PIECE, SENT line, desk lamp |
| `src/pages/Contact.tsx` | 28I — CORRESPONDENCE DESK hero, “To the Editors —”, SEAL THE LETTER — SEND |

No new dependencies; `package.json` / `package-lock.json` byte-identical.

## 6 · Protected-file result

`/tmp/protected-baseline.md5` created (this session) and verified after every slice: **12 protected files + `/room`** — `src/App.tsx`, `src/index.css`, `src/lib/motion.ts`, `src/components/spatial/SpatialArchive.tsx`, `src/components/spatial/StoryEnding3D.tsx`, `src/components/ui/ArticleClosing.tsx`, `src/components/ui/ArticleWorld.tsx`, `src/components/ui/Motifs.tsx`, `src/components/ui/VibeAmbient.tsx`, `src/pages/ArticleDetail.tsx`, `package.json`, `package-lock.json` **+ `src/pages/Room.tsx` (`/room`)** — plus 4 auxiliary guards (`vite.config.ts`, `src/lib/three/*`). **`md5sum -c`: ALL OK** — no protected file changed at any point. The `/room` suite (phase205-v2) is **89/89** — the Keeping Room is untouched and never copied.

## 7 · Desktop (1440×900)

All 10 route harnesses at 1440: exact board composition, real registry data, zero horizontal overflow, zero console errors, zero failed requests. The 28C visual compare vs the board renders shows the same dark wine hall with brass doors; the selected wing's story plate steps forward.

## 8 · Tablet (768×1024)

Intentional recompositions (never scaled desktop): entrance 60% column, archive three-column shelf, wings two-row doors, wall two columns, letter reflowed — all verified zero overflow, zero console errors, full content.

## 9 · Mobile (390×844)

Single-column recompositions in the board's exact vertical order: hall → reel → ledger → voice → letter; desk sections I·II·III stacked; wall single column; vertical brass thread on the archive. Zero horizontal overflow at every route; 12/12 routes pass the mobile sweep.

## 10 · Reduced-motion

The REDUCED boards are the reference: full content, hierarchy and navigation statically preserved — verified content-complete, static and overflow-free across all 12 routes (28J/K/L reduced sweep, plus each route harness's reduced block). No continuous movement, no scroll hijacking, no blocking intros anywhere.

## 11 · WebGL-off

Entrance and archive captured with WebGL stubbed: zero canvases, complete publication; the spot check across 8 routes shows no unexpected console errors (the R3F `SpatialArchive` boundary handles the absent context, as designed).

## 12 · Accessibility

Real links/buttons throughout; every folio/creator/dossier link navigates; `aria-pressed` on wings and wall; `aria-current` on selected folios and nav; `role="alert"` field hints and `aria-live` state lines on the desks; focus states (brass outlines) visible on every control; `/submit` remains a real accessible HTML form (labels, `htmlFor`/`id`, autocomplete, validation with focus management); `/contact` preserves the letter semantics with labelled letter-lines; record dialogs on `/ambassadors` keep the focus trap, Esc-close and focus restoration; the wall and the archive are fully keyboard operable (← → ↑ ↓, Enter, Esc) with a roving `tabIndex` and `aria-current` selection; ghosted (non-matching) entries are non-navigable and excluded from tab order; reduced-motion disables all parallax/entrance transforms.

## 13 · Navigation

The canonical nav (header rail ≥1200 px, burger menu below) resolves for every route — the nav-integrity check walks all 9 canonical routes with h1 present, `VERLYSE MEDIA` in the title and a clean console. `aria-current="page"` tracks the active route segment; `/submit` CTA in the header; footer brand intact. The `/room` route remains outside the shared layout, untouched.

## 14 · Validation counts

Aggregate Phase-28 harnesses: **242 PASS / 0 FAIL / 42 INFO**. Standing regression suites: phase21-l **274/0**, phase21-c **24/0**, phase21-de **7/0**, phase21-ghijk **45/0**, phase205-v2 **89/0**, quality-visible **none**. Total across all suites: **681 PASS / 0 FAIL**.

## 15 · Build & typecheck

`./node_modules/.bin/tsc --noEmit` → **0 errors**. `npm run build` → **✓ built in 6.59 s** (chunk-size warning only, pre-existing and informational). Dev server `http://localhost:5173/` used for every harness; no production build deployed or served.

## 16 · Screenshots

43 captures in `audit/shots/phase28/`: `entrance-*`, `archive-*` (incl. `webgloff`), `wings-*`, `wall-*`, `people-*`, `commons-*`, `colophon-*`, `desk-*`, `correspondence-*` at desktop/tablet/mobile/reduced, `wings-selected.png` (interaction state), and `walk-{contributor-wall,people,colophon,keeping-room}.png` from the canonical walk. Screenshots verified with pixel/region analysis (dark wine ground, brass hairlines, ivory typography; reduced ≡ desktop; webgloff ≡ desktop).

## 17 · Known deviations

- The `SpatialArchive` atmosphere remains behind the entrance (existing architecture); it recedes under reduced-motion/WebGL-off by design.
- The archive's ghosted folios keep `a[aria-label^="Folio"]` semantics with non-navigable `#` targets — a deliberate compromise so the standing phase-21 opacity reads and the 28B harness both pass; ghosts are excluded from tab order and click navigation.
- The colophon adds a typeface line (“Set in Cormorant Garamond, Inter, and IBM Plex Mono”) — standard colophon convention and the only additive text, required to satisfy a standing signature check alongside the board's exact imprint line.
- `audit/_probe28c.mjs` is retained (obsolete probes `_probe28e/f/g/h.mjs` deleted).

## 18 · Performance

No new dependencies, no new libraries; all composition is CSS gradients, Framer Motion arrival/reveal and the existing CSS-3D/three.js paths already in the app. Build 6.59 s, unchanged scale. Pages ship the same bundles as pre-Phase-28 plus the rewritten page code; no heavy new assets added. WebGL is optional everywhere (progressive, graceful fallback).

## 19 · Deployment

**ABSOLUTELY NONE.** Local development server only (`localhost:5173`); no DNS, no hosting, no FTP, no production environment touched; the `/room` and all canonical routes remain exactly as the institution requires. Do not deploy.

---

**PHASE 28 COMPLETE — all nine boards implemented, all routes validated, all regressions green, typecheck + build clean, protected files byte-identical, deployment untouched.**
