# GLOBAL TRANSFORMATION MAP — PHASE 21

**Project:** Verlyse Media (React 18 · Vite · TS · Tailwind · framer-motion · react-three)
**Design source of truth:** Penpot Phase-19 system (charcoal/wine/ivory/brass · Cormorant Garamond/Inter/IBM Plex Mono · plates · thread · folios · warm light)
**Rule:** The Keeping Room is the *metaphor*, Verlyse Media is the *product*. One continuous physical/editorial world. No deployment.

---

## 0. Audit summary (what actually exists today)

The site is **not** "a conventional website with one 3D page". It already carries the Keeping Room language on **every** route:

- All pages use the wine/charcoal/ivory/gold palette, serif+mono typography, editorial section heads, gold rules.
- Homepage cover has a real bounded **Three.js SpatialArchive** (protected) + editorial feature plate + entrance timeline.
- ArticleDetail has **StoryEnding3D / ArticleClosing / ArticleWorld / Motifs / VibeAmbient** (all protected) + canonical reading.
- Global SearchOverlay is already a dimmed archival index (`role=dialog`, `aria-modal`, ≤8 results, Esc restores).
- Header/menu already use mono uppercase + numbered menu items + wine-deep surfaces; Dock is a mobile folio bar.

**Genuine gaps to close (the real transformation):**

| Gap | Where |
|---|---|
| Page transitions are a generic magazine fade+sweep | `App.tsx` PageTransition |
| Header nav lacks "archival instrument" folio numbering + thread | `Header.tsx` |
| `/articles` is a conventional list (lead + rows), not an archive of folios | `Articles.tsx` |
| `/categories` is a filter grid, not a spatial reorganization | `Categories.tsx` |
| `/creators` is a card grid, not contributor dossiers | `Creators.tsx` |
| `/ambassadors` is a card grid, not an archival people wall | `Ambassadors.tsx` |
| Article *entry* doesn't announce the folio being pulled | `App.tsx` transition layer |

Everything else (Home, About, Community, Submit, Contact, WriterProfile, SearchOverlay, ArticleDetail) already conforms to the visual/material language and only needs *continuity*, not redesign.

---

## 1. Route-by-route map

| ROUTE | CURRENT EXPERIENCE | NEW SPATIAL EXPERIENCE | REUSED SYSTEMS | NEW COMPONENTS | MOTION SYSTEM | 3D | RESPONSIVE STRATEGY |
|---|---|---|---|---|---|---|---|
| **/** (Home) | Cover with Three.js spatial archive + feature plate + editorial sections | **Phase B:** reinforce arrival as archive entrance — ghost folio numeral, PULL→READ→RETURN vocabulary, "Pull folio 01" affordance on the feature plate; everything else stays | `SpatialArchive` (protected), `CountUp`, `Reveal`, `VoiceCarousel`, `MotifDivider`, `primitives` | `Home` additions only (inline) | framer-motion entrance timeline (exists), threshold veil | Three.js (already, protected) | already 1440/768/390 intentional |
| **Global shell** | Header + Footer + Dock + SearchOverlay | **Phase A:** folio-indexed nav (01–06) + brass thread that establishes; archival *threshold* page transition with route-aware folio label | `Header`, `Footer`, `Dock`, `Preloader`, `SearchOverlay` | `PageTransition` (threshold veil + thread + label) | framer-motion, reduced-motion instant | none (CSS) | header already responsive |
| **/articles** | Lead row + list rows | **Phase C:** archive shelf — 19 folio plates on the brass thread with depth (CSS-3D), featured/newest, category/author/date metadata, PULL→READ→RETURN affordance | `ARTICLES` registry, `folios` model concepts, room plate language (no `three`) | `ArticleShelf` / `FolioPlate` (CSS-3D, deterministic) | framer-motion entrance; hover attention | none (CSS-3D) | desktop shelf arc / tablet portrait shelf / mobile one-plate vertical thread |
| **/article/:id** | Canonical ArticleDetail (protected) | **Phase D/E:** threshold announces "Folio №NN · Reading" on entry; reading stays quiet and canonical | `ArticleDetail` (protected), `StoryEnding3D`, `ArticleClosing`, `ArticleWorld`, `Motifs`, `VibeAmbient` | threshold label only | veil transition; existing article motion | Three.js (existing endings) | untouched |
| **/categories** | Category grid | **Phase G:** category = the archive reorganizing — matching folios brighten/approach, others recede; never a list | `CATEGORIES`, folio geometry patterns | `CategoryArchive` | framer-motion reorganize | none (CSS-3D) | intentional per breakpoint |
| **/creators** | Contributor card grid | **Phase H:** contributor dossiers — portrait, role, bio, their folios; Full profile → `/creator/:id` | `AUTHORS`, `authorPhoto`, `foliosByAuthor` pattern | `CreatorDossier` | framer-motion dossier open | none (CSS) | stacked dossier on mobile |
| **/creator/:id** | Canonical writer profile (already archival) | continuity only | `WriterProfilePage` | — | existing | existing | — |
| **/ambassadors** | Ambasssador card grid | **Phase I:** archival people wall — real records as numbered plates on the thread; canonical route remains | `BRAND.ambassador*`, real team/creator records | `PeopleWall` | framer-motion | none (CSS) | 2-col → 1-col |
| **/community** | Editorial rails + voices (already on-language) | continuity only | `Community`, `FilmRail` | — | existing | existing | — |
| **/about** | Editorial colophon (already on-language) | continuity only | `About` | — | existing | existing | — |
| **/submit** | Submission page (already on-language) | continuity only | `Submit` | — | existing | existing | — |
| **/contact** | Contact desk (already on-language) | continuity only | `Contact` | — | existing | existing | — |
| **/room** | Full spatial archive prototype | **Keep as deep-archive destination** (not deleted); decision on redirect deferred to end of Phase 21 | all room files | — | existing | CSS-3D | intentional |

---

## 2. Shared architecture decisions

- **WORLD:** one visual system (Penpot Phase-19) across every route; no per-page "3D scenes".
- **CAMERA/VIEW:** CSS-3D perspective + framer-motion for DOM-first surfaces; `three` stays in its existing bounded layers (SpatialArchive, StoryEnding3D — protected, untouched).
- **DEPTH:** scale/opacity/z-translate hierarchy (folio near = bright/large; far = dim/small).
- **PLATES/THREAD/FOLIOS:** reuse room plate grammar (ivory, brass hairline, ghost numeral, mono metadata) in articles/categories/creators/ambassadors.
- **TRANSITIONS:** single global **archival threshold** (wine veil + brass thread + route-aware folio label) replacing the generic fade; reduced-motion instant.
- **REDUCED MOTION:** every new surface collapses to near-instant; content remains identical.
- **WEBGL:** no new `three` imports outside existing protected layers; CSS-3D carries new depth.
- **PERFORMANCE:** new components lazy/cheap; no new dependencies; bundle measured after each slice.

## 3. Slice plan (build → run → inspect → test → fix after each)

- **Phase A** ✅ (done): global shell — threshold PageTransition + folio-indexed nav. (24-check suite: 23 PASS + 1 cache artifact.)
- **Phase B** ✅ (done): homepage arrival reinforcement (ghost folio, PULL→READ→RETURN, pull affordance).
- **Phase C** ✅ (done): /articles main archive — 19 registry folios on the brass thread (desktop arc / tablet shelf / mobile vertical thread), search+category reorganize in place. **24/24**.
- **Phase D/E** ✅ (done): article pull/entry + reading integration — PULL → wine threshold “FOLIO № · READING” → canonical ArticleDetail → BACK → archive restored. ArchiveShelf DOM-focus fix (Enter pulls the correct folio). **7/7**.
- **Phase G** ✅ (done): /categories spatial index — door-plates select a department; the archive reorganizes itself (members brighten/approach, non-members recede, thread remains). **45/45 (G–K combined)**.
- **Phase H** ✅ (done): /creators contributor archive — numbered name index + dossier panel + folio plates → canonical article / creator page.
- **Phase I** ✅ (done): /ambassadors room of people — numbered diamond medallions, spatial clusters, FOCUS record dialog (Esc/focus trap), open seat №13 + real form.
- **Phase J** ✅ (done): search as editorial index — archive dims with context preserved, results carry registry folio №s, ↑/↓/Enter pull to canonical article, Esc returns.
- **Phase K** ✅ (done): /community The Commons, /about The Colophon (colophon imprint added), /submit Send a Voice, /contact The Desk — each its own metaphor, shared materials.
- **Phase L** ✅ (done): final global coherence audit — 288 checks (272 PASS / 0 FAIL), 45 flows re-verified, three.js isolation confirmed, quality tests A–E PASS. Fixes: Home WebGL-error boundary, /articles unfiltered-archive depth bug, reduced-motion Home entrance, nested-route active nav, /room footer link (dead end removed). /room disposition: **KEEP as the deep-archive spatial discovery destination**, reachable from the footer; not in primary nav; no redirect. See `PHASE21-FINAL-AUDIT-REPORT.md`.

## 4. Penpot

Phase-19 frames remain the foundation; the global expansion *extends their language* (already present site-wide) rather than inventing a new one — no new Penpot frames required for A/B. If Phase C+ warrants a frame for the articles shelf, a board can be drafted before implementing (optional, quota-conscious).

## 5. Safety

- No deployment, no InfinityFree/kesug/Vercel/DNS/FTP, no credentials, no new dependencies.
- Protected files: `spatial/*`, `three/*`, `ArticleDetail`, `ArticleClosing`, `ArticleWorld`, `Motifs`, `VibeAmbient`, `motion.ts`, `index.css`, `package.json`, `package-lock.json`, `vite.config.ts` — **byte-identical** unless a demonstrable integration issue forces a scoped change.

---

## PHASE 22 — THE IMMERSIVE PUBLICATION (completed)

Global spatial world transformation, route-by-route. The Keeping Room = vocabulary/reference only; Verlyse Media = identity. Verified foundation from Phase 21; evolved the compositions the Phase-22 brief calls out.

- **22A/C** ✅ — Archive evolved from single thread → **three-shelf stacks** (desktop): folios on receding shelves, focus approaches the reader, shelf boards + back wall, thread kept for tablet/mobile. Shared `geometry.ts` + `ArchiveShelf`.
- **22B** ✅ — Home entrance: controlled **scroll parallax** across atmosphere/ghost-masthead/copy planes, reduced-motion-gated.
- **22E** ✅ — /categories → **The Wings**: facade of seven department doors (depth/rotation), open Wing 08; selection reorganizes the archive.
- **22F** ✅ — /creators → **The Contributor Wall**: names as primary typographic objects; focus/hover steps forward, wall recedes.
- **22H** ✅ — /community: ledger **engraved into the room** (ghost numeral, brass ledger head, stat hover).
- **22D/G/I/J/K/L** ✅ — Verified: reading room (protected), people wing, colophon/desk, navigation/transitions, responsive, reduced-motion, WebGL-off.
- **22M** ✅ — Full audit: 288 checks / 0 FAIL; C 24/24 · D/E 7/7 · GHIJK 45/45 · /room 89/89 · tsc 0 · build ✓ · protected 0 diffs. No deployment.

---

## PHASE 23A — THE ENTRANCE ✅ COMPLETE (2026-08-30)

Homepage `/` entrance art-direction refinement of the Phase‑22 parallax. No rebuild, no content replacement, no /room influence, no new dependencies.

**Changed files (2):** `src/pages/Home.tsx` (7 edits: depth-hierarchical parallax pAtmo 0.28 / pGhost 0.18 / pBand 0.12 / pCopy 0.06 / pPlate −0.05 + scale→1.05, all reduce-safe; two print-registration brass hairlines; feature-plate wrapper w/ counter-scroll + scale + focus-visible brass outline; reduce-gated gold rule `initial`; ledger caption "The publication record — engraved, not estimated"; folio bar "Issue № 01" + "↓ the archive opens below") · `src/components/ui/ScrollBeat.tsx` (ReflectionLine reduced-motion gate — whileInView drift disabled under reduce).

**Verification (all green):** tsc 0 · build ✓ 7.41s · NEW phase23a harness 22/22 (×2 stable) · C 24/24 · D/E 7/7 · GHIJK 45/45 · /room 89/89 · L 288 = 272 PASS / 0 FAIL / 16 INFO · quality-visible: none · protected 15/15 OK · screenshots `audit/shots/23a-home-{1440,768,390,reduced,nogl}.png` + `audit/phase23a-results.json`.

**Measured depth at scrollY 400:** atmo 112 > ghost 72 > band 48 > copy 24 > plate −20 (scale 1.020) — exact design rates. Reduced motion: 0 movers, 0 anims. WebGL-off: entrance intact.

Report: `PHASE23A-REPORT.md` (§16 + §18). 23B NOT started.

---

## PHASE 23A.1 — THE ENTRANCE REVEAL ✅ COMPLETE (2026-08-31)

Follow-up to 23A: 23A passed tests but failed the visual objective (at rest ≈ Phase 22; archive invisible). 23A.1 reveals + art-directs the EXISTING SpatialArchive. **Only `src/pages/Home.tsx` changed** (protected 3D untouched).

**Fixes:** canvas wrapped with `[&_canvas]:mix-blend-lighten` → the scene's opaque black field lightens into the wine backdrop, leaving only cover plates + brass thread visible (archive reads as physical objects, not a black box) · wine atmosphere `0.9→0.38` + warmer base · vignette `0.55→0.26` · ghost VERLYSE stroke `0.13→0.36` · NEW giant ghost folio "№ 01" (`clamp(7rem,18vw,18rem)`, stroke 0.16, parallax 0.11, behind headline) · NEW 4 brass registration marks (corners, lg+) · parallax strengthened: atmo 0.36 / ghost 0.24 / band 0.16 / folio 0.11 / copy 0.10 / plate −0.08, plate scale cap 1.08.

**Verification (all green):** harness 27/27 ×2 (new checks: blend lighten, atmo 0.38, vignette 0.26, stroke 0.36, ≥4 marks, folio hierarchy) · tsc 0 · build ✓ 6.76s · C 24/24 · D/E 7/7 · GHIJK 45/45 · /room 89/89 · L 272/0/16 · quality none · protected 15/15. At-rest CSS-only captures now **0% pure black, wine dominant** (23A was 89% black). Measured scroll-400 hierarchy: 144/96/64/44/40/−32. Sandbox software-GL can't draw the scene's textures (framebuffer black) — real-browser WebGL-on visual is the user's final check. Report: `PHASE23A1-REPORT.md`.

---

## PHASE 24 — THE READING ROOM ✅ COMPLETE (2026-08-31)

`/article/:id` is now a spatial READING ROOM built AROUND the protected ArticleDetail (never modified). New `src/components/reading/ReadingRoom.tsx` (~120 lines) + 2-line App.tsx route wrap.

**Room (3 planes, CSS only):** BACK = fixed wine architectural field (lamp/floor gradients #3B0D17→#2A0F18→#1C070E), 2 brass wall rules + shelf rule, distant ghost folio numeral `№ NN` engraved behind the column · MID = vertical brass ledger "The Reading Room — Folio №NN", right index "category · № NN / 19", corner registration ticks, brass thread that draws down the page with reading progress (scroll-driven) · FRONT = canonical article (z2 over z0). Restrained parallax: back 0.07 / ghost 0.11 / mark 0.03 (per 1600px, capped; reduce→0). Folio derived from registry (findIndex+1). Reduced motion = same static composition, 0 anims. WebGL never required. No new deps/canvas/Three.

**Changed:** `src/components/reading/ReadingRoom.tsx` (new) · `src/App.tsx` (import + wrap). Protected 15/15 identical.

**Verification (all green):** NEW `audit/phase24-reading-room-validate.mjs` **64/64 ×2** (№01/№05/№19: deep URL, title, exactly-one H1, author, folio ledger, body intact no-dup, images, #ending, Up Next, overflow 0, keyboard focus, console clean; spatial grammar desktop; tablet/mobile simplification; reduced 0 anims; WebGL-off complete; Back→19 folios→Forward) · tsc 0 · build ✓ 6.15s · C 24/24 · D/E 7/7 · GHIJK 45/45 · /room 89/89 · L 272/0/16 · quality none. Screenshots `audit/shots/24-reading-{1440,768,390,reduced,nogl,mid-scroll}.png` (0% black, wine-dominant). Report: `PHASE24-REPORT.md`.
