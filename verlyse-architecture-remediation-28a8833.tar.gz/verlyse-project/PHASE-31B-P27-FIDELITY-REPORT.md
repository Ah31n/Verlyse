# PHASE 31B — P27 PENPOT FIDELITY REPORT

**Scope:** P27-fidelity implementation of exactly three routes — `/` (Entrance), `/articles` (Archive), `/categories` (Wings) — against the authoritative P27 board families. Not a redesign; not a "more 3D" request.
**Method:** every comparison below is measured from **actual board renders** (`/home/user/p27-shots/p27-{entrance,archive,wings}-{desk,tab,mob,red}.png`) vs **fresh Chromium captures** of the live app (`audit/shots/phase31b/*.png`). Prior reports were treated as historical context, not evidence.
**Date:** 2026-09-01.

---

## 1 · Board mapping (route → Penpot page → board → viewport → evidence → status)

| Route | Penpot family | Board file | Viewport | Evidence | Status |
|---|---|---|---|---|---|
| `/` Entrance | P27 (boards live under P19 pages; duplicates exist) | `p27-entrance-desk.png` | 1440×900 | `board-entrance.json` | IMPLEMENTED |
| `/` Entrance | P27 | `p27-entrance-tab.png` | 768×1024 | same | IMPLEMENTED |
| `/` Entrance | P27 | `p27-entrance-mob.png` | 390×844 | same | IMPLEMENTED |
| `/` Entrance | P27 (reduced == desk, verified identical profile) | `p27-entrance-red.png` | 1440×900 static | same | IMPLEMENTED |
| `/articles` Archive | P27 | `p27-archive-desk.png` | 1440×900 | `board-archive.json` | IMPLEMENTED |
| `/articles` Archive | P27 | `p27-archive-tab.png` | 768×1024 | same | IMPLEMENTED |
| `/articles` Archive | P27 | `p27-archive-mob.png` | 390×844 | same | IMPLEMENTED |
| `/categories` Wings | P27 | `p27-wings-desk.png` | 1440×900 | `board-wings.json` | IMPLEMENTED |
| `/categories` Wings | P27 | `p27-wings-tab.png` | 768×1024 | same | IMPLEMENTED |
| `/categories` Wings | P27 | `p27-wings-mob.png` | 390×844 | same | IMPLEMENTED |

Status classes used throughout: **IMPLEMENTED** · **DYNAMIC** (driven by live registry, by design) · **DESIGN ANNOTATION** (board labels/notes — never rendered) · **REFERENCE** (board state text) · **MISSING** · **NOT APPLICABLE**.

## 2 · Ambiguity resolutions

1. **P27 Entrance boards under P19 pages / duplicate entrance boards:** the approved `p27-entrance-{desk,tab,mob,red}.png` renders are the authority (validated by Phase-28 harnesses; canvas corners `#35101B→#1D1214` confirm genuine wine boards, not bleed). No other Entrance generation used.
2. **P25 Reading Room stale/empty boards:** not used — three P27 families only.
3. **Reduced boards:** pixel-identical to desktop (ivory/gold profiles match) → reduced must be the desk composition with zero motion. Verified: `archive/wings` desk-vs-reduced diff 0.000; entrance 0.027 (sub-pixel antialiasing only).
4. **Annotation rail:** the right ≈13% of every board carries Penpot annotation labels (e.g., "STATE · BACK/MID/FRONT", composition notes). Classified **DESIGN ANNOTATION** — cropped at x=0.87W for all measurements and never pasted into the UI.
5. **19 folios vs 15 board slots:** the board's shelf is a composition reference (5 slots × 3 rows + hinge); the live Archive carries all **19 registry folios** (5+5+5+4 rows) so no folio is dropped. The registry wins over the board's sample count.
6. **Board headline ambiguity:** the board's upper-middle zone shows ghost typography and the impl's h1 "Where Vision Becomes A Voice" is a Phase-28-required element; the impl keeps its centered h1 in the upper-middle zone (documented deviation, §16).

## 3 · ENTRANCE — board vs impl (12 fidelity dimensions)

Measured desk (1440×900): board sheet x29–71%, y54–76%; impl sheet x28.9–71.1%, y54–77.5% (top **486 = 486 exact**; width 608 vs 605).

| Dimension | Board | Impl (before → after) | Verdict |
|---|---|---|---|
| Composition | ghost typography upper, ivory sheet lower-middle, folio bar base | text-on-wine → **ivory sheet in the board zone** | IMPLEMENTED |
| Object positions | sheet y54–76 | y486–699 (54–77.5) | IMPLEMENTED |
| Scale | sheet 605×198 | 608×212 | IMPLEMENTED |
| Typography | wine editorial text on ivory sheet | wine serif title + brass mono meta on ivory | IMPLEMENTED |
| Color/materials | ivory `#F8F6F2` sheet, wine text, brass hairline, offset edge | same material system (no new palette) | IMPLEMENTED |
| Depth | sheet floats on wine hall, parallax planes | pAtmo/pGhost/pFolio/pCopy parallax + sheet shadow | IMPLEMENTED |
| Layer order | back hall / mid ghost / front sheet | z0 hall, z1-2 ghosts, z3 sheet | IMPLEMENTED |
| Spacing | sparse negative space above sheet | h1 zone + rule + sheet rhythm | IMPLEMENTED |
| Alignment | sheet centred | sheet centred (tab right-shifted per board) | IMPLEMENTED |
| Interaction state | — (static board) | reduced-motion collapse, hover/focus unchanged | NOT APPLICABLE |
| Responsive recomposition | tab = wider sheet (x22–87), mob = full-width (y42–61) | tab x18–82 y55–80; mob full-width y43–66 | IMPLEMENTED |
| Reduced-motion composition | desk static | reduced == desk (0.027 diff) | IMPLEMENTED |
| Brass rules / ghost numeral / CTA / nav | rule y50, folio bar y88 | short brass rule above sheet, folio bar y851–899, CTA + deck below sheet, nav intact | IMPLEMENTED |

Ivory presence: desk 8.94%→**10.07%** · tab 11.54%→**15.81%** · mob 15.78%→**19.00%** (pre-fix: 0.46 / 0.24 / 0.23).

## 4 · ARCHIVE — board vs impl

Desk: board 3 shelf rows of ivory folio plates, slots x14–88% with central hinge (51–64); impl 19 ivory cards in 5+5+5+4 rows with a brass central spine, rows starting ≈44% (board ≈32%; residual header cost documented in §16).

| Dimension | Board | Impl (before → after) | Verdict |
|---|---|---|---|
| Composition | ivory folio plates on shelf rows | text rows → **ivory cards in shelf rows + spine** | IMPLEMENTED |
| Object positions | rows y32–43 / 53–62 / 73–82 | rows y44–55 / 59–69 / 73–84 / 88–98 | IMPLEMENTED |
| Scale | cards ≈11%×11% | cards 233×86–108 px ≈ board-ish ratio | IMPLEMENTED |
| Typography | wine text on ivory | wine serif titles, brass №, wine meta | IMPLEMENTED |
| Color/materials | ivory + brass hairline | ivory + outer/inner brass hairlines | IMPLEMENTED |
| Depth | shelf tapers | inner-opacity taper + recede under filter | IMPLEMENTED |
| Layer order | back shelf threads / mid header / front shelf | unchanged back threads + header + front | IMPLEMENTED |
| Spacing | uniform rows, hinge | uniform rows + brass spine | IMPLEMENTED |
| Alignment | 5-across (desk), 3-across (tab), full-width (mob) | 5/3/1 with `sm:2` intermediate | IMPLEMENTED |
| Interaction state | selected plate distinguished | brass border + lift + shadow + "Selected — open folio →" | IMPLEMENTED |
| Responsive | tab 3-col, mob 3 full-width strips | tab 3-col, mob full-width cards | IMPLEMENTED |
| Reduced-motion | desk static | reduced == desk (0.000) | IMPLEMENTED |

Ivory presence: desk 17.49%→**13.60%** · tab 18.85%→**21.97%** · mob 17.32%→**28.21%** (pre-fix: 0.21 / 0.12 / 0.16).

## 5 · WINGS — board vs impl

Desk: board tall ivory first-door plate x22–31% y21–73% + six gold ghost doors; impl ivory plate y40–82 on door I at rest, following the selected wing.

| Dimension | Board | Impl (before → after) | Verdict |
|---|---|---|---|
| Composition | one ivory door plate + gold ghost doors | **ivory arched plate + gold ghost doors** | IMPLEMENTED |
| Object positions | plate y21–73 (tall) | plate y369–729 when selected, y40–82 at rest (row-shifted by header) | IMPLEMENTED |
| Scale | plate ≈130×468 | plate ≈176×360 | IMPLEMENTED |
| Typography | wine text on ivory plate | wine italic name + brass Wing label + wine count on ivory | IMPLEMENTED |
| Color/materials | ivory plate, brass edges | ivory + brass border + inner hairline | IMPLEMENTED |
| Depth | plate steps forward | shadow + lift; others recede 0.25–0.3 | IMPLEMENTED |
| Layer order | back hall + recesses / mid doors / front stories | unchanged | IMPLEMENTED |
| Spacing | doors top-aligned, plate extends down | `items-start` grid, plate taller | IMPLEMENTED |
| Alignment | 7 doors | 7 doors (2/4/7 responsive) | IMPLEMENTED |
| Interaction state | — | aria-pressed, recede, counts update, Esc restores | NOT APPLICABLE (static board) |
| Responsive | tab plate x19–36; mob full-width plate y13–28 | tab x4–31 y33–72; mob full-width y39–79 | IMPLEMENTED |
| Reduced-motion | desk static | reduced == desk (0.000) | IMPLEMENTED |

Ivory presence: desk 3.64%→**5.09%** · tab 5.35%→**8.06%** · mob 5.61%→**19.53%** (pre-fix: 0.36 / 0.26 / 0.31).

## 6 · Gaps (root cause and closing)

**Root cause (all three routes):** the P27 boards place **solid ivory paper objects** on the wine hall; the impl rendered those objects as gold-hairline/ghost text compositions with almost no ivory (entrance −10 to −17 pts, archive −19 to −20 pts, wings −4 to −6 pts). All fixes were contained material conversions — no new visual language, no new effects, no new dependencies, protected files untouched.

## 7 · Fixes applied

- **Home.tsx** — feature block wrapped in a solid ivory editorial sheet (`#F8F6F2`, brass border + offset hairline + bottom gradient rule, wine text, brass CTA styling); MID headline block given an explicit `top` so the threshold sits in the upper-middle; short brass rule above the sheet; sheet sized/positioned per board (608×212 @ y486 desk; 496×250 @ y567 tab; full-width @ y364 mob). Reduced-motion guards preserved.
- **Articles.tsx** — folio rows converted to 19 solid ivory cards (wine text, № brass, inner brass hairline, Newest badge on wine); `xl:grid-cols-5` with a brass central spine (the board's hinge); selected plate = brass border + lift + shadow + "Selected — open folio →"; non-members recede under filter; header compacted so the first row starts ≈44%; ghost №01–19 floated out of flow at the shelf's top-right. **All functional code (search, rail, keyboard, focus, aria-current, Esc, canonical links, dock) preserved byte-for-byte logic.**
- **Categories.tsx** — active (or first-at-rest) door becomes a solid ivory arched plate (wine text, brass border + inner hairline, tall on desk, full-width on mobile); other doors stay gold ghosts; `items-start` grid so the plate stands forward; recede/lift/count/Esc behaviour unchanged.

## 8 · Screenshots (visual evidence)

`audit/shots/phase31b/` — 12 viewport captures (`entrance-{1440,768,390,reduced}.png`, `archive-…`, `wings-…`) + `archive-selected.png` (folio-3 focused) + `wings-selected.png` (Poetry selected). All captures: ox=0, exactly 1 h1, 0 console errors.

## 9 · Responsive

Each viewport matches **its own board** (no desktop scaling):
- **Desk 1440×900:** Entrance sheet 608px @ y486 (board 605 @ y486); Archive 5-col + spine; Wings tall ivory door.
- **Tab 768×1024:** Entrance sheet 496px @ y567 (board ≈499 @ y543; +24px residual); Archive 3-col; Wings plate narrower/higher per tab board.
- **Mob 390×844:** Entrance full-width sheet y364 (board y354); Archive full-width ivory cards above the fold (folio №01 at y442); Wings full-width ivory plate. No horizontal overflow anywhere (ox=0 across all 12 captures).

## 10 · Reduced motion

All three routes: `prefers-reduced-motion: reduce` → static compositions, **0 running animations**, content intact, no overflow. Desk-vs-reduced pixel diff 0.000 (archive, wings) / 0.027 (entrance, antialiasing).

## 11 · Accessibility

- Single `h1` per route (verified at all 3 viewports).
- Archive: real DOM focus, Arrow/Home/End keys, Enter opens, Esc restores, `aria-current` on the selected folio, ghost/non-member links `href="#"` + preventDefault (kept).
- Wings: real `<button>` doors, `aria-pressed`, keyboard ← →, Esc return, list semantics for folios.
- Entrance: anchors unchanged; sheet is decorative container around existing links; all motion gated by `useReducedMotion`.
- No console errors, no failed requests, no horizontal overflow in any capture.

## 12 · Functional regression

| Suite | Result |
|---|---|
| `npm test` (full-matrix + interaction + flags + assets) | **exit 0** — interaction 12/12, assets 40/40, 0 console/page/network errors, 0 overflow routes |
| `phase31-archive-validate.mjs` | **29 PASS / 0 FAIL** |
| `phase28-entrance` | 33/0/5 |
| `phase28-archive` | 25/0/5 |
| `phase28-wings` | 19/0/4 |
| `phase31b-visual-validate.mjs` (NEW) | **74 PASS / 0 FAIL / 0 INFO** |
| `phase21-c` | 24/24 |
| `phase21-de` | 7/7 |
| `phase21-ghijk` | 45/45 |
| `phase205-v2` (/room authority) | 89/89 |
| `phase21-l` | 273–274 pass / 1–2 **pre-existing settle flakes** (see §16.4) |
| `quality-visible` | no route mismatches |

## 13 · Build & typecheck

- `npx tsc --noEmit` → **0 errors**.
- `npm run build` → clean; only the pre-existing three.js/react chunk-size advisory (unchanged, not addressed this phase).

## 14 · Protected-file checksums

Fresh baseline written to `audit/protected-baseline-phase31b.md5` (14 protected files; the Phase-31 `/tmp` baseline was lost to a sandbox reset, as anticipated). **None of the three 31B-edited files (`Home.tsx`, `Articles.tsx`, `Categories.tsx`) are protected.** Protected files byte-identical (no Phase-31B edit touched them):

| File | md5 |
|---|---|
| src/App.tsx | `ab1f04fa…bddfc5` |
| src/pages/Room.tsx | `372d6555…08b297` |
| src/index.css | `4a50893d…19d6b3` |
| src/lib/motion.ts | `43ab8cc3…9bf3a5` |
| src/components/spatial/SpatialArchive.tsx | `ba4f8b4a…68ecf55a` |
| src/components/spatial/StoryEnding3D.tsx | `074074b8…38a9a5` |
| src/components/ui/ArticleClosing.tsx | `4df70edf…a48b8` |
| src/components/ui/ArticleWorld.tsx | `ee1236f7…dc63ce` |
| src/components/ui/Motifs.tsx | `12c49628…7bbe1` |
| src/components/ui/VibeAmbient.tsx | `f52fcea8…bc41708d` |
| src/pages/ArticleDetail.tsx | `084fb3fe…11a2d6` |
| package.json | `c0c71e66…a9fd2b7` |
| package-lock.json | `a66edfdd…5c38d5` |
| vite.config.ts | `108eae41…db849` |

No new dependencies; `npm ci` reproducibility intact (node_modules rebuilt from lockfile after sandbox reset).

## 15 · /room regression

`/room` untouched: `phase205-v2` **89/89** (incl. "WebGL-off: room + 19 plates render"). Direct WebGL-off probe of `/room`: h1 "The Keeping Room" present, ox=0. The Keeping Room composition was **not** copied into Archive or any 31B route.

## 16 · Remaining deviations (honest list — none inflated to PASS)

1. **Archive first-row start ≈44% vs board ≈32%** — the impl's functional header (search + category rail, which the board does not show) occupies the band; the shelf rows themselves match the board's 11%-tall plate rhythm. Classified IMPLEMENTED (composition intent) with this positional deviation.
2. **Archive desk ivory 13.6% vs board 17.5%** — 19 discrete cards with breathing gaps vs the board's continuous shelf bands. Deliberate: 19 folios must all be readable, and card gaps read as shelf spacing.
3. **Entrance tab sheet +24px lower / mob +40px taller than board** — content volume (5 lines vs board's 3) and stack anchoring; within "art director recognises" tolerance.
4. **phase21-l settle flakes (pre-existing):** 1–2 FAILs per run on different lazy routes (`/room`, `/contact`, REDUCED `/`), all traced to the suite's 1.5–1.6 s settle vs lazy-chunk loads needing 4.2–7 s. Direct probes with proper settle: all pass (h1 present, ox=0, 0 running animations under reduce). Not caused by 31B (flaking routes untouched).
5. **Board ghost-wordmark zone** — the impl keeps its larger engraved VERLYSE/MEDIA ghost + centered h1; the board's upper-middle reading is approximated, not replicated exactly (see §2.6).
6. **Mob Archive/Wings ivory volume higher than board** (+10.9/+13.9 pts) — the impl plates carry the full required content (title, category, author) on mobile; the board's short strips would drop that information.
7. **Board annotation labels / state text** — never rendered (DESIGN ANNOTATION / REFERENCE by classification).

## 17 · Deployment status

**None.** No Vercel/InfinityFree/FTP/DNS operations, no production credentials or environment touched. Validation ran against the local Vite dev server (`localhost:5173`) only. The remote deploy scripts continue to require `FTP_USER`/`FTP_PASS` and fail closed (Phase 31 remediation intact; final repo secret scan remains CLEAN).

---

**Verdict:** the three P27-fidelity routes now place the board's ivory objects (Entrance feature sheet, Archive folio plates, Wings door plate) at board-comparable positions, scale, material, and depth on the wine hall — with all standing functionality, accessibility, registry data, protected files, and `/room` intact. All mandated suites green except the two documented pre-existing settle flakes. No deployment performed.
