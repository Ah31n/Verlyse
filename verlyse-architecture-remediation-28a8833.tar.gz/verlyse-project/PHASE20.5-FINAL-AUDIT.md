# PHASE 20.5 — THE KEEPING ROOM · FINAL AUDIT

**Project:** Verlyse Media · **Layer:** The Keeping Room (`/room`) · **Date:** 2026-08-30
**Method:** Audit the Phase-20 build state-by-state against the approved Penpot Phase-19 frames (`/home/user/p19-shots/fr-00…fr-15.png`), fix only demonstrable P0–P2 fidelity/interaction/responsive issues, re-validate in real Chromium (Playwright) after every change. No redesign. No deployment. No new dependencies. No protected file touched.

---

## 1. Overall verdict

**PASS — production-ready (local, not deployed).** The room faithfully realizes the approved experience. The audit found no P0 issues. It found **one class of P1 fidelity gap** — the FOCUS / SETTLE / NEXT decisions were presented in a separate dark overlay rather than **on the enlarged, face-on ivory plate** as Penpot frames 03 / 04 / 08 specify — plus supporting gaps in ENTRY (05), ENDING (07) and RETURN (09). All were fixed using **only real registry data**, within the allowed room file scope. Every state now matches its Penpot frame, all three viewports are clean, keyboard/reduced-motion/WebGL-off pass, canonical routes and protected files are intact.

Tests A (remove 3D) and B (remove technology) **pass**: the enlarged plate is a flat editorial card (eyebrow, serif title, brass rule, italic pull text, wine byline, mono metadata), the palette is wine/ivory/brass, and no state depends on WebGL or particles.

## 2. Penpot fidelity (frame-by-frame)

| Frame | Result | Evidence |
|---|---|---|
| 01 Arrival | ✅ VERLYSE MEDIA over THE KEEPING ROOM; wine threshold; ghost edge plates; Enter CTA | `desktop-01-arrival.png` |
| 02 Discovery | ✅ 19 real folios on the brass arc; №01 *Their Voices Matter* / Alina Javed primary; neighbour attenuation | `desktop-02-discovery.png` |
| 03 Focus | ✅ **fixed** — plate enlarges face-on & carries the editorial content; neighbours mute to flanking blocks; `PULL THE PLATE` | `desktop-03-focus.png` |
| 04 Settle | ✅ **fixed** — title / excerpt / byline / `SOCIAL ISSUES · 26 JUN 2026 · 4 MIN` / `ENTER → · RETURN ←` on the plate | `desktop-04-settle.png` |
| 05 Entry | ✅ **fixed** — wine threshold, Verlyse masthead, title, brass byline, date/read-time; no duplicated article UI | `audit-entry.png`, `desktop-05-entry.png` |
| 06 Reading | ✅ Canonical ArticleDetail owns reading (`Verlyse` masthead, est. 2026); room hands off | `desktop-06-article.png` |
| 07 Ending | ✅ **fixed** — wine card, `FOLIO №01 · CLOSE`, real closing line, brass rule, `— ALINA JAVED`, room re-forms | `desktop-07-ending.png` |
| 08 Next | ✅ **fixed** — newest **№19 Mir Raza Ali / VERLYSE MEDIA**, real excerpt, `READ FOLIO 19 →`, flanking plates visible | `desktop-08-next.png` |
| 09 Return | ✅ **fixed** — neat face-on restored row; read plate brightest w/ `READ ✓`; `Back to the archive.` headline | `desktop-09-return.png` |
| 10 Category | ✅ Spatial filter; members bright on the arc, non-members ghosts; never a list | `desktop-10-category.png` |
| 11 Creator dossier | ✅ Real contributor (Alina Javed, 2 folios); `Full profile →` to `/creator/:id` | `audit-dossier.png`, `desktop-11-dossier.png` |
| 12 Search | ✅ Dimmed-room overlay, live results (max 6), Enter opens, Esc closes; escape hatch → `/articles` | `desktop-12-search.png` |
| 13 Ambassadors/People | ✅ Room acts as entrance: `People` → canonical `/ambassadors` (verified navigation) | route log |
| 14 Tablet 768×1024 | ✅ Portrait composition, enlarged face fits, no overflow | `tablet-01…09` |
| 15 Mobile 390×844 | ✅ One plate in hand, vertical thread, opens on newest **№19**, reduced depth, face fits | `mobile-02/03`, `mobile-04-settle` |

All editorial text is registry-sourced: dates (`2026-06-26` → **26 JUN 2026**, `2026-08-27`), reading times (4 MIN / 2 MIN), categories, bylines, and excerpts (№01 pull line “The only difference is where they were born.”; №19 “Mir Raza Ali was only 25.”) match the frames verbatim. **Nothing was invented.**

## 3. Desktop (1440×900)
All 9 vertical states + 3 discovery layers render; **overflowX 0 / overflowY 0, consoleErrors [], failedRequests []** on every capture.

## 4. Tablet (768×1024)
Portrait shelf/reduced depth confirmed; the enlarged editorial face and wine cards fit without clipping; **0 / 0 overflow, no console errors**.

## 5. Mobile (390×844)
Opens on newest №19 (NEWEST badge); vertical brass thread; focus/settle face fits within the viewport; secondary chips hidden; controls clear the footer; **0 / 0 overflow, no console errors**.

## 6. Interaction (PULL → READ → RETURN)
Verified end-to-end in-browser: arrival →(Enter) discovery →(↓) focus →(Enter) settle →(Enter) **entry threshold → canonical `/article/their-voices-matter`** →(Back) **ending** →(Next) **№19** →(Return) restored thread with `READ ✓`. Read-state persists across the handoff via `sessionStorage`. A state-machine gap (Esc from NEXT dropped to discovery) was fixed to return to the read folio’s Ending.

## 7. Accessibility
- **Keyboard-only pass run and logged:** Enter/↓ advance, Enter pulls focus→settle→read, Esc backs out (settle→focus→discovery; closes search/category/dossier), `/` opens search (1 result for “mir raza”), ↑ returns. Focusable targets are semantic `<button>`/`<Link>` with `aria-label`/`aria-current`; search is `role="dialog" aria-modal="true"`.
- **Reduced motion** (`prefers-reduced-motion: reduce`): full flow re-run — transitions near-instant, 3D perspective disabled, **0 errors / 0 overflow**; same publication.

## 8. WebGL fallback
Room imports **no `three` and uses no canvas** (verified by grep). WebGL context forced to `null`: full flow **0 console errors, 0 overflow, no blank state**.

## 9. Performance / bundle
`/room` stays lazy. Final build: `Room-*.js 27.25 kB` (**gzip 7.73 kB**), `✓ built in 6.73s`. The large `three-*.js` chunk is not imported by the room. No new assets, no perpetual animation, listeners are effect-scoped.

## 10. Routing / canonical systems
All return HTTP 200 and render: `/room`, `/article/their-voices-matter`, `/article/mir-raza-ali`, `/creator/alina-javed`, `/ambassadors`, `/articles`. Hard refresh / deep link on `/room` remounts the room (`main[aria-label*="Keeping Room"]` present). Invalid article (`/article/no-such-folio-xyz`) returns the app shell (SPA 200) with canonical not-found handling — **the room does not handle or invent article content**. Search is an overlay (no `/search` route replaced); its fallback links to `/articles`.

## 11. Protected-file integrity
`md5sum -c phase20-baseline-hashes.txt` → **all 12 protected files OK / byte-identical** (SpatialArchive, StoryEnding3D, ArticleClosing, ArticleWorld, Motifs, VibeAmbient, ArticleDetail, motion.ts, index.css, package.json, package-lock.json, vite.config.ts). `src/components/spatial/*` and `src/lib/three/*` untouched.

## 12. Changes actually made (room scope only)
- **`src/components/room/Plate.tsx`** — added a full **editorial face** for the pulled folio (focus/settle/next): eyebrow `FOLIO №n`, serif title, brass rule, italic excerpt, wine byline (serif for people / mono for the Verlyse Media organization), mono `CATEGORY · [date] · MIN`, and on-plate `PULL THE PLATE` / `ENTER →` / `RETURN ←` / `READ FOLIO n →` controls; stacked NEWEST/READ badges; shelf card retained for discovery.
- **`src/lib/room/geometry.ts`** — focus/settle/next now present the focused plate face-on and large with neighbours muted (brighter in NEXT); **RETURN** is a neat face-on restored row; ENDING/ENTRY retreat behind the wine cards.
- **`src/components/room/Room.tsx`** — replaced the focus/settle/next dark overlays with on-plate decisions; built the **frame-05 wine entry threshold** and **frame-07 ending card** (real closing line); added the **frame-09 Return** headline; NEXT moves attention to №19; hid room chrome during the full-screen entry/ending beats (no bleed-through); two-step PULL (focus→settle) consistent for click and keyboard; fixed Esc-from-NEXT and category-chip collision.
- No changes to `state.ts`, `folios.ts`, `pages/Room.tsx`, `App.tsx`, or any protected/registry file.

## 13. Screenshots captured
`/home/user/p19-validation/shots/`: `desktop-01…12`, `tablet-01…09`, `mobile-01…09`, `audit-entry.png`, `audit-dossier.png`, `audit-discovery.png`, plus earlier loop shots (`loop-06/07/09`).

## 14. Remaining issues
- **None at P0–P3.** Note (by design, not a defect): state **13 Ambassadors** is intentionally a canonical destination reached via `People`; the room is the entrance and does not embed a people grid (frame 13’s in-room directory was the approved handoff concept — the live header link to `/ambassadors` satisfies the “people remain canonical / room is entrance” rule).
- P4 (subjective, **not changed**): exact plate pixel-sizes differ marginally from the Penpot mock; composition and hierarchy match.

## 15. Deployment status
**Not deployed.** No InfinityFree / Vercel / DNS / FTP / credentials touched. Local dev server only; production build verified.
