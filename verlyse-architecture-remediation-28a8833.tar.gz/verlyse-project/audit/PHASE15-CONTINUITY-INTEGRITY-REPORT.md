# Phase 15 — Editorial Continuity & Post-Ingestion Integrity Audit

**Date:** 2026-08-28 · **Auditor:** Arena agent · **Site:** `/home/user/verlyse-project` (sole copy)
**Scope:** audit-only, per change threshold — modify only genuine continuity defects that affect the published experience; never protected cinematic systems (SpatialArchive, StoryEnding3D, ArticleClosing, ArticleDetail, Motifs, VibeAmbient, motion/camera, dependencies).

---

## Verdict — the critical test

> "Could someone who never saw Phase 14 tell they were added yesterday?"

**NO — not after the nine corrections below, and not before them for the article itself.** The Mir Raza Ali piece renders through the exact same template, type system, plate treatment, ending plate, contributor block, and registry-driven discovery as the eighteen features before it. The seams that *did* exist were never in the article — they were in static copy elsewhere that had been hand-tuned to "eighteen" and never updated by the registry (the ingest correctly refused to touch it). Those are now fixed. The only residual, uniform quirk (duplicated category chip on creator cards) pre-exists Phase 14 across **all 14 established cards** and is therefore continuity, not a defect.

**Changes made in Phase 15: 9 text-level fixes across 4 files. 0 changes to protected systems. 0 changes to the Phase 14 article record or Zainab Khan record.**

---

## 1. Editorial continuity — new vs established articles

Compared at 1440×900, 768×1024, 390×844 against `behind-every-headline` (same category) and `their-voices-matter` (same ending type):

| Element | Mir Raza Ali (new) | Established siblings | Verdict |
|---|---|---|---|
| Documentary hero (cover plate, meta row, excerpt) | Plate 01 w/ "THE COVER" caption, kicker row, italic excerpt | Identical structure on every documentary | ✓ native |
| Typography hierarchy (title scale, drop cap, measure) | Same template classes | Identical | ✓ |
| Metadata (category · byline · read time) | `SOCIAL ISSUES · VERLYSE MEDIA · 2 MIN READ` | Same pattern, computed fields | ✓ |
| Contributor block (monogram diamond, name, handle row, signature, ABOUT THE WRITER) | `VM` monogram, `@VERLYSE.MEDIA · THE PLATFORM` | Identical; monogram fallback works as designed | ✓ |
| Within-the-post plates | WAFFLIX (01/2) + THE DEMAND (02/2), gold inset frames, mono labels, captions | Same figFrame treatment | ✓ |
| Tags row | SOCIAL ISSUES / JUSTICE / PAKISTAN | Same underline-chip row | ✓ |
| Ending (voices plate) | Hairline → 3 serif lines → italic couplet → ink-stroke signature | Pixel-identical structure to TVM's ending; hashtag in signoff matches sibling precedent (`@lina_.jved` in TVM's) | ✓ |
| Related / Up Next | behind-every-headline → its related row lists Mir Raza Ali ✓; tvm's up-next chain includes it | Derived from registry `related()` | ✓ |
| Category treatment | Social Issues card count = 4, folio rail 01–19 | ✓ after fix (was "№ 01 to № 18") | ✓ |

**No invented metadata.** Every field on the record traces to the submission (title, byline "Verlyse Media", role "The Platform", body, 3 plates, 2 within-the-post figures, ending, #JusticeForMirRazaAli). Date and read time follow existing registry conventions.

## 2. Registry integrity — `scripts/phase15-integrity.mjs`

**54 assertions, 54 passed, 0 failed.** Highlights:

- 19 articles: unique `id`, `title`, `shortCode`, `slug`; all 87 referenced images exist on disk.
- `ARTICLES[0]` = `their-voices-matter` (featured untouched); `mir-raza-ali` appended **last** (folio № 19) — deterministic, no reordering, no duplicate.
- 16 authors: 15 human + platform (`verlyse-media`, no portrait field, exact role strings). No duplicate identities.
- Per-category counts match the registry: Stories 1 · Poetry 7 · Essays 2 · Art 3 · Social Issues 4 · Lifestyle 1 · Horror 1.
- `COMMUNITY_STATS` = 19 features / 1281 appreciations / 585 conversations / 15 creators — each equals the computed sum.
- `BRAND.team` = 12 rows; first row (Alina) and every pre-existing row byte-identical in content; Zainab Khan final.
- `related()` safe for all 19 articles (no dangling ids).
- Sitemap: 19 article + 16 creator URLs, all resolvable routes.

## 3. Homepage continuity

- Featured work remains `ARTICLES[0]` = Their Voices Matter (hero cover, "THE FIRST FEATURE — PLATE 1", `EST. 2026`) — verified by screenshot; **untouched**.
- Latest-work logic (date-desc, top 8) now leads with `mir-raza-ali` (08-27) ahead of `behind-every-headline` (08-01) — correct, because it genuinely is the newest; ordering is computed, not hardcoded.
- No badges (NEW/LATEST/FEATURED) anywhere; the archive's "LATEST FEATURE" banner is the pre-existing designed treatment for the most recent feature.
- New content does not overpower the cover: home hero, stats row, and first-feature plate unchanged.
- Spatial archive: receives the record through the same registry path (all plate fields verified present); no camera/motion changes (mtime-proof, §8).

## 4. Ambassador continuity — Zainab Khan

- Exact strings: `name: "Zainab Khan"`, `role: "Head of Research Department"`, bio `"Leads the research department at Verlyse Media."` — rendered verbatim on `/ambassadors`.
- Placement: final row (12th) of the team, below Ahsan Ashfaq; the closing line ("The team as it stands today…") follows her row intact.
- Monogram: `ZK` in the diamond — same fallback structure as every other no-photo record; no generated/stock face, no reused portrait, no image field.
- Responsive + visual consistency: side-by-side with Ahsan Ashfaq's row (including the two-line role wrap he already exhibits) — indistinguishable treatment (screenshots `p15-amb-team-bottom`, `p14-ambassadors-*`).
- No duplicates; no other team record altered (integrity script asserts pre-existing rows).

## 5. Article experience — does it *feel* like a Verlyse article?

Full pass at 1440/768/390: arrival → cover plate → meta row → excerpt → contributor block → drop-cap body → within-the-post plates → tags → save/share rail → ending plate → signature → up-next → footer. Every beat matches the sibling templates beat-for-beat (see §1 table). The piece reads as if it had always been № 19.

## 6. Responsive — compared against established articles, not in isolation

390×844: monogram block wraps identically to siblings; ending plate keeps its border/padding; sticky mobile nav (HOME · ARTICLES · CATEGORIES · SUBMIT) behaves as on every other article. 768×1024: two-column within-the-post grid collapses on both new and old alike. No new breakpoint artifacts.

## 7. Search & discovery — "Raza"

| Path | Result |
|---|---|
| Nav overlay search "Raza" | ✓ resolves "Mir Raza Ali" (screenshot `p15-overlay-raza.png`) |
| Article index (search field + list) | ✓ shown in "19 presented" |
| Social Issues category filter | ✓ listed |
| Related (behind-every-headline) | ✓ |
| Spatial archive | ✓ record present with all plate fields (integrity) |
| Direct route `/article/mir-raza-ali` | ✓ 200, 0 console errors |
| Hard refresh on the route | ✓ ok (phase14-verify rerun) |

## 8. Regression sweep — protected systems unmodified

Every protected path has mtime **17:30:40**, predating all Phase 14 edits (~17:45) and all Phase 15 edits:
`SpatialArchive.tsx`, `StoryEnding3D.tsx`, `ArticleClosing.tsx`, `ArticleDetail.tsx`, `Motifs.tsx`, `VibeAmbient.tsx`, `ArticleWorld.tsx`, `src/components/spatial/*`, `src/lib/three/*`, `index.css`, `pages/ArticleDetail.tsx`, `package.json`, `package-lock.json`, `vite.config.ts`.
Camera constants (baseZ 10.8, depth −3.2, 1.2s/0.8s) are parameterized, not literals — mtime is the unmodified evidence. `npm run build` clean (tsc + vite). Runtime regression: **19/19 routes + 5 assets, 0 console errors, 0 broken images** after every fix.

---

## Defects found & fixed (9) — all static copy that had gone stale

The registry was always the source of truth; the ingest correctly appended to it. These nine literals were hand-written for an 18-feature/14-creator site and had no code path to update:

| # | File | Was | Now |
|---|---|---|---|
| 1 | `src/pages/Articles.tsx` (hero ledger) | `№ 01 — "Their Voices Matter" / № 18 — "The Garden…" / № 19 — yours?` | `№ 01 — "Their Voices Matter" / № 19 — "Mir Raza Ali" / № 20 — yours?` |
| 2 | `src/pages/Articles.tsx` (reserved ghost numeral) | `19` | `20` |
| 3 | `src/pages/Articles.tsx` (reserved comment) | "№ 19 reserved" | "№ 20 reserved" |
| 4 | `src/pages/Articles.tsx` (index footer) | "Eighteen features in the archive" | "Nineteen features in the archive" |
| 5 | `src/pages/Categories.tsx` | "№ 01 to № 18" | "№ 01 to № 19" |
| 6 | `src/components/ui/EasterEggs.tsx` | "Eighteen features, fourteen writers" | "Nineteen features, fifteen writers" |
| 7 | `src/components/ui/EasterEggs.tsx` | "Accession — 2026 · 01 — 18" | "Accession — 2026 · 01 — 19" |
| 8 | `src/pages/Home.tsx` | `['14', 'Creators credited']` | `['15', 'Creators credited']` |
| 9 | *(same file, second label)* | second "Creators credited" label agreed at 14 | both labels now 15 |

**Creator-count ground truth** (verified computationally): 14 unique byline authorIds; **15 credited creators** — `mochjixx` (Mochi) is credited via the `credit` field on *a-students-worth* and has never carried an authorId, yet is counted in `COMMUNITY_STATS` and shown on the creators wall. 15 is the site's canonical count; the footer "FIFTEEN CREATORS · ONE ROOM" already said so. The Home label was the only stale one.

**Why these fixes qualify under the change threshold:** each was a self-contradiction visible in the published archive (the page said "19 presented" in the rail while the ledger ended at № 18 and the footer said "eighteen"); the fix is a one-token copy correction that restores the pre-Phase-14 authoring pattern (ledger = first/last/yours; count words track the registry); and no protected system is touched.

## Inspected and intentionally NOT changed

- **Documentary kicker redundancy** ("A SUBMISSION BY VERLYSE MEDIA" under a Verlyse Media byline) — template lives in protected `ArticleDetail.tsx`; cosmetic; documented seam.
- **Creator-card duplicated chip** ("SOCIAL ISSUES · SOCIAL ISSUES") — the card renders `[category, …tags.slice(0,1)]` and every established article stores `tags[0]` = its category, so **all 14 pre-existing cards** render the duplicate identically. Uniform across the wall → continuity. Fixing it would mean editing the shared card component (visual system) or deviating the new record from the data convention — both rejected.
- **Folio vs date order in the unfiltered index** — the index leads with the newest feature (latest-first banner) while folios stay stable by array position. Pre-existing designed behavior; the new article simply occupies the newest slot with its stable № 19.
- **Copy-A pre-Phase-13 state** in Home/SpatialArchive/StoryEnding3D — documented, unchanged.

## Evidence

- Scripts: `scripts/phase15-integrity.mjs` (54/54), `scripts/phase15-compare.mjs`, `scripts/phase15-retake.mjs`, `scripts/phase14-verify.mjs` rerun (19/19).
- Screenshots in `/home/user/phase14-verify/` prefixed `p15-*`: new vs established heroes/ending/contributor ×3 viewports, within-the-post, ambassador rows (Zainab/Ahsan/Javeria), creators wall cards, articles hero ledger, reserved № 20 block, home hero, overlay search "Raza".

**Ship state: build clean, 19/19 runtime green, registry 54/54, continuity verdict — the additions are indistinguishable from the house style.**
