# VERLYSE MEDIA — PHASE 14
## CANONICAL CONTENT INGESTION & BRAND AMBASSADOR UPDATE

**Date**: 2026-08-28
**Workspace**: `/home/user/verlyse-project`
**Phase**: 14 — New Editorial Submission + Brand Ambassador Update

This was a content ingestion phase. No animation, camera, spatial, or layout systems were touched.

---

### 1. New submission identity

Source: supplied Instagram dataset `dataset_instagram-scraper_2026-08-28_16-57-03-343.json`
(post `DciqQXTCilh`, a 3-slide carousel published by `@verlyse.media` on 2026-08-27).

- **Title**: “Mir Raza Ali” — taken verbatim from the post’s own title slide (slide 1 masthead)
- **Type**: full social-issue dispatch (memorial + demand for justice), category **Social Issues**
- **Author record**: `verlyse-media` — the platform itself is the poster named in the source
  (`ownerFullName: "Verlyse Media"`, `ownerUsername: "verlyse.media"`). Added to `AUTHORS` as
  `The platform`; no portrait exists in the source, so the established monogram treatment applies.
- **Body**: the three slide texts, extracted word-for-word (per the content layer’s own convention)
- **Dates/counts**: date 2026-08-27; 9 comments (the post’s own `commentsCount`)
- **Likes**: the source reported `likesCount: -1` (unavailable) — stored as `0` with a data comment;
  no like count is asserted anywhere on the site

Nothing was invented. Where metadata was absent (creator note, motif, second credit, thumbnail,
finale) the field was simply omitted and the architecture’s existing fallbacks apply.

### 2. Files modified

| File | Change |
|---|---|
| `src/data/content.ts` | +1 `AUTHORS` entry (`verlyse-media`); +1 `ARTICLES` entry (`mir-raza-ali`, appended — `ARTICLES[0]` untouched); Social Issues `count` 3→4; `COMMUNITY_STATS` features 18→19 + note, conversations 576→585; +1 `BRAND.team` entry (Zainab Khan, appended) |
| `src/pages/Home.tsx` | hardcoded count copy 18→19 (4 places), 576→585 (2 places) |
| `src/pages/Creators.tsx` | “fifteen” → “sixteen names” (SEO + intro) |
| `src/pages/About.tsx` | 18→19 (2 places), 576→585 (1 place), timeline “19 features, 15 creators” |
| `src/pages/Articles.tsx` | PageRail “eighteen” → “nineteen” |
| `src/pages/Community.tsx` | SEO + prose copy 18→19 / 576→585, aria-label “all nineteen covers” |
| `src/components/layout/Footer.tsx` | “Eighteen features” → “Nineteen features” |
| `public/sitemap.xml` | + `/article/mir-raza-ali`, + `/creator/verlyse-media` |
| `README.md` | documented feed totals updated to the verified numbers |
| `scripts/phase14-verify.mjs`, `scripts/phase14-shots.mjs` | new audit tooling (house convention: audit scripts live in `scripts/`) |

**Protected files — not modified**: `SpatialArchive.tsx`, `StoryEnding3D.tsx`, `lib/motion.ts`,
`index.css`, `ArticleDetail.tsx`, `ArticleClosing.tsx`, `Motifs.tsx`, `VibeAmbient.tsx`,
`ArticleWorld.tsx`, all `src/components/spatial/*`, `package.json` / `package-lock.json`.

### 3. Assets added (all self-hosted, deterministic paths, no temp URLs)

| Path | Role |
|---|---|
| `public/img/works/DciqQXTCilh-1.webp` | cover (slide 1 — masthead + portrait of Mir Raza with the Wafflix mascot) |
| `public/img/works/DciqQXTCilh-2.webp` | slide 2 (the Wafflix story) |
| `public/img/works/DciqQXTCilh-3.webp` | slide 3 (the demand) |
| `public/img/inner/mir-raza-wafflix-cart.webp` | inner figure — the cart, cropped from slide 2 |
| `public/img/inner/mir-raza-justice-rally.webp` | inner figure — the rally, cropped from slide 3 |

Cover/figures distinction preserved: slide 1 is the primary cover; slides 2–3 additionally appear as
the “Within the post” source plates (same pattern as `behind-every-headline`).

### 4. Brand Ambassador update

`Zainab Khan — Head of Research Department` added as the final row of `BRAND.team` (the data source
rendered by the `/ambassadors` route, “The team” section). Exact name and role as supplied. No image
was supplied, so the existing monogram treatment applies (no face generated, no stock, no reuse).
All 11 pre-existing rows untouched, in their original order.

### 5. Route added/updated

- `/article/mir-raza-ali` — data-driven via the existing `/article/:id` router (no route registration needed)
- `/creator/verlyse-media` — data-driven via `/creator/:authorId` (monogram profile)
- Both URLs added to `sitemap.xml`
- Direct navigation, hard refresh (SPA rewrite), internal links (related cards, “Up next”, search
  overlay, articles index), category room (Social Issues now shows “4 features within”), related-content
  logic, and spatial archive (feeds from `ARTICLES` automatically) — all verified

### 6. Existing systems verified

- Homepage featured work unchanged (`ARTICLES[0]` = “Their Voices Matter”)
- Latest-works grid: new feature appears as issue 01 purely via the existing date-sort derivation
- Search: typing “Raza” in the live overlay resolves the new feature
- Category derivation, related articles, community stats — all registry-driven
- `package.json` / `package-lock.json` untouched (no new dependencies)

### 7. Build result

- `tsc -b`: **0 errors**
- `vite build`: **PASS** (5.9 s, 28 chunks — identical chunk topology to the Phase 13 baseline; the
  three.js 770 kB chunk warning is pre-existing and unchanged)

### 8. Runtime result (headless Chrome, production build)

- 14 routes + 5 direct asset requests + hard-refresh of the new article: **0 console errors,
  0 page errors, 0 failed asset requests, 0 broken images**
- Existing-route controls (`their-voices-matter`, `behind-every-headline`, `creator/alina-javed`,
  all other pages): pass
- Live search overlay resolves the new feature; reduced-motion check passes (content visible,
  no animation dependence)

### 9. Responsive result

Full-page verification at **1440×900**, **768×1024**, **390×844** on the new article:
no overflow, no clipping, no broken image ratios, no typography collisions. The documentary hero
plate scales down on mobile (existing behavior). Ambassador card row renders at all widths
(grid collapses to single column — existing behavior). Screenshots: `/home/user/phase14-verify/`.

### 10. Accessibility result

- Inherited behavior, no changes: semantic `h1` per page, section kickers, `figure`/`figcaption`
  for the plates (alt = label + article title), monograms `aria-hidden`
- `aria-label` on the Community feed grid updated to the true count
- Keyboard/focus: no new interactive elements introduced
- `prefers-reduced-motion: reduce`: verified — all content renders visible without animation

### 11. Regression result

- Phase 10–13 protected files: **byte-identical** (not in the change set)
- No new GSAP/Three.js/parallax/particles/transitions/decorative effects; no new dependencies
- Existing articles, creators, categories, ambassadors: untouched (verified via route audit +
  duplication check: title/slug/shortcode/shortCode each resolve exactly once; Zainab Khan appears
  exactly once in the entire site)
- No creative regression — the new feature uses only registry data and existing rendering paths
  (documentary hero, `urgent` vibe, `newsprint` world, `voices` closing — all pre-existing
  registered treatments)

### 12. Unresolved issues / honest caveats

1. **Like count unavailable in source** (`likesCount: -1`). Stored as `0` with an explanatory data
   comment; the site-wide “1281 appreciations” total was left as-is (it remains the verified sum of
   the posts whose counts are known).
2. **Documentary kicker template** renders “Verlyse Media presents — a submission by Verlyse Media”
   because the poster is the platform itself. Pre-existing template behavior; left unchanged per the
   protected-systems rule.
3. **Motif omitted** for the new feature (no motif exists in the source; the house `✦` fallback
   renders, same as any motif-less feature).
4. **Pre-existing workspace note (not caused by this phase)**: `Home.tsx`, `SpatialArchive.tsx` and
   `StoryEnding3D.tsx` are in their pre-Phase-13 snapshot state due to an earlier workspace
   truncation (see session record). Phase 14 modified only copy in `Home.tsx`; the spatial/camera
   systems were not touched and behave as last built.
5. The 585-conversations figure is the exact sum of every post’s own `comments` field (576 + 9).

---

**Final principle honored**: content only. The new submission and Zainab Khan belong to the existing
Verlyse publication as if they had always been there.

VERLYSE FIRST. PUBLICATION SECOND. SPATIAL THIRD. MOTION FOURTH. TECHNOLOGY LAST.
