#!/usr/bin/env python3
"""Phase 31B — board & implementation composition analyzer.
Crops the right ~13% annotation rail, reports row profiles + ivory blobs per image.
Usage: python3 audit/phase31b-analyze.py <mode: rows|blobs|both> <image...>
"""
import json, sys
from PIL import Image
import numpy as np
from collections import deque

CROP = 0.87

def analyze(p, mode):
    a = np.asarray(Image.open(p).convert('RGB')).astype(int)
    h, w, _ = a.shape
    a = a[:, :int(w * CROP), :]
    h, w = int(a.shape[0]), int(a.shape[1])
    R, G, B = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    iv = ((R > 200) & (G > 190) & (B > 160)).astype(float)
    gold = ((R > 120) & (R < 215) & (G > 85) & (G < 200) & (B < 140)).astype(float)
    bright = ((R > 150) & (R <= 212) & (G > 140) & (G <= 200) & (B > 100) & (B < 180)).astype(float)
    rec = {'file': p.split('/')[-1], 'w': int(w), 'h': int(h),
           'ivory%': round(float(iv.mean() * 100), 2),
           'gold%': round(float(gold.mean() * 100), 2),
           'bright%': round(float(bright.mean() * 100), 2)}
    if mode in ('rows', 'both'):
        rows = []
        step = max(1, h // 40)
        for y0 in range(0, h, step):
            y1 = min(h, y0 + step)
            rows.append({'y%': round(y0 / h * 100, 1),
                         'ivory': round(float(iv[y0:y1].mean() * 100), 2),
                         'gold': round(float(gold[y0:y1].mean() * 100), 2),
                         'bright': round(float(bright[y0:y1].mean() * 100), 2)})
        rec['rows'] = rows
    if mode in ('blobs', 'both'):
        mask = (iv > 0).astype(bool)
        visited = np.zeros_like(mask)
        blobs = []
        for y in range(h):
            for x in range(w):
                if mask[y, x] and not visited[y, x]:
                    q = deque([(y, x)]); visited[y, x] = True
                    size = 0; minx = maxx = x; miny = maxy = y
                    while q:
                        cy, cx = q.popleft(); size += 1
                        minx = min(minx, cx); maxx = max(maxx, cx)
                        miny = min(miny, cy); maxy = max(maxy, cy)
                        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                            ny, nx = cy + dy, cx + dx
                            if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and not visited[ny, nx]:
                                visited[ny, nx] = True; q.append((ny, nx))
                    if size >= 4000:
                        blobs.append({'px': size,
                                      'x%': [round(minx / w * 100, 1), round(maxx / w * 100, 1)],
                                      'y%': [round(miny / h * 100, 1), round(maxy / h * 100, 1)]})
        rec['blobs'] = sorted(blobs, key=lambda b: -b['px'])
    return rec

mode = sys.argv[1]
imgs = sys.argv[2:]
out = {p: analyze(p, mode) for p in imgs}
print(json.dumps(out, indent=1))
