# Verlyse Media — Phase 1: Forensic Gap Analysis

**Date:** 2026-08-28  
**Inspector:** Arena Agent Mode  
**Workspace:** `/home/user/workspace_extracted/verlyse-project/`

---

## What was inspected

| System | Files | Status |
|--------|-------|--------|
| Routing | `App.tsx` — 12 routes, lazy-loaded, Framer Motion page transitions | ✅ Present |
| Layout chrome | `Header.tsx`, `Dock.tsx`, `Footer.tsx`, `Layout.tsx`, `Preloader.tsx` | ✅ Present |
| Search | `SearchOverlay.tsx` — ⌘K, focus trap, Esc, keyboard | ✅ Present |
| Saved | `SavedDrawer.tsx` | ✅ Present |
| Homepage | `Home.tsx` — 819 lines, Cover + IssueBand + WorksStrip + FeatureSection + SpatialReading + Pulse + Departments + VoiceCarousel + Invitation + Colophon | ✅ Present |
| Article | `ArticleDetail.tsx` — 748 lines, 4 hero modes, 14 vibes, 7 worlds | ✅ Present |
| Spatial (homepage) | `SpatialArchive.tsx` — Three.js, 18 CoverPlane plates, SignalThread, Rig camera | ✅ Present |
| Spatial (endings) | `StoryEnding3D.tsx` — 18 distinct scene kinds (voices, clock, waltz, candle, light, painting, beads, page, letter, cat, feather, hands, pause, people, word, steps, cycle, prayer) | ✅ Present |
| SVG signatures | `ArticleSignature.tsx` — 677 lines, 18 SVG scenes with CSS keyframe animations | ✅ Present |
| Closings | `ArticleClosing.tsx` — 10 closing variants (voices, mission, note, artwork, about-work, final-verse, passage, story-end + Signature, MotifDivider) | ✅ Present |
| Article world | `ArticleWorld.tsx` — 7 world textures (paper, letter, newsprint, night, linen, gallery, document) | ✅ Present |
| Determinism | `seed.ts` — FNV-1a + LCG | ✅ Present |
| Spatial state | `spatialState.ts` — 6 states (threshold→archive→selected→reading→desk→quiet) | ✅ Present |
| WebGL detection | `useWebGLSupport.ts` | ✅ Present |
| Motion library | `motion.ts` — ink/leaf easing, settle/unfold/ink/breathe durations | ✅ Present |
| UI primitives | `Reveal.tsx`, `VoiceCarousel.tsx`, `primitives.tsx`, `EasterEggs.tsx`, `Motifs.tsx`, `MotionMoves.tsx`, `ScrollBeat.tsx` | ✅ Present |
| Content | `content.ts` — 14 articles, 15 authors, 7 categories | ✅ Present |
| Endings | `articleEndings.ts` — 18 scene mappings + SIGNATURE_MAP | ✅ Present |
| Styles | `index.css` — 532 lines, Tailwind + custom keyframes for 18 signature scenes | ✅ Present |
| Tailwind | `tailwind.config.js` — wine/ivory/gold palette, Cormorant Garamond/Inter/IBM Plex Mono | ✅ Present |
| Build | `vite.config.ts` — code-splitting for three/react/motion/router | ✅ Present |
| Images | `public/img/` — works/, inner/, signatures/, authors/, 3 posters | ✅ Present |

---

## What already works well (do NOT touch)

1. **Editorial identity is fully realized.** Wine/ivory/gold palette, Cormorant Garamond serif, drop caps, pull quotes, marginalia, plate imagery. This is the magazine's soul.

2. **18 SVG signature scenes are beautifully crafted.** Each one is an original symbolic composition (the clock at 3:13, the letter folding, the feather drifting, the cat blinking, etc.) with restrained CSS keyframe animations. These are the visual punctuation marks. They should remain untouched.

3. **Deterministic spatial seeding is sound.** FNV-1a + LCG, no Math.random() in spatial pipeline.

4. **6-state spatial machine is well-designed.** threshold→archive→selected→reading→desk→quiet with intensity values.

5. **Content integrity.** 14 real articles with real text, real authors, real comments.

6. **Accessibility infrastructure.** Skip link, ARIA, reduced motion, keyboard nav, focus restoration.

7. **Code splitting.** Three.js loads only when needed; route pages are lazy.

8. **4 hero modes.** Cinematic, documentary, gallery, quiet — each article gets its own presentation.

9. **14 vibe specs.** Each article's temperament drives its motion and finish.

10. **7 world textures.** Each publication has its own atmospheric layer.

11. **10 closing variants.** Each feature closes differently.

12. **Search + Saved + Reading mode.** All functional with keyboard access.

---

## Gap Analysis — ranked by priority

### P0 — Must improve (genuinely affects the immersive goal)

**1. Homepage spatial archive is too subtle.**
- In the live screenshots, the Three.js plates behind the hero are barely visible — faint dark shapes at best. The spatial layer should feel present but not overpowering. Currently it reads as "there's something dark behind the text" rather than "there's an archive of editorial plates with depth."
- **Root cause:** Plate opacity values are too low (`0.4 * distFade * intensity`), plate sizes are small, and the camera doesn't frame them well. The plates need to be more visible at the archive state.
- **Fix:** Increase plate opacity, size, and camera framing. Make the brass SignalThread more visible. The archive should feel like a physical room you can see into.

**2. Camera rig is too passive.**
- The `Rig` component in `SpatialArchive.tsx` uses simple sinusoidal drift with very small amplitude (`0.5` at threshold, `0.28` at archive). The camera barely moves. It doesn't feel cinematic.
- **Fix:** Add more intentional camera choreography — gentle parallax tied to scroll position, focal depth changes when selecting a plate, and a subtle "lean" toward the selected work. The camera should feel like a physical editorial camera.

**3. StoryEnding3D scenes are geometric primitives.**
- The Three.js ending scenes use basic geometries (boxes, cones, spheres, torus) with basic materials. They lack atmospheric depth — no particles, no volumetric feel, no editorial lighting.
- **Fix:** Enhance lighting (more layers, more editorial quality), add subtle particle systems where appropriate, improve material quality (more roughness/metalness variation), and make compositions more distinctive.

### P1 — Important polish

**4. Scroll choreography is mostly Framer Motion `whileInView`.**
- Section entrances use the same pattern: `whileInView={{ opacity: 1, y: 0 }}`. This is functional but doesn't create a cinematic scrolling experience.
- **Fix:** Add GSAP ScrollTrigger for large-scale scroll choreography — section entrance sequencing, controlled parallax, pinned moments. Not to replace Framer Motion (which handles UI state), but to add cinematic scroll direction.

**5. Image treatment could be more editorial.**
- Cover plates use `aspect-[4/5]` with `object-cover`. This is correct but could have more intentional framing — custom crop hints per article, more distinctive reveal choreography.
- **Fix:** Add editorial crop hints, more distinctive image reveals (clip-path, mask), and better hover treatment.

**6. Micro-interactions are restrained but could be more refined.**
- Nav links have a simple underline on hover. Cards scale slightly. Buttons have a fill animation. These are good but could be more distinctive.
- **Fix:** Refine hover states — more editorial, more distinctive. Add subtle magnetic behavior to important CTAs. Refine the saved/bookmark interaction.

**7. Page transitions are basic.**
- Currently: opacity + y offset with a gold hairline sweep. This works but doesn't feel like moving through a publication.
- **Fix:** Make transitions feel more like turning a page — maybe a brief curtain effect, or a more distinctive sweep.

**8. Mobile spatial experience is untested.**
- The SpatialArchive doesn't render on mobile (viewport gating). The mobile experience relies entirely on the HTML publication.
- **Fix:** Ensure mobile has its own intentional composition — not just a shrunk desktop.

### P2 — Optional refinement

**9. Typography hierarchy.** Line-height, letter-spacing, and responsive scaling are good but could be refined further.

**10. More atmospheric particles in 3D scenes.** Dust motes, light particles, etc.

**11. Parallax on hero images.** The cinematic hero could have more depth.

**12. More distinctive visual treatments per vibe/category.** Currently vibes mostly change overlay colors.

---

## What I will NOT do

- Rewrite content.ts, articleEndings.ts, seed.ts, spatialState.ts
- Replace the 18 SVG signature scenes (they are already beautiful)
- Add Math.random() anywhere
- Create a second routing system
- Add unnecessary dependencies
- Make the 3D layer required for the publication
- Clone Manus
- Deploy or modify production

---

## Animation ownership (to be enforced)

| Property | Owner | Notes |
|----------|-------|-------|
| 3D transforms, camera, spatial objects | Three.js / R3F | SpatialArchive + StoryEnding3D |
| Scroll choreography, section sequencing | GSAP ScrollTrigger (to be added) | Large-scale scroll |
| Page transitions, UI state, menu, search, drawer, reveals | Framer Motion | React UI state |
| SVG signature keyframe animations | CSS keyframes | Already present, do not touch |
| Hover/focus/utility transitions | CSS | Simple states |

---

## Manus reference

No Manus workspace was found in the upload. The Manus prompt references it as a quality benchmark for visual sophistication, composition, depth, and choreography — but no actual files are available. All improvements will be driven by the Verlyse identity and the gaps identified above.

---

## Plan

1. **Enhance SpatialArchive** — increase plate visibility, improve camera choreography, make the brass thread more prominent
2. **Enhance StoryEnding3D** — better lighting, atmospheric particles, more distinctive compositions per scene kind
3. **Add GSAP ScrollTrigger** — cinematic scroll choreography for key homepage sections
4. **Refine micro-interactions** — nav, cards, buttons, bookmark
5. **Refine page transitions** — more editorial feel
6. **Build + verify** — full audit across desktop, tablet, mobile
7. **Final report** — evidence-backed

Let me proceed to Phase 2: Implementation.
