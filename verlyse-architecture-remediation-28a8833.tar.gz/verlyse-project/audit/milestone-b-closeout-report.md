# Milestone B Closeout Gates

Date: 2026-09-04
Branch: `verlyse-architecture-remediation`
Deployment: **not performed** — preview deployment requires explicit user approval.

## Gate 1 — Complete metadata generation: PASS

The build-time generator now reads the canonical `src/data/content.ts` registry through a temporary TypeScript transpilation step. It no longer maintains a hand-curated article/contributor list.

Generated route count: **50**

Generated route families:

- `/` — homepage
- `/articles` — archive
- `/categories` — category index
- `/categories/stories`
- `/categories/poetry`
- `/categories/essays`
- `/categories/art`
- `/categories/social-issues`
- `/categories/lifestyle`
- `/categories/horror`
- 19 `/article/:id` routes from `ARTICLES`
- 16 `/creator/:id` routes from `AUTHORS`
- `/about`
- `/community`
- `/ambassadors`
- `/submit`
- `/contact`

The category slug route is now supported by React Router and initializes the selected category from the canonical registry.

`npm run test:metadata` passed for all 50 generated shells. Each shell was checked for:

- unique title;
- description;
- canonical URL;
- Open Graph title, description, type, and image;
- Twitter card, title, description, and image;
- `index, follow` directive;
- JSON-LD;
- Article JSON-LD for article routes; and
- ProfilePage JSON-LD for contributor routes.

Social image assets returned HTTP 200 in the existing production reference.

## Gate 2 — Preview deployment verification: BLOCKED / AWAITING APPROVAL

No preview deployment was created because the user has not explicitly approved the external deployment action.

Prepared but not executed:

```bash
npm run build
npx vercel --prebuilt --token "$VERCEL_TOKEN"
```

After approval, verify the preview URL for clean route HTML, robots, sitemap, API CORS, CSP/security headers, images, and hydrated SPA navigation.

## Gate 3 — Browser validation: BLOCKED BY ENVIRONMENT

Playwright browser binaries were downloaded, but Chromium cannot start because the environment lacks:

```text
libnspr4.so
```

The full matrix and interaction audits were attempted and failed at browser launch. No rendered browser validation is claimed for any viewport or interaction requirement.

## Gate 4 — Independent Git-history secret verification: PASS

An independent non-disclosing history scan was run across all commits, excluding only the detector’s own literal pattern source from the target scan. It found no live-token or private-key pattern in repository history.

Results:

- baseline commit: no live-secret finding;
- Milestone A commits: no live-secret finding;
- Milestone B commits: no live-secret finding;
- tracked sensitive filenames: none;
- remediation status: no repository-history remediation required.

No matched values were printed.

## Gate 5 — API smoke test: PASS

`npm run test:newsletter` passed six synthetic provider-free checks:

- allowed production origin;
- approved local origin;
- disallowed origin;
- OPTIONS;
- GET;
- invalid email;
- missing provider configuration; and
- safe normalized errors.

No real email, provider request, subscription, or form submission was performed.

The client build contains no provider authorization value. `BUTTONDOWN_API_KEY` remains server-only.

The current rate limiter remains instance-local. It is not distributed protection. No paid/shared rate-limit service was added.

## Gate 6 — Dependency review: PASS

GSAP was confirmed unused by source import inspection and was removed in its own cleanup change:

- `package.json`
- `package-lock.json`

No animation framework was added.

## Changed files since the previous Milestone B report

- `scripts/prerender-metadata.mjs` — registry-backed generation for all route families.
- `scripts/metadata-audit.mjs` — full generated-route metadata assertions.
- `src/App.tsx` — category slug route.
- `src/pages/Categories.tsx` — canonical category slug initialization and route metadata.
- `vercel.json` — category and dynamic article/contributor prerender rewrites.
- `package.json` — GSAP removal and existing validation scripts.
- `package-lock.json` — GSAP removal.
- `audit/milestone-b-closeout-report.md` — this report.

No visual rewrite, scene art, geometry, content registry, or CMS/framework migration was performed.

## Validation summary

Passed:

- `npm run build`
- `npm run test:metadata`
- `npm run test:newsletter`
- `npm run check:secrets`
- `npm run typecheck:api`
- `git diff --check`
- independent Git-history secret-pattern scan
- production social-image checks

Blocked:

- Playwright full matrix
- interaction audit
- all real browser viewport/focus/reduced-motion/WebGL-off checks
- preview deployment verification pending explicit approval

## Milestone C decision

**Milestone C is blocked.**

It must not begin until:

1. the user explicitly approves a preview deployment and the prerendered clean URLs are verified;
2. a browser-capable runtime is available or the limitation is explicitly accepted; and
3. navigation/focus behavior is verified in a real browser.

When approved, Milestone C must begin with only the mobile quality-controller spike specified by the user: static/ambient/interactive tiers, 4–6 initial textures, capped DPR, offscreen pause, and a visible non-WebGL archive path. No new scene art should be added first.
