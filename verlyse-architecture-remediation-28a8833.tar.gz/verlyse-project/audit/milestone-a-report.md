# Milestone A — Safety and Baseline Report

Date: 2026-09-04
Branch: `verlyse-architecture-remediation`
Deployment: none (intentionally not deployed)

## Scope completed

Milestone A only. No visual rewrite, editorial content change, content-registry change, 3D geometry change, or new 3D feature was introduced.

## Changed files

- `.gitignore` — expanded exclusions for environment files, credentials, tokens, private keys, OAuth artifacts, browser profiles, cookies, PKI databases, MCP files, and generated workspace state.
- `api/newsletter.ts` — replaced wildcard CORS with an allowlist for the production origin and local Vite/preview origins; documented that the in-memory limiter is instance-local and not distributed protection.
- `index.html` — changed the public-site robots directive from `noindex, nofollow` to `index, follow` after confirming this is intended to be a discoverable public magazine.
- `src/hooks/useSeo.ts` — retained the existing client-side SEO model and added route-specific Twitter metadata and Open Graph type values for page and article routes.
- `scripts/check-secrets.mjs` — added a non-disclosing filename and obvious-secret-pattern check.
- `package.json` — added `npm run check:secrets`.
- `.mcp.json.example` — removed from tracked application source because MCP configuration is treated as sensitive workspace state.
- `audit/milestone-a-report.md` — this report.

## Security findings and actions

- The workspace is now a Git repository on branch `verlyse-architecture-remediation`.
- Baseline commit was created before remediation: `853e6fa`.
- The user confirmed that exposed credentials were rotated before work began. No credential values were opened, printed, copied, or written by this milestone.
- Local MCP files were removed from the application workspace without opening them.
- A sanitized rollback copy remains at `/home/user/verlyse-architecture-remediation-baseline`.
- `npm run check:secrets` passes.
- A tracked-file scan finds only `.env.example`, which is an allowed placeholder file and contains no secret value.
- The check intentionally reports filenames and safe finding labels only; it never prints matched secret content.

## Public indexing

- The site was confirmed as the intended public Verlyse magazine.
- `index.html` now uses `index, follow`.
- `public/robots.txt` and `public/sitemap.xml` were preserved unchanged.

## Metadata findings

- Every current public page component has a `useSeo` call, and article/contributor routes derive metadata from the canonical registry.
- Page metadata now updates title, description, canonical, Open Graph title/description/image/type, Twitter card/title/description/image, and WebPage JSON-LD.
- Article metadata retains Article JSON-LD and now updates article-specific Twitter/Open Graph values.
- The current Vite SPA deployment serves one generic `index.html` before hydration. True per-route metadata before client hydration is not available without prerendering or SSR. That limitation is documented rather than hidden; a full prerender migration is deferred to the next milestone.
- Local route-shell checks returned 200 for all known routes, but the initial HTML title remains generic before hydration. This is an unresolved SEO delivery risk.

## API findings

- Newsletter CORS now allows only:
  - `https://verlyse-react.vercel.app`
  - `http://localhost:5173`
  - `http://localhost:4173`
- `BUTTONDOWN_API_KEY` remains server-only.
- POST/OPTIONS method checks and email validation were preserved.
- Provider errors remain normalized to safe client-facing error codes.
- The in-memory per-IP limiter is explicitly documented as instance-local and not distributed protection.

## Tests passed

- `npm run check:secrets`
- `npm run build`
- `npm run typecheck:api`
- `git diff --check`
- Local preview direct route checks returned HTTP 200 for `/`, `/articles`, `/categories`, `/creators`, `/ambassadors`, `/community`, `/about`, `/submit`, `/contact`, `/room`, `/article/3-13`, and `/creator/alina-javed`.
- Local initial HTML verified `index, follow`.
- Tracked sensitive-file scan found no MCP, OAuth, credential, token, cookie, browser, PKI, private-key, or `.env` files; `.env.example` is the sole allowed placeholder.

## Tests blocked by environment

- Playwright/full browser audits remain blocked because the required Chromium executable is unavailable in the environment.
- Therefore this milestone does not claim mobile, keyboard, reduced-motion, WebGL-off, horizontal-overflow, focus, or rendered visual validation.

## Unresolved risks

1. Route-specific metadata is still client-hydrated in the Vite SPA.
2. The current homepage WebGL scene remains unchanged and may still be costly on mobile.
3. Newsletter rate limiting is not distributed across serverless instances.
4. The current CSP and API origin policy need a production smoke test after deployment; no deployment was performed by instruction.
5. A browser-capable audit environment is still required for the requested interaction and responsive acceptance checks.

## Exact next milestone recommendation

**Milestone B — Foundation**, beginning with a small route-metadata delivery spike (prerendered route shells or an explicitly evaluated server-capable approach), then newsletter/submission reliability and navigation/focus cleanup. Do not begin 3D or visual changes until route metadata delivery, browser audit availability, and the API security smoke test are resolved.
