# Verlyse — Route Matrix (summary)

Full JSON: `route-matrix-desktop.json` / `route-matrix-tablet.json` / `route-matrix-mobile.json` / `route-matrix.json`.

Coverage: **10 core + 7 category query states + 18 article detail + 15 creator detail = 49 routes per viewport** across **1440×900, 768×1024, 390×844** = **147 records**.

## Aggregate result
| Viewport | Routes | Console/page/net errors | Horiz overflow | Footer at true bottom |
|---|---|---|---|---|
| Desktop 1440×900 | 49 | **0** | **0** | **0** (all reach bottom) |
| Tablet 768×1024 | 49 | **0** | **0** | +62px* |
| Mobile 390×844 | 49 | **0** | **0** | +62px* |

\* The 62px mobile/tablet offset is the **designed fixed bottom Dock (`Dock.tsx` `h-[62px]`)**, which the footer clears via `max-[979px]:pb-32`. This is intentional mobile chrome, **not** clipping/covering (the footer is fully reachable and scrolls above the dock). Verified it also appears on untouched creator routes (uniform) → not introduced by the spatial work.

## Representative heights (local dev build)
| Route | Desktop | Tablet | Mobile |
|---|---|---|---|
| `/` | 14,574 | ~ | 18,758 |
| `/articles` | 8,867 | ~ | 8,701 |
| `/categories` | 3,812 | ~ | 5,073 |
| `/creators` | 7,051 | ~ | 14,837 |
| `/community` | 6,621 | ~ | 7,844 |
| `/about` | 7,405 | ~ | 10,521 |
| `/article/their-voices-matter` | 9,684 | ~ | 10,887 |
| `/article/3-13` | 12,041 | ~ | 13,859 |

Heights differ from the supplied reference baseline because this is the dev build plus the added spatial layer; all content sections/order are present (verified against canonical).

## Note on full-page screenshots
Static full-page captures show the hero + footer but the mid-page `Reveal` sections appear unfilled because their `whileInView` reveals never fire without scrolling. The content is present (confirmed by DOM text + `scrollHeight`); this is a capture-method artifact, not missing content.
