# Milestone B — Foundation Report

Date: 2026-09-04
Branch: `verlyse-architecture-remediation`
Deployment: none (explicitly not deployed)

## 1. Metadata delivery decision note

| Option | Effort | Vite/Router compatibility | Vercel behavior | Crawlers/social | Content workflow | Rollback | Decision |
|---|---:|---|---|---|---|---|---|
| Route-specific prerendered HTML | Low/medium | High; preserves React Router hydration | High; static route files plus explicit rewrites | Strong for selected routes | Requires build-time route list | Low | **Chosen for spike** |
| Vite-compatible static generation step | Low/medium | High | High | Strong for generated routes | Requires build-time generation | Low | Implemented as the prerender script |
| Server-capable React deployment | High | Requires migration | Requires deployment model change | Strong | Better long-term dynamic coverage | High | Deferred |
| Retain SPA only | Lowest | Existing | Existing | Weak before hydration | Easiest updates | Lowest | Rejected as the sole solution |

The chosen spike keeps the current React/Vite/React Router architecture and writes route-specific shells after the Vite build for:

- `/`
- `/articles`
- `/article/3-13`
- `/creator/alina-javed`

`vercel.json` now routes the three nested prerendered paths to their generated `index.html` files before the SPA catch-all. The full app remains client-side and the 3D lazy-loading architecture is unchanged.

The route list is intentionally explicit for this spike. The next metadata milestone should generate all article/contributor/category routes from the canonical registry rather than maintaining a hand-curated list.

## 2. Changed files

- `scripts/prerender-metadata.mjs` — Vite-compatible static metadata shell generation.
- `scripts/metadata-audit.mjs` — build-output metadata regression test.
- `scripts/newsletter-smoke.mjs` — synthetic provider-free API boundary smoke test.
- `package.json` — build now runs metadata prerendering; added metadata/newsletter test scripts.
- `vercel.json` — explicit rewrites for prerendered nested routes.
- `api/newsletter.ts` — environment-configurable CORS allowlist and rate-limit limitation documentation.
- `src/components/layout/Header.tsx` — avoids stealing focus on initial render; restores focus to the actual menu trigger after close.
- `src/components/layout/SavedDrawer.tsx` — moves focus into the drawer and adds Escape-close handling while preserving focus restoration.
- `audit/milestone-b-report.md` — this report.

No 3D, geometry, scene art direction, editorial copy, or content-registry files were changed.

## 3. Browser environment and results

Attempted to install the existing Playwright Chromium setup. Browser binaries downloaded successfully, but execution remains blocked by the environment because `libnspr4.so` is unavailable. Existing full-matrix and interaction audits therefore could not launch Chromium.

No browser-level claims are made for mobile, keyboard, reduced motion, WebGL-off, focus, or overflow behavior.

## 4. Route metadata results

- `npm run build`: passed.
- Build generated four route-specific HTML shells.
- `npm run test:metadata`: passed for all four spike routes.
- Each generated shell includes unique title, description, canonical URL, Open Graph image/type, Twitter metadata, indexing directive, and JSON-LD.
- Article shell contains Article JSON-LD.
- Contributor shell contains ProfilePage JSON-LD.
- Social image files were checked against production and returned HTTP 200.
- The Vite preview server serves the SPA fallback for clean nested URLs, so its clean URL response is not treated as proof of Vercel rewrite behavior. The output files and explicit Vercel rewrites were validated locally; production deployment remains intentionally pending.

## 5. API/security smoke results

`npm run test:newsletter` passed six synthetic checks without contacting Buttondown or any external provider:

- allowed production OPTIONS returns 204;
- allowed origin is echoed;
- disallowed origin is not echoed;
- GET is rejected;
- invalid email returns a safe normalized error;
- missing provider configuration returns a safe normalized error.

`ALLOWED_ORIGINS` can now configure a future custom production domain without a source edit. Defaults retain the production and local development origins.

`BUTTONDOWN_API_KEY` remains server-only. Provider authorization values are not present in client build output.

A history scan found no live-token/private-key pattern in tracked history after excluding the detector’s own pattern literals. Tracked sensitive filenames are absent. No secret values were printed.

## 6. Navigation/focus findings and fixes

Confirmed code-level issues addressed:

- Header focus management previously focused the menu trigger on every initial render; it now restores focus only after an actual menu close.
- Header menu focus still moves to the first menu link when opened.
- Saved drawer now moves focus to its close control and closes on Escape.
- Existing SearchOverlay focus entry, Escape-close, body scroll lock, and opener restoration were preserved.
- Existing menu/dialog labels and `aria-expanded`/`aria-controls` behavior were preserved.

Browser verification of these changes is blocked by the missing system library described above.

## 7. Submission boundary findings

No submission UI or external form behavior was changed in this milestone.

Current confirmed boundary:

- client-side required-field and email validation exists;
- submission posts directly from the browser to FormSubmit;
- on failure, the UI falls back to a `mailto:` URL;
- there is no durable Verlyse submission record;
- there is no server-side validation boundary for submissions;
- selected file handling records the filename but does not upload/deliver the file;
- delivery success is not an editorial-system acknowledgement.

Next submission milestone should introduce a server-side provider adapter, explicit file limits/storage, spam controls, durable status, and confirmed provider responses. No real form was submitted.

## 8. Dependency/build notes

- GSAP remains declared but no source import was found. Removal should be a separate cleanup commit after confirming no indirect or planned runtime use.
- Build continues to pass with the existing non-blocking Three.js chunk warning.
- No new runtime dependency was added.

## 9. Tests passed

- `npm run build`
- `npm run test:metadata`
- `npm run test:newsletter`
- `npm run check:secrets`
- `npm run typecheck:api`
- `git diff --check`
- production social image HEAD checks: both returned HTTP 200
- direct local preview route checks: all known routes returned HTTP 200

## 10. Tests blocked

- `npm run test` / full browser matrix: blocked by Chromium `libnspr4.so` environment dependency.
- `scripts/interaction-audit.mjs`: same blocker.
- Rendered viewport, mobile overflow, keyboard focus, reduced-motion, WebGL-off, and real overlay behavior remain unverified.
- Production route-shell behavior is not claimed because deployment was intentionally not performed.

## 11. Unresolved risks

1. The prerender spike covers four routes only; article/contributor/category route generation is still incomplete.
2. Vercel behavior must be smoke-tested after explicit deployment approval.
3. Browser audits require a runtime image with `libnspr4.so` or an accepted alternative.
4. Submission remains a direct third-party forwarding prototype with no durable editorial workflow.
5. Newsletter rate limiting remains instance-local.
6. GSAP remains an unused declared dependency.

## Exact Milestone C recommendation

Do not begin the immersive vertical slice yet. First complete the deferred Milestone B gates:

1. run the four prerendered routes on a preview deployment and verify clean URL initial HTML;
2. generate metadata shells from the canonical registry for all article and contributor routes;
3. provide a browser-capable audit environment or formally accept the limitation;
4. complete the server-side submission boundary design and approval;
5. perform browser validation of navigation/focus changes.

Only after those gates pass should Milestone C begin with a **mobile-only spatial quality controller spike**, not new scene art: static/ambient/interactive tiers, 4–6 initial textures, offscreen pause, capped DPR, and a visible non-WebGL archive path.
