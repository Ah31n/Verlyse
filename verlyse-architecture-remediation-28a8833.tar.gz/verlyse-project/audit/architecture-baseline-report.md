# Verlyse Media Architecture Remediation — Baseline

Date: 2026-09-04
Scope: inspection only; no application code was changed during this audit turn.
Production reference: https://verlyse-react.vercel.app

## Rollback and repository state

- The project directory is **not a Git repository** (`git status` failed), so a branch could not be created.
- A sanitized rollback copy was created at `/home/user/verlyse-architecture-remediation-baseline`.
- The backup excludes `.mcp.json`, `.mcp.json.example`, `.cursor/`, `.vscode/`, `.vercel/`, `.env*`, `node_modules/`, `dist/`, and TypeScript build metadata.
- Existing `.gitignore` excludes `node_modules`, `dist`, `.vercel`, `.env`, and local MCP configs. It should be expanded for broader credential/browser/PKI patterns in a future safety milestone.

## Confirmed findings

### P0 — production indexing is disabled

`index.html` contains `noindex, nofollow`, while `public/robots.txt` allows crawling and publishes a sitemap. This contradicts the public-magazine requirement and prevents normal discovery.

### P0 — sensitive local configuration files exist in the workspace

The source tree contains `.mcp.json`, `.cursor/mcp.json`, and `.vscode/mcp.json`. They are ignored by the current `.gitignore`, but their presence in the workspace is a sensitive-artifact risk. They were excluded from the sanitized rollback copy. No secret values are reproduced in this report.

A live credential was also exposed in the conversation history; rotation is required before any MCP or deployment work continues.

### P1 — production metadata is client-side only

`useSeo.ts` updates title, description, canonical, Open Graph, and JSON-LD in `useEffect`. The initial HTML has only generic metadata, so direct crawlers and social scrapers may not receive route-specific metadata without executing JavaScript. Article JSON-LD exists client-side, but there is no confirmed prerender/server-render strategy.

### P1 — CSP and API CORS need tightening

`vercel.json` applies a CSP, but `api/newsletter.ts` sends `Access-Control-Allow-Origin: *`. The newsletter endpoint also accepts any origin while the frontend calls it same-origin. This should be narrowed to approved origins in a security milestone.

### P1 — homepage WebGL is continuously active

`SpatialArchive.tsx` renders a Three.js canvas with `frameloop="always"`, DPR `[1, 1.5]`, and one textured plane per article in the registry. The current baseline therefore loads/animates 19 cover planes when the scene activates. `StoryEnding3D.tsx` also uses an always-running loop during its active phase. These are confirmed likely contributors to mobile lag; runtime frame measurements require a browser executable.

### P1 — no automated browser baseline is currently runnable

`npm run test`, `verify-flags.mjs`, and `asset-audit.mjs` stop because the Playwright Chromium executable is not installed in the workspace environment. Earlier browser validation also encountered missing system libraries. Rendered viewport, keyboard, reduced-motion, WebGL-off, and overflow claims therefore remain unverified in this audit run.

### P2 — large initial build assets

Current production build output includes approximately:

- `react` chunk: 278.27 kB minified / 89.76 kB gzip
- `three` chunk: 770.45 kB minified / 203.46 kB gzip
- `motion` chunk: 122.86 kB minified / 40.91 kB gzip
- main index chunk: 133.34 kB minified / 42.83 kB gzip
- CSS: 117.60 kB minified / 20.77 kB gzip

The build emits the existing non-blocking chunk-size warning for Three.js.

### P2 — GSAP appears unused

`gsap` is declared in `package.json`, but no application source import was found. It should be removed or deliberately adopted after dependency verification.

## Confirmed working baseline

- Direct production HTTP requests returned 200 for `/`, `/articles`, `/categories`, `/creators`, `/ambassadors`, `/community`, `/about`, `/submit`, `/contact`, `/room`, `/article/3-13`, and `/creator/alina-javed`.
- `npm run build`: passed.
- `npm run typecheck:api`: passed.
- Typed content registry currently contains 19 articles, 16 authors, 7 categories, and 4 community-stat entries.
- Route-level lazy loading exists in `src/App.tsx`.
- WebGL support detection and reduced-motion checks exist.
- Semantic HTML remains the source for article content; WebGL components are marked `aria-hidden` in the inspected spatial code.
- Newsletter provider key is read server-side from `BUTTONDOWN_API_KEY`, not client source.

## Test results

| Check | Result | Notes |
|---|---|---|
| TypeScript/Vite build | PASS | Existing large Three.js advisory remains |
| API typecheck | PASS | `tsconfig.api.json` |
| Full automated audit | BLOCKED | Playwright browser executable missing |
| Browser interaction audit | BLOCKED | Same missing Playwright executable |
| Asset audit | BLOCKED | Same missing Playwright executable |
| Direct production routes | PASS | All sampled routes returned HTTP 200 |
| Git clean/branch | BLOCKED | Repository has no `.git` directory |

## Architecture map

- `src/data/content.ts`: canonical typed registry for articles/authors/categories.
- `src/App.tsx`: React Router route table and route-level lazy imports.
- `src/hooks/useSeo.ts`: client-side route metadata and JSON-LD.
- `src/components/spatial/SpatialArchive.tsx`: homepage WebGL scene.
- `src/components/spatial/StoryEnding3D.tsx`: article-ending WebGL scene.
- `src/components/room/Room.tsx`: full-screen spatial archive experience.
- `api/newsletter.ts`: Buttondown serverless subscription boundary.
- `vercel.json`: security headers and SPA/API rewrites.

## Recommended next milestone

Milestone A safety should precede visual work:

1. Rotate the exposed credential and remove sensitive MCP artifacts from the active project workspace.
2. Create a real Git rollback point outside the sanitized snapshot.
3. Expand ignore and secret-detection rules.
4. Resolve the indexing decision (`noindex` versus public magazine) explicitly.
5. Install a compatible browser for the audit environment or document a supported alternative.
6. Add route metadata tests and a WebGL performance probe before changing the spatial controller.
7. Then implement a mobile-only spatial quality tier, preserving the desktop visual direction.
