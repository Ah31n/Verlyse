# PHASE 21 — GLOBAL IMMERSIVE TRANSFORMATION · SLICES A & B

**Project:** Verlyse Media · **Mode:** Arena local dev only · **No deployment**
**Design source of truth:** Penpot Phase-19 system (the Keeping Room language applied site-wide)

---

## What was delivered this slice

### 1. `GLOBAL-TRANSFORMATION-MAP.md` (the mandated §30 deliverable)

Complete route-by-route map: current experience → new spatial experience → reused systems → new components → motion → 3D → responsive, for every route (`/`, `/articles`, `/article/:id`, `/categories`, `/creators`, `/creator/:id`, `/ambassadors`, `/community`, `/about`, `/submit`, `/contact`, `/room`) plus the shared architecture (world/camera/depth/plates/thread/light/focus/transitions/reduced-motion) and the C→K slice plan.

### 2. Phase A — Global shell

**`src/App.tsx` — archival threshold page transition (replaces the generic magazine fade):**
- Every navigation now passes through a **wine veil (`#2A0F18`) + brass thread** that draws across with a **route-aware folio label**, then the page settles like a plate.
- Labels: `/` → "The archive" · `/articles` → "Nineteen folios" · `/article/:id` → **"Folio №NN · Reading"** (real folio number from the registry) · `/categories` → "The index" · `/creators` → "The contributors" · `/creator/:id` → "A contributor dossier" · `/ambassadors` → "The people" · `/community` → "The commons" · `/about` → "The colophon" · `/submit` → "Send a voice" · `/contact` → "The desk".
- The veil is skipped on the **very first load** (the preloader owns that entrance) and under **prefers-reduced-motion** (verified: no veil, instant).

**`src/components/layout/Header.tsx` — archival-instrument navigation:**
- Primary nav links now carry **folio indices** (`01 Articles · 02 Categories · 03 Featured Creators · 04 Community · 05 Brand Ambassador · 06 About`), gold when active — the nav reads like a numbered archive instrument while remaining plain accessible text + `aria-current`.

### 3. Phase B — Homepage (primary archive entrance)

**`src/pages/Home.tsx` (Cover only, nothing protected touched):**
- **Ghost folio numeral `01`** engraved behind the headline (stroke-only, aria-hidden) — the archive's first plate behind the words.
- **"Pull → Read → Return"** mono line with a brass rule under the CTAs — the global interaction vocabulary taught in one quiet line.
- CTA renamed **"Pull folio 01 →"** (was "Read the current feature") — the featured story's physical pull affordance.

Everything else on the homepage (Three.js SpatialArchive cover, feature plate, ink flourish, ledger, folio bar) already realized the archive-entrance concept and was left untouched.

---

## Validation (real Chromium)

| Check | Result |
|---|---|
| Home: PULL→READ→RETURN vocabulary | ✅ |
| Home: "Pull folio 01" affordance | ✅ |
| Home: ghost folio numeral | ✅ |
| Header: folio-indexed nav | ✅ |
| Navigation → archival threshold veil | ✅ |
| Threshold label "Nineteen folios" (route-aware) | ✅ |
| Reduced-motion: no veil, instant | ✅ |
| All routes 200 (`/`…`/contact`, `/article/:id`, `/creator/:id`) | ✅ (1× 304 = cached revisit) |
| Console clean (home, nav, routes, reduced-motion) | ✅ |
| `tsc --noEmit` | ✅ 0 errors |
| `npm run build` | ✅ (Home 33.7 kB gzip 8.4 kB; index 122.8 kB gzip 40.7 kB — no new deps) |
| **Protected files (12 + `spatial/*` + `three/*`)** | ✅ **0 diffs** vs Phase 20.5 baseline |
| **`/room` regression (Phase 20.5 suite)** | ✅ **89/89 PASS** |

Screenshots: `audit/shots/phase21-home.png`, `phase21-articles-after-nav.png`.
Harness + results: `audit/phase21-ab-validate.mjs`, `audit/phase21-ab-results.json`.

---

## Next slices (C → K, per the map)

- **C** `/articles` → archive shelf of 19 folio plates on the brass thread (CSS-3D, deterministic).
- **D/E** article pull entry + canonical reading integration (threshold already announces "Folio №NN · Reading").
- **G** `/categories` → spatial reorganization (members brighten/approach, others recede).
- **H** `/creators` → contributor dossiers · **I** `/ambassadors` → archival people wall.
- **J/K** search continuity + remaining routes; **L** `/room` disposition + full-site audit.

Each slice will follow the same discipline: build → run → inspect → test → fix, with the protected-file baseline re-verified after every change.

---

## Safety

No deployment · no InfinityFree/kesug/Vercel/DNS/FTP · no credentials · no new dependencies · no invented content · `index.css`, `motion.ts`, `ArticleDetail`, `StoryEnding3D`, `ArticleClosing`, `ArticleWorld`, `Motifs`, `VibeAmbient`, `SpatialArchive`, `three/*`, `package.json/lock`, `vite.config.ts` all untouched.
