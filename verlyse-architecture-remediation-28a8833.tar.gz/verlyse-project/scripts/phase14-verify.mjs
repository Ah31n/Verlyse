/* Phase 14 runtime verification — routes, console, assets, hydration. */
import puppeteer from 'puppeteer'

const BASE = process.env.BASE_URL || 'http://localhost:4173'

const ROUTES = [
  { path: '/', expect: ['19 features'] },
  { path: '/about', expect: [] },
  { path: '/articles', expect: ['Mir Raza Ali'] },
  { path: '/article/mir-raza-ali', expect: ['Dispatch', 'Wafflix', 'Demand a fair investigation', 'Within the post'] },
  { path: '/article/behind-every-headline', expect: ['Behind Every Headline'] },
  { path: '/article/their-voices-matter', expect: ['Their Voices Matter'] },
  { path: '/categories', expect: ['Social Issues', '4 features within'] },
  { path: '/community', expect: ['585'] },
  { path: '/submit', expect: [] },
  { path: '/ambassadors', expect: ['Zainab Khan', 'Head of Research Department', 'Javeria Karim', 'Ahsan Ashfaq'] },
  { path: '/creators', expect: ['Verlyse Media', 'Mochi'] },
  { path: '/creator/verlyse-media', expect: ['Verlyse Media', 'The platform'] },
  { path: '/creator/alina-javed', expect: ['Alina Javed'] },
  { path: '/contact', expect: [] },
]

const browser = await puppeteer.launch({
  headless: 'new',
  args: ['--no-sandbox', '--disable-gpu', '--use-gl=swiftshader', '--window-size=1440,900'],
})

const results = []
const failRequests = new Set()
const consoleErrors = new Map()

async function visit(page, path, expect = []) {
  failRequests.clear()
  const row = { path, status: 'ok', console: [], missing: [], failedRequests: [], imgBroken: 0 }
  const onConsole = (m) => { if (m.type() === 'error') row.console.push(m.text().slice(0, 200)) }
  const onPageError = (e) => row.console.push('PAGEERROR: ' + String(e.message).slice(0, 200))
  const onReqFail = (r) => {
    if (!r.response()) row.failedRequests.push(r.url().replace(BASE, '') + ' (' + (r.failure()?.errorText || 'failed') + ')')
  }
  const onResp = (r) => { if (r.status() >= 400) row.failedRequests.push(r.status() + ' ' + r.url().replace(BASE, '')) }
  page.on('console', onConsole)
  page.on('pageerror', onPageError)
  page.on('requestfailed', onReqFail)
  page.on('response', onResp)

  try {
    await page.goto(BASE + path, { waitUntil: 'networkidle2', timeout: 45000 })
  } catch (e) { row.status = 'NAVFAIL: ' + String(e).slice(0, 120) }
  await new Promise((r) => setTimeout(r, 3500)) // let reveals + motion settle

  // scroll through the page so every whileInView reveal has fired
  await page.evaluate(async () => {
    const h = document.body.scrollHeight
    for (let y = 0; y <= h; y += 700) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 120)) }
    window.scrollTo(0, 0)
  })
  await new Promise((r) => setTimeout(r, 800))

  const raw = await page.evaluate(() => document.body.innerText)
  const text = raw.replace(/\s+/g, ' ')
  const squashed = raw.replace(/\s+/g, '')
  const low = text.toLowerCase()
  for (const ex of expect) {
    const e = ex.replace(/\s+/g, ' ').toLowerCase()
    if (!low.includes(e) && !squashed.toLowerCase().includes(ex.replace(/\s+/g, ''))) row.missing.push(ex)
  }

  // broken images (loaded <img> whose naturalWidth is 0)
  row.imgBroken = await page.evaluate(() =>
    Array.from(document.images).filter((im) => im.complete && im.naturalWidth === 0).length
  )

  page.off('console', onConsole)
  page.off('pageerror', onPageError)
  page.off('requestfailed', onReqFail)
  page.off('response', onResp)
  return row
}

const page = await browser.newPage()
await page.setViewport({ width: 1440, height: 900 })

for (const r of ROUTES) {
  const row = await visit(page, r.path, r.expect)
  results.push(row)
  const flag = row.status !== 'ok' || row.console.length || row.missing.length || row.failedRequests.length || row.imgBroken
  console.log(`${flag ? '✗' : '✓'} ${r.path.padEnd(34)} ${row.status} console=${row.console.length} missing=[${row.missing}] failedReq=[${row.failedRequests.slice(0, 4)}] brokenImg=${row.imgBroken}`)
}

// direct asset checks
const assets = [
  '/img/works/DciqQXTCilh-1.webp', '/img/works/DciqQXTCilh-2.webp', '/img/works/DciqQXTCilh-3.webp',
  '/img/inner/mir-raza-wafflix-cart.webp', '/img/inner/mir-raza-justice-rally.webp',
]
await page.goto(BASE + '/', { waitUntil: 'networkidle2' })
for (const a of assets) {
  const r = await page.evaluate(async (u) => {
    try { const res = await fetch(u); const b = await res.arrayBuffer(); return { ok: res.ok, status: res.status, size: b.byteLength } }
    catch (e) { return { ok: false, status: 0, size: 0 } }
  }, a)
  const ok = r.ok && r.size > 2000
  console.log(`${ok ? '✓' : '✗'} asset ${a} ${ok ? 'OK (' + r.size + 'B)' : 'BROKEN (HTTP ' + r.status + ')'}`)
  results.push({ path: 'asset:' + a, status: ok ? 'ok' : 'BROKEN', console: [], missing: [], failedRequests: [], imgBroken: 0 })
}

// refresh test (hard reload on the article route — SPA rewrite must resolve)
const row2 = await visit(page, '/article/mir-raza-ali', ['Dispatch', 'Demand a fair investigation'])
console.log(`${row2.status === 'ok' && !row2.missing.length ? '✓' : '✗'} refresh /article/mir-raza-ali (hard) ${row2.missing.length ? 'missing=' + row2.missing : 'ok'}`)

// screenshots: new article at 3 viewports + ambassadors team
const shots = [
  { name: 'p14-article-desktop', path: '/article/mir-raza-ali', w: 1440, h: 900, full: true },
  { name: 'p14-article-tablet', path: '/article/mir-raza-ali', w: 768, h: 1024, full: true },
  { name: 'p14-article-mobile', path: '/article/mir-raza-ali', w: 390, h: 844, full: true },
  { name: 'p14-ambassadors-desktop', path: '/ambassadors', w: 1440, h: 900, full: true },
  { name: 'p14-home-desktop', path: '/', w: 1440, h: 900, full: false },
]
for (const s of shots) {
  await page.setViewport({ width: s.w, height: s.h })
  await page.goto(BASE + s.path, { waitUntil: 'networkidle2', timeout: 45000 })
  await new Promise((r) => setTimeout(r, 4500))
  await page.screenshot({ path: `/home/user/phase14-verify/${s.name}.png`, fullPage: s.full })
  console.log(`✓ shot ${s.name}`)
}

const bad = results.filter((r) => r.status !== 'ok' || r.console.length || r.missing.length || r.failedRequests.length || r.imgBroken)
console.log('\n==== SUMMARY ====')
console.log(`routes+assets checked: ${results.length}, problems: ${bad.length}`)
await browser.close()
process.exit(bad.length ? 1 : 0)
