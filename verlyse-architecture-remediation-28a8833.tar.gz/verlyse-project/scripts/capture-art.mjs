/* eslint-disable no-console */
import { chromium } from '@playwright/test'
import * as fs from 'node:fs'
import * as path from 'node:path'
const BASE = 'http://127.0.0.1:5173'
const OUT = path.resolve('audit/screenshots')

async function run() {
  fs.mkdirSync(OUT, { recursive: true })
  const browser = await chromium.launch()

  // Homepage hero (spatial archive) — desktop + mobile
  for (const [name, vp] of Object.entries({ desktop: { w: 1440, h: 900 }, mobile: { w: 390, h: 844 } })) {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } })
    const page = await ctx.newPage()
    await page.goto(BASE + '/', { waitUntil: 'networkidle' })
    await page.waitForTimeout(2600)
    // scroll hero into spatial view then back to top for the masthead
    await page.evaluate(() => window.scrollTo(0, 0))
    await page.waitForTimeout(800)
    await page.screenshot({ path: path.join(OUT, `hero-${name}.png`) })
    await ctx.close()
  }

  // Story ending scene for two distinct articles (desktop)
  for (const slug of ['their-voices-matter', '3-13']) {
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } })
    const page = await ctx.newPage()
    await page.goto(BASE + '/article/' + slug, { waitUntil: 'networkidle' })
    await page.waitForTimeout(1200)
    // scroll to the ending region so the scene activates
    await page.locator('#ending').scrollIntoViewIfNeeded()
    await page.waitForTimeout(2600)
    await page.screenshot({ path: path.join(OUT, `ending-${slug}.png`) })
    await ctx.close()
  }

  await browser.close()
  console.log('Captured hero + ending art-direction screenshots')
}
run().catch((e) => { console.error(e); process.exit(1) })
