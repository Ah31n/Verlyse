/* Phase 15 — content registry integrity (audit-only, no writes to src) */
import { build } from 'esbuild'
import { readFileSync, existsSync, readdirSync } from 'fs'
import { fileURLToPath } from 'url'
import path from 'path'

const root = '/home/user/verlyse-project'
const out = '/tmp/verlyse-content.mjs'
await build({
  entryPoints: [path.join(root, 'src/data/content.ts')],
  bundle: true, format: 'esm', outfile: out, platform: 'node',
  loader: { '.ts': 'ts' },
})
const C = await import(out)
const { ARTICLES, AUTHORS, CATEGORIES, COMMUNITY_STATS, BRAND } = C

let pass = 0, fail = 0
const ok = (c, label, extra = '') => { c ? pass++ : fail++; console.log(`${c ? '✓' : '✗'} ${label}${extra ? ' — ' + extra : ''}`) }

/* ---------- ARTICLES ---------- */
const ids = ARTICLES.map(a => a.id)
ok(new Set(ids).size === ids.length, 'article ids unique', `${ids.length} articles`)
const titles = ARTICLES.map(a => a.title)
ok(new Set(titles).size === titles.length, 'article titles unique')
const codes = ARTICLES.map(a => a.shortCode)
ok(new Set(codes).size === codes.length, 'article shortCodes unique')
const catNames = new Set(CATEGORIES.map(c => c.name))
ok(ARTICLES.every(a => catNames.has(a.category)), 'every article category exists in CATEGORIES')
const authorIds = new Set(AUTHORS.map(a => a.id))
const badRefs = ARTICLES.filter(a => !authorIds.has(a.authorId))
ok(badRefs.length === 0, 'every authorId resolves to AUTHORS', badRefs.length ? badRefs.join(',') : '')

/* asset existence for every referenced image */
const referenced = new Set()
for (const a of ARTICLES) {
  referenced.add(a.cover)
  if (a.thumbnail) referenced.add(a.thumbnail)
  a.slides.forEach(s => referenced.add(s))
  ;(a.figures ?? []).forEach(f => referenced.add(f.src))
}
const missing = [...referenced].filter(p => !existsSync(path.join(root, 'public', p)))
ok(missing.length === 0, 'every referenced image exists in public/', missing.length ? missing.join(',') : `${referenced.size} assets checked`)
const imgFiles = []
const walk = d => { for (const e of readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else imgFiles.push('/' + p.slice(root.length + 1)) } }
walk(path.join(root, 'public'))
const unreferenced = imgFiles.filter(p => p.startsWith('/img/') && !referenced.has(p) && !imgFiles.includes(p))
console.log(`  info: ${imgFiles.filter(p => p.startsWith('/img/')).length} image files, ${referenced.size} referenced by registry`)

/* dates valid + ordering */
const dateRe = /^\d{4}-\d{2}-\d{2}$/
ok(ARTICLES.every(a => dateRe.test(a.date)), 'all dates YYYY-MM-DD')
const byDate = ARTICLES.slice().sort((a, b) => b.date.localeCompare(a.date))
console.log('  info: latest-first order: ' + byDate.slice(0, 8).map(a => `${a.id} (${a.date})`).join(', '))

/* required fields */
const req = ['id', 'title', 'authorId', 'category', 'excerpt', 'readingTime', 'date', 'cover', 'slides', 'tags', 'body', 'likes', 'comments', 'shortCode', 'voices']
const missingFields = ARTICLES.filter(a => req.some(f => a[f] === undefined || a[f] === null)).map(a => a.id)
ok(missingFields.length === 0, 'all required schema fields present', missingFields.join(','))
const newArt = ARTICLES.find(a => a.id === 'mir-raza-ali')
ok(!!newArt, 'mir-raza-ali present')
ok(ARTICLES.length === 19, 'ARTICLES.length === 19')
ok(ARTICLES[0].id === 'their-voices-matter', 'FEATURED = ARTICLES[0] is their-voices-matter (unchanged cover story)')
ok(ARTICLES[ARTICLES.length - 1].id === 'mir-raza-ali', 'new article appended at end (no reordering)')

/* ---------- AUTHORS ---------- */
ok(new Set(AUTHORS.map(a => a.id)).size === AUTHORS.length, 'author ids unique', `${AUTHORS.length} authors`)
const humans = AUTHORS.filter(a => a.id !== 'verlyse-media')
ok(humans.length === 15, '15 credited human creators')
ok(!!AUTHORS.find(a => a.id === 'verlyse-media' && a.name === 'Verlyse Media' && a.handle === '@verlyse.media'), 'platform author record exact')
const plat = AUTHORS.find(a => a.id === 'verlyse-media')
ok(!plat.portrait && !plat.profilePhoto, 'platform author has no portrait (monogram treatment)')

/* ---------- CATEGORIES counts vs actual ---------- */
const actual = {}
ARTICLES.forEach(a => { actual[a.category] = (actual[a.category] ?? 0) + 1 })
for (const c of CATEGORIES) ok(actual[c.name] === c.count, `category "${c.name}" count ${c.count} matches registry (${actual[c.name] ?? 0})`)

/* ---------- COMMUNITY totals vs sums ---------- */
const sumComments = ARTICLES.reduce((s, a) => s + a.comments, 0)
const sumLikes = ARTICLES.reduce((s, a) => s + a.likes, 0)
const st = Object.fromEntries(COMMUNITY_STATS.map(s => [s.label, s.value]))
ok(+st['Features presented'] === ARTICLES.length, `features stat ${st['Features presented']} === 19`)
ok(+st['Conversations'] === sumComments, `conversations stat ${st['Conversations']} === sum of comments (${sumComments})`)
ok(+st['Appreciations'] === sumLikes, `appreciations stat ${st['Appreciations']} === sum of stored likes (${sumLikes})`)
ok(+st['Creators credited'] === 15, 'creators-credited stat === 15')

/* ---------- BRAND.team ---------- */
const team = BRAND.team
ok(team.length === 12, 'BRAND.team has 12 rows (11 + Zainab Khan)')
ok(new Set(team.map(m => m.name)).size === team.length, 'team names unique')
const zainab = team[team.length - 1]
ok(zainab && zainab.name === 'Zainab Khan' && zainab.role === 'Head of Research Department', 'Zainab Khan is FINAL row, exact name + exact role', JSON.stringify(zainab))
ok(team.every(m => !('portrait' in m) && !('photo' in m)), 'team rows use monogram structure (no image fields)')
ok(team[8].name === 'Javeria Karim' && team[0].name === 'Ana Fatima', 'existing team order preserved (first + ambassador head rows intact)')

/* ---------- related derivation — no crash, deterministic ---------- */
const { relatedArticles } = C
for (const a of ARTICLES) { const r = relatedArticles(a); ok(r.length <= 3 && r.every(x => x.id !== a.id), `related(${a.id}) safe`, r.map(x => x.id).join(' + ') || '(none)') }
const upNextBehind = relatedArticles(ARTICLES.find(a => a.id === 'behind-every-headline'))
console.log('  info: up-next on behind-every-headline → ' + upNextBehind.map(x => x.title).join(' / '))

/* ---------- sitemap cross-check ---------- */
const sm = readFileSync(path.join(root, 'public/sitemap.xml'), 'utf8')
const smArticles = [...sm.matchAll(/\/article\/([a-z0-9-]+)<\/loc>/g)].map(m => m[1])
const smCreators = [...sm.matchAll(/\/creator\/([a-z0-9-]+)<\/loc>/g)].map(m => m[1])
ok(smArticles.length === ARTICLES.length, `sitemap article urls (${smArticles.length}) === registry (${ARTICLES.length})`)
ok(ARTICLES.every(a => smArticles.includes(a.id)), 'every article in sitemap')
ok(smCreators.length === AUTHORS.length && smCreators.every(x => authorIds.has(x)), `sitemap creator urls (${smCreators.length}) === registry (${AUTHORS.length})`)
console.log(`  info: sitemap creators (${smCreators.length}) match registry (${AUTHORS.length})`)

console.log(`\n==== PHASE 15 REGISTRY INTEGRITY: ${pass} passed, ${fail} failed ====`)
process.exit(fail ? 1 : 0)
