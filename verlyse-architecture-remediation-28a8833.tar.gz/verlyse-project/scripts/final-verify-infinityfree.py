#!/usr/bin/env python3
"""FINAL InfinityFree deployment verification (lean, hang-safe).
Directories known to exist (verified): htdocs/, htdocs/assets, htdocs/fonts,
htdocs/img, htdocs/img/works, htdocs/img/inner, htdocs/img/authors, htdocs/img/signatures.
- Non-image files + .htaccess: BYTE-EXACT sha256.
- Images: must decode with PIL and match local width/height (InfinityFree
  re-encodes images server-side — by-design byte difference, geometry is the contract).
- Extra files = any server entry beyond the local manifest (excluding .well-known/).
Log: audit/deploy-final-verify.log. Exit 0 iff all pass."""
import ftplib, os, hashlib, sys, io, time
from PIL import Image

DIST = '/home/user/verlyse-project/dist'
HTACCESS_LOCAL = '/tmp/live-old/.htaccess'
# ---------------------------------------------------------------------------
# SECURITY — credentials are NEVER committed to source control.
# The FTP account previously hardcoded here was leaked in this repository and
# is treated as COMPROMISED and REVOKED. Do not reuse it, do not re-add it.
#
#   ACTION REQUIRED: the exposed FTP credentials must be revoked and replaced
#   via a secure vault before any deployment.
#
# Supply fresh credentials only at run time, via environment variables or
# CI/CD secrets (never in code, never in committed .env files):
#   export FTP_HOST=ftpupload.net FTP_PORT=21 FTP_USER=... FTP_PASS=...
# ---------------------------------------------------------------------------
HOST = os.environ.get('FTP_HOST', 'ftpupload.net')
PORT = int(os.environ.get('FTP_PORT', '21'))
USER = os.environ.get('FTP_USER', '')
PASS = os.environ.get('FTP_PASS', '')
if not USER or not PASS:
    raise SystemExit(
        'FTP_USER / FTP_PASS are not set — supply via environment or CI secrets.\n'
        'ACTION REQUIRED: the exposed FTP credentials must be revoked and replaced\n'
        'via a secure vault before any deployment.'
    )
DIRS = ['htdocs', 'htdocs/assets', 'htdocs/fonts', 'htdocs/img',
        'htdocs/img/works', 'htdocs/img/inner', 'htdocs/img/authors', 'htdocs/img/signatures']
LOG = open('/home/user/verlyse-project/audit/deploy-final-verify.log', 'w', buffering=1)

def log(m):
    print(m, flush=True); LOG.write(m + '\n')

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(65536), b''): h.update(c)
    return h.hexdigest()

def is_image(r): return r.lower().endswith(('.webp', '.jpg', '.jpeg', '.png'))

local = {}
for base, dirs, files in os.walk(DIST):
    rel = os.path.relpath(base, DIST)
    for fn in files:
        r = fn if rel == '.' else f'{rel.replace(os.sep, "/")}/{fn}'
        local[r] = os.path.join(base, fn)
local['.htaccess'] = HTACCESS_LOCAL
log(f'local files: {len(local)}')

def connect():
    for t in range(4):
        try:
            f = ftplib.FTP()
            f.connect(HOST, PORT, timeout=45)
            f.login(USER, PASS)
            f.cwd('/')
            return f
        except Exception as e:
            log(f'  connect fail ({t+1}): {str(e)[:40]}')
            time.sleep(5)
    raise SystemExit('cannot connect')

def nlst(ftp, d):
    for t in range(4):
        try:
            return ftp.nlst(d)
        except Exception as e:
            log(f'  nlst retry {d} ({t+1}): {str(e)[:40]}')
            time.sleep(4)
            try: ftp.quit()
            except Exception: pass
            ftp = connect()
    return []

# 1. server file set from per-dir NLST (no cwd probing)
ftp = connect()
server = set()
for d in DIRS:
    for e in nlst(ftp, d):
        rel = e[len(d):].lstrip('/')
        if rel:
            server.add(rel)
    time.sleep(1)
log(f'server files: {len(server)}')
extra = sorted(s for s in (server - set(local)) if not s.startswith('.well-known/'))
missing_files = sorted(set(local) - server)
log(f'missing on server: {len(missing_files)} {missing_files[:12]}')
log(f'extra on server (stale): {len(extra)} {extra[:12]}')
ftp.quit()

# 2. per-file check
fails = []
ftp = connect()
for i, rel in enumerate(sorted(local), 1):
    lp = local[rel]; data = None
    try:
        for attempt in range(3):
            try:
                buf = []
                ftp.retrbinary(f'RETR htdocs/{rel}', lambda b: buf.append(b))
                data = b''.join(buf)
                break
            except Exception as e:
                if attempt == 2:
                    log(f'  RETR-FAIL {rel}: {str(e)[:45]}'); fails.append(rel); data = None
                else:
                    time.sleep(4); ftp = connect()
        if data is None: continue
        if is_image(rel):
            try:
                rd = Image.open(io.BytesIO(data)); rd.load(); rd = (rd.width, rd.height)
                im = Image.open(lp); im.load(); ld = (im.width, im.height)
            except Exception as e:
                log(f'  BAD-IMAGE {rel}: {str(e)[:45]}'); fails.append(rel); continue
            if rd == ld:
                if i % 15 == 0 or i == len(local):
                    log(f'  ok-img   {i}/{len(local)} {rel} {rd[0]}x{rd[1]}')
            else:
                log(f'  DIM-DIFF {rel} remote {rd} local {ld}'); fails.append(rel)
        else:
            got = hashlib.sha256(data).hexdigest(); exp = sha(lp)
            if got == exp:
                if i % 15 == 0 or i == len(local):
                    log(f'  ok-bytes {i}/{len(local)} {rel}')
            else:
                log(f'  BYTE-MISMATCH {rel} (remote {len(data)}B vs local {os.path.getsize(lp)}B)')
                fails.append(rel)
        if i % 10 == 0:
            try: ftp.quit()
            except Exception: pass
            time.sleep(2); ftp = connect()
    except SystemExit:
        raise
    except Exception as e:
        log(f'  ERROR {rel}: {str(e)[:45]}'); fails.append(rel)
try: ftp.quit()
except Exception: pass

log('================ FINAL RESULT ================')
if missing_files: log('MISSING: ' + ', '.join(missing_files))
if extra: log('EXTRA/STALE: ' + ', '.join(extra))
if fails:
    log(f'FAILURES ({len(fails)}): ' + ', '.join(fails)); log('FINAL: FAIL'); sys.exit(1)
log(f'FINAL: PASS — all {len(local)} files present; text/code/font/htaccess byte-exact; all images valid with matching dimensions; no stale files')
