#!/usr/bin/env python3
"""Deploy dist/ to InfinityFree (kesug.com mirror) — v2.
Absolute-path STOR from the virtual root; chunked sessions; restores the
established .htaccess; verifies by size + content hash on the key file."""
import ftplib, os, hashlib, sys, time

HOST, PORT = 'ftpupload.net', 21
# ---------------------------------------------------------------------------
# SECURITY — credentials are NEVER committed to source control.
# The FTP account previously hardcoded here was leaked in this repository and
# is treated as COMPROMISED and REVOKED. Do not reuse it, do not re-add it.
#
#   ACTION REQUIRED: the exposed FTP credentials must be revoked and replaced
#   via a secure vault before any deployment.
#
# Supply fresh credentials only at run time, via environment variables or
# CI/CD secrets (never in code, never in committed .env files):
#   export FTP_HOST=ftpupload.net FTP_PORT=21 FTP_USER=... FTP_PASS=...
# ---------------------------------------------------------------------------
HOST = os.environ.get('FTP_HOST', 'ftpupload.net')
PORT = int(os.environ.get('FTP_PORT', '21'))
USER = os.environ.get('FTP_USER', '')
PASS = os.environ.get('FTP_PASS', '')
if not USER or not PASS:
    raise SystemExit(
        'FTP_USER / FTP_PASS are not set — supply via environment or CI secrets.\n'
        'ACTION REQUIRED: the exposed FTP credentials must be revoked and replaced\n'
        'via a secure vault before any deployment.'
    )
DIST = '/home/user/verlyse-project/dist'
HTACCESS = '/tmp/live-old/.htaccess'
P = 'htdocs/'

def connect():
    ftp = ftplib.FTP()
    ftp.connect(HOST, PORT, timeout=45)
    ftp.login(USER, PASS)
    return ftp

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()

# ---- build local manifest: relative path -> (abs local, size, sha) ----
local = {}
for base, dirs, files in os.walk(DIST):
    rel = os.path.relpath(base, DIST)
    for fn in files:
        r = fn if rel == '.' else f'{rel.replace(os.sep, "/")}/{fn}'
        ap = os.path.join(base, fn)
        local[r] = (ap, os.path.getsize(ap), sha256_file(ap))
print(f'local files: {len(local)}')

# ---- inventory remote (files only) ----
ftp = connect()
remote = {}
for entry in ftp.nlst(P):
    rel = entry[len(P):]
    if rel in ('.', '..'): continue
    # size via SIZE command (absolute path, works from any cwd)
    try:
        remote[rel] = int(ftp.size(P + rel))
    except Exception:
        remote[rel] = None  # directory or no-size
ftp.quit()
dirs = {k: v for k, v in remote.items() if v is None}
files = {k: v for k, v in remote.items() if v is not None}
print(f'remote entries: {len(remote)} (files: {len(files)}, dirs/no-size: {len(dirs)})')

# ---- decide uploads: everything in local (full fresh deploy) ----
to_upload = sorted(local.keys())

# ---- upload in chunks of 30, reconnecting per chunk ----
CHUNK = 30
uploaded = 0
failed = []
t0 = time.time()
for i in range(0, len(to_upload), CHUNK):
    chunk = to_upload[i:i+CHUNK]
    try:
        ftp = connect()
    except Exception as e:
        print('connect fail, retrying in 15s:', e)
        time.sleep(15)
        ftp = connect()
    for rel in chunk:
        ap, size, sha = local[rel]
        target = P + rel
        # ensure parent dir exists
        if '/' in rel:
            parent = target.rsplit('/', 1)[0]
            try: ftp.cwd(parent)
            except Exception:
                try: ftp.mkd(parent)
                except Exception: pass
        ok = False
        for attempt in range(3):
            try:
                with open(ap, 'rb') as fh:
                    ftp.storbinary(f'STOR {target}', fh)
                ok = True
                break
            except Exception as e:
                print(f'  retry {attempt+1} {rel}: {e}')
                time.sleep(8)
                try:
                    ftp.quit()
                except Exception:
                    pass
                try: ftp = connect()
                except Exception as e2:
                    print('  reconnect fail:', e2)
                    time.sleep(15)
        if ok:
            uploaded += 1
        else:
            failed.append(rel)
    try: ftp.quit()
    except Exception: pass
    print(f'  {uploaded}/{len(to_upload)} uploaded ({time.time()-t0:.0f}s)')

# ---- restore .htaccess (byte-exact copy of the established one) ----
try:
    ftp = connect()
    with open(HTACCESS, 'rb') as fh:
        ftp.storbinary(f'STOR {P}.htaccess', fh)
    ftp.quit()
    print('.htaccess restored')
except Exception as e:
    print('.htaccess restore FAILED:', e)
    failed.append('.htaccess')

# ---- verify: inventory + index.html content hash ----
time.sleep(5)
ftp = connect()
vfiles = {}
for entry in ftp.nlst(P):
    rel = entry[len(P):]
    if rel in ('.', '..'): continue
    try:
        vfiles[rel] = int(ftp.size(P + rel))
    except Exception:
        vfiles[rel] = None
missing = [r for r in local if r not in vfiles]
sizebad = [r for r in local if r in vfiles and vfiles[r] is not None and vfiles[r] != local[r][1]]
# content check on index.html
bad = []
try:
    buf = []
    ftp.retrbinary(f'RETR {P}index.html', lambda b: buf.append(b))
    got = hashlib.sha256(b''.join(buf)).hexdigest()
    if got != local['index.html'][2]:
        bad.append('index.html hash mismatch')
except Exception as e:
    bad.append(f'index.html retri fail: {e}')
ht_sz = vfiles.get('.htaccess')
exp_ht = os.path.getsize(HTACCESS)
print(f'verify: files now {sum(1 for v in vfiles.values() if v is not None)} | missing: {len(missing)} | size-mismatch: {len(sizebad)} | .htaccess size {ht_sz} (expect {exp_ht})')
if missing[:10]: print('  missing:', missing[:10])
if sizebad[:10]: print('  sizebad:', sizebad[:10])
if bad: print('  BAD:', bad)
ftp.quit()
print(f'DONE uploaded={uploaded} failed={len(failed)} failed_list={failed[:10]}')
sys.exit(1 if (failed or missing or sizebad or bad) else 0)
