import puppeteer from 'puppeteer'
const b = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-gpu', '--use-gl=swiftshader'] })
const p = await b.newPage()
const D = '/home/user/phase14-verify'
async function revealAll() {
  await p.evaluate(async () => {
    const h = document.body.scrollHeight
    for (let y = 0; y <= h; y += 280) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 110)) }
  })
  await new Promise((r) => setTimeout(r, 800))
}
async function scrollToText(expr, block = 'center', nth = -1) {
  await p.evaluate(({ expr, block, nth }) => {
    const pred = new Function('t', 'el', 'return ' + expr)
    const matches = []
    for (const el of document.querySelectorAll('p,h1,h2,h3')) if (pred(el.textContent, el)) matches.push(el)
    const el = nth < 0 ? matches[matches.length - 1] : matches[nth]
    if (el) el.scrollIntoView({ block })
    return matches.length
  }, { expr, block, nth })
  await new Promise((r) => setTimeout(r, 1600))
}

await p.setViewport({ width: 1440, height: 900 })

/* creators wall — last two cards (Mochi + Verlyse Media) */
await p.goto('http://localhost:4173/creators', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 2000))
await revealAll()
const n = await scrollToText("t.trim() === 'Mochi'", 'start')
await p.evaluate(() => window.scrollBy(0, 200))
await new Promise((r) => setTimeout(r, 900))
await p.screenshot({ path: `${D}/p15-creators-cards.png` })
console.log('creators cards (matches:', n, ')')

/* articles hero with ledger */
await p.goto('http://localhost:4173/articles', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 2000))
await revealAll()
await p.evaluate(() => window.scrollTo(0, 0))
await new Promise((r) => setTimeout(r, 900))
await p.screenshot({ path: `${D}/p15-articles-hero.png` })

/* articles reserved block (bottom) */
await scrollToText("t.includes('Reserved — the next feature')", 'center')
await p.evaluate(() => window.scrollBy(0, -120))
await new Promise((r) => setTimeout(r, 900))
await p.screenshot({ path: `${D}/p15-articles-reserved.png` })
console.log('articles hero + reserved shots done')
await b.close()
