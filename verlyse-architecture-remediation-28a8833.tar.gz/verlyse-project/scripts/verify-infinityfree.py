#!/usr/bin/env python3
"""Byte-exact audit of the InfinityFree deployment: hash every local dist file
against the server copy; re-upload mismatches; re-verify. Exits 0 only if all
131 files + .htaccess are byte-identical."""
import ftplib, os, hashlib, sys, time

DIST = '/home/user/verlyse-project/dist'
HTACCESS_LOCAL = '/tmp/live-old/.htaccess'
# ---------------------------------------------------------------------------
# SECURITY — credentials are NEVER committed to source control.
# The FTP account previously hardcoded here was leaked in this repository and
# is treated as COMPROMISED and REVOKED. Do not reuse it, do not re-add it.
#
#   ACTION REQUIRED: the exposed FTP credentials must be revoked and replaced
#   via a secure vault before any deployment.
#
# Supply fresh credentials only at run time, via environment variables or
# CI/CD secrets (never in code, never in committed .env files):
#   export FTP_HOST=ftpupload.net FTP_PORT=21 FTP_USER=... FTP_PASS=...
# ---------------------------------------------------------------------------
HOST = os.environ.get('FTP_HOST', 'ftpupload.net')
PORT = int(os.environ.get('FTP_PORT', '21'))
USER = os.environ.get('FTP_USER', '')
PASS = os.environ.get('FTP_PASS', '')
if not USER or not PASS:
    raise SystemExit(
        'FTP_USER / FTP_PASS are not set — supply via environment or CI secrets.\n'
        'ACTION REQUIRED: the exposed FTP credentials must be revoked and replaced\n'
        'via a secure vault before any deployment.'
    )

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(65536), b''): h.update(c)
    return h.hexdigest()

local = {}
for base, dirs, files in os.walk(DIST):
    rel = os.path.relpath(base, DIST)
    for fn in files:
        r = fn if rel == '.' else f'{rel.replace(os.sep, "/")}/{fn}'
        local[r] = sha(os.path.join(base, fn))
local['.htaccess'] = sha(HTACCESS_LOCAL)
print(f'auditing {len(local)} files')

def connect():
    ftp = ftplib.FTP()
    ftp.connect(HOST, PORT, timeout=60)
    ftp.login(USER, PASS)
    ftp.cwd('/')
    return ftp

def fetch(ftp, rel):
    buf = []
    ftp.retrbinary(f'RETR htdocs/{rel}', lambda b: buf.append(b))
    data = b''.join(buf)
    return hashlib.sha256(data).hexdigest(), len(data)

def upload(ftp, rel):
    src = HTACCESS_LOCAL if rel == '.htaccess' else os.path.join(DIST, rel)
    with open(src, 'rb') as fh:
        ftp.storbinary(f'STOR htdocs/{rel}', fh)

LOG = open('/home/user/verlyse-project/audit/deploy-verify.log', 'a', buffering=1)
def log(msg):
    print(msg, flush=True)
    LOG.write(msg + '\n')

# resume support: skip files already confirmed in a previous log run
confirmed = set()
try:
    for line in open('/home/user/verlyse-project/audit/deploy-verify.log'):
        if ' CONFIRMED ' in line:
            confirmed.add(line.split(' CONFIRMED ')[1].strip())
except Exception:
    pass
log(f'=== audit run start: {len(confirmed)} already confirmed')

bad = []
ftp = connect()
i = 0
for rel in sorted(local):
    i += 1
    if rel in confirmed:
        continue
    try:
        got, got_sz = fetch(ftp, rel)
    except Exception as e:
        got, got_sz = 'RETR_FAIL', 0
        log(f'  retr fail {rel}: {str(e)[:50]} (will treat as mismatch)')
    exp_sz = os.path.getsize(HTACCESS_LOCAL if rel == '.htaccess' else os.path.join(DIST, rel))
    if got == local[rel] and got_sz == exp_sz:
        confirmed.add(rel)
        log(f' CONFIRMED {rel}')
        if len(confirmed) % 25 == 0: log(f'  progress: {len(confirmed)}/{len(local)} confirmed')
        continue
    log(f'  MISMATCH {rel} (remote {got_sz}B vs local {exp_sz}B) — reuploading')
    fixed = False
    for attempt in range(6):
        try:
            ftp.quit()
        except Exception: pass
        time.sleep(5)
        try:
            ftp = connect()
            ftp.cwd('/')
            upload(ftp, rel)
            got2, got2_sz = fetch(ftp, rel)
            if got2 == local[rel] and got2_sz == exp_sz:
                confirmed.add(rel)
                log(f' CONFIRMED {rel} (repaired attempt {attempt+1})')
                fixed = True
                break
            log(f'  still bad {rel} attempt {attempt+1} ({got2_sz}B)')
        except Exception as e:
            log(f'  repair fail {rel}: {str(e)[:60]}')
    if not fixed:
        bad.append(rel)
try:
    ftp.quit()
except Exception: pass
log(f'RESULT: {len(confirmed)}/{len(local)} byte-exact')
if bad:
    log('STILL BAD: ' + ', '.join(bad))
    sys.exit(1)
log('ALL FILES BYTE-IDENTICAL')
