import puppeteer from 'puppeteer'
const b = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-gpu', '--use-gl=swiftshader'] })
const p = await b.newPage()

async function slowReveal() {
  await p.evaluate(async () => {
    const h = document.body.scrollHeight
    for (let y = 0; y <= h; y += 280) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 140)) }
    window.scrollTo(0, 0)
  })
  await new Promise((r) => setTimeout(r, 1200))
}

async function shoot(name, path, w, h, full) {
  await p.setViewport({ width: w, height: h })
  await p.goto('http://localhost:4173' + path, { waitUntil: 'networkidle2', timeout: 45000 })
  await new Promise((r) => setTimeout(r, 2500))
  await slowReveal()
  await p.screenshot({ path: `/home/user/phase14-verify/${name}.png`, fullPage: full })
  console.log('shot', name)
}

await shoot('p14-article-tablet', '/article/mir-raza-ali', 768, 1024, true)
await shoot('p14-article-mobile', '/article/mir-raza-ali', 390, 844, true)
await shoot('p14-ambassadors-desktop', '/ambassadors', 1440, 900, true)
await shoot('p14-home-desktop', '/', 1440, 900, true)

// reduced motion: content must still render (no animation, but visible)
await p.setViewport({ width: 1440, height: 900 })
await p.emulateMediaFeatures([{ name: 'prefers-reduced-motion', value: 'reduce' }])
await p.goto('http://localhost:4173/article/mir-raza-ali', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 3000))
await p.evaluate(async () => {
  const h = document.body.scrollHeight
  for (let y = 0; y <= h; y += 400) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 80)) }
  window.scrollTo(0, 0)
})
await new Promise((r) => setTimeout(r, 1500))
const rmText = await p.evaluate(() => document.body.innerText)
const rmOk = rmText.toLowerCase().includes('wafflix') && rmText.toLowerCase().includes('conversations')
// check first body paragraph is actually visible (opacity 1)
const rmVisible = await p.evaluate(() => {
  const arts = Array.from(document.querySelectorAll('article > div'))
  return arts.length > 0 && arts.every((d) => {
    const cs = getComputedStyle(d)
    return cs.opacity === '1' || cs.visibility !== 'hidden'
  })
})
console.log('reduced-motion content visible:', rmOk, '| elements opaque:', rmVisible)
await p.screenshot({ path: '/home/user/phase14-verify/p14-reduced-motion.png', fullPage: false })

// live search: open overlay, type "Raza", expect the new article to resolve
await p.emulateMediaFeatures([{ name: 'prefers-reduced-motion', value: 'no-preference' }])
await p.goto('http://localhost:4173/', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 2000))
await p.keyboard.press('Escape')
// find the search trigger (button with aria-label or the magnifier)
const opened = await p.evaluate(() => {
  for (const btn of document.querySelectorAll('button, a')) {
    const l = (btn.getAttribute('aria-label') || '') + ' ' + btn.textContent
    if (/search/i.test(l)) { btn.click(); return true }
  }
  return false
})
await new Promise((r) => setTimeout(r, 1200))
await p.keyboard.type('Raza')
await new Promise((r) => setTimeout(r, 1200))
const searchText = await p.evaluate(() => document.body.innerText.toLowerCase())
const searchOk = searchText.includes('mir raza ali') && searchText.includes('social issues')
console.log('search overlay opened:', opened, '| "Raza" resolves new article:', searchOk)
await p.screenshot({ path: '/home/user/phase14-verify/p14-search.png', fullPage: false })

await b.close()
