import puppeteer from 'puppeteer'
const b = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-gpu', '--use-gl=swiftshader'] })
const p = await b.newPage()
const D = '/home/user/phase14-verify'

async function revealAll() {
  await p.evaluate(async () => {
    const h = document.body.scrollHeight
    for (let y = 0; y <= h; y += 280) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 120)) }
  })
  await new Promise((r) => setTimeout(r, 800))
}
async function scrollToText(labelSrc, block = 'start') {
  await p.evaluate(({ labelSrc, block }) => {
    const pred = new Function('t', 'el', 'return ' + labelSrc)
    for (const el of document.querySelectorAll('p,h2,h3,span,figcaption')) {
      if (pred(el.textContent, el)) { el.scrollIntoView({ block, behavior: 'instant' }); return true }
    }
    return false
  }, { labelSrc, block })
  await new Promise((r) => setTimeout(r, 1800))
}

const ARTICLES = [
  { id: 'mir-raza-ali', tag: 'new' },
  { id: 'behind-every-headline', tag: 'est-behind' },
  { id: 'their-voices-matter', tag: 'est-tvm' },
]
const VPS = [{ w: 1440, h: 900, v: 'd' }, { w: 768, h: 1024, v: 't' }, { w: 390, h: 844, v: 'm' }]

for (const vp of VPS) {
  for (const a of ARTICLES) {
    await p.setViewport({ width: vp.w, height: vp.h })
    await p.goto(`http://localhost:4173/article/${a.id}`, { waitUntil: 'networkidle2', timeout: 45000 })
    await new Promise((r) => setTimeout(r, 2200))
    await revealAll()
    // 1. hero
    await p.evaluate(() => window.scrollTo(0, 0))
    await new Promise((r) => setTimeout(r, 900))
    await p.screenshot({ path: `${D}/p15-${a.tag}-${vp.v}-hero.png` })
    // 2. contributor block
    await scrollToText("t.toLowerCase().includes('about the writer')")
    await p.evaluate(() => window.scrollBy(0, -120))
    await new Promise((r) => setTimeout(r, 900))
    await p.screenshot({ path: `${D}/p15-${a.tag}-${vp.v}-contributor.png` })
    // 3. ending
    await scrollToText("t === 'The ending'")
    await p.evaluate(() => window.scrollBy(0, -60))
    await new Promise((r) => setTimeout(r, 900))
    await p.screenshot({ path: `${D}/p15-${a.tag}-${vp.v}-ending.png` })
    console.log('shots', a.id, vp.v)
  }
}

/* within-the-post: new article vs behind-every-headline (desktop) */
await p.setViewport({ width: 1440, height: 900 })
for (const a of ['mir-raza-ali', 'behind-every-headline']) {
  await p.goto(`http://localhost:4173/article/${a}`, { waitUntil: 'networkidle2', timeout: 45000 })
  await new Promise((r) => setTimeout(r, 2200))
  await revealAll()
  await scrollToText("t === 'Within the post'")
  await p.evaluate(() => window.scrollBy(0, -40))
  await new Promise((r) => setTimeout(r, 900))
  await p.screenshot({ path: `${D}/p15-within-${a === 'mir-raza-ali' ? 'new' : 'est-behind'}-d.png` })
  console.log('within shot', a)
}

/* ambassadors — the room: bottom rows (Zainab + Ahsan) and a middle row (Javeria) */
await p.setViewport({ width: 1440, height: 900 })
await p.goto('http://localhost:4173/ambassadors', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 2200))
await revealAll()
await scrollToText("'Zainab Khan' === t.trim()")
await p.evaluate(() => window.scrollBy(0, -330))
await new Promise((r) => setTimeout(r, 900))
await p.screenshot({ path: `${D}/p15-amb-team-bottom.png` })
await scrollToText("'Javeria Karim' === t.trim()")
await p.evaluate(() => window.scrollBy(0, -60))
await new Promise((r) => setTimeout(r, 900))
await p.screenshot({ path: `${D}/p15-amb-team-middle.png` })
console.log('ambassador shots done')

/* creators wall — the platform card region (16th card, last row) */
await p.goto('http://localhost:4173/creators', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 2200))
await revealAll()
await scrollToText("'Verlyse Media' === t.trim()", 'center')
await p.evaluate(() => window.scrollBy(0, -250))
await new Promise((r) => setTimeout(r, 900))
await p.screenshot({ path: `${D}/p15-creators-wall.png` })
console.log('creators shot done')

/* articles index top (folio 01 card) */
await p.goto('http://localhost:4173/articles', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 2200))
await revealAll()
await p.evaluate(() => window.scrollTo(0, 0))
await new Promise((r) => setTimeout(r, 900))
await p.screenshot({ path: `${D}/p15-articles-index.png` })
/* index: is "Raza" visible + Social Issues filter */
const idxText = await p.evaluate(() => document.body.innerText.toLowerCase())
console.log('index shows Raza:', idxText.includes('mir raza ali'))
const filterClicked = await p.evaluate(() => {
  for (const b of document.querySelectorAll('button,a')) {
    if (b.textContent.trim() === 'Social Issues') { b.click(); return true }
  }
  return false
})
await new Promise((r) => setTimeout(r, 1500))
const filtered = await p.evaluate(() => document.body.innerText.toLowerCase())
console.log('social-issues filter clicked:', filterClicked, '| filtered list shows Raza:', filtered.includes('mir raza ali'))
await p.screenshot({ path: `${D}/p15-articles-filtered.png` })

/* homepage hero — continuity vs Phase 14 */
await p.goto('http://localhost:4173/', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 3000))
await p.evaluate(() => window.scrollTo(0, 0))
await new Promise((r) => setTimeout(r, 800))
await p.screenshot({ path: `${D}/p15-home-hero.png` })
console.log('home hero shot done')

/* discovery: "Raza" in related content of a sibling (behind-every-headline also-in-issue) */
await p.goto('http://localhost:4173/article/behind-every-headline', { waitUntil: 'networkidle2', timeout: 45000 })
await new Promise((r) => setTimeout(r, 2200))
await revealAll()
const relText = await p.evaluate(() => document.body.innerText.toLowerCase())
console.log('related content of behind-every-headline mentions Raza:', relText.includes('mir raza ali'))
await scrollToText("t.includes('also in this issue')")
await p.screenshot({ path: `${D}/p15-related-behind.png` })

await b.close()
console.log('ALL P15 SHOTS DONE')
