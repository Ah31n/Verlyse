# Deployment status

- Project: `verlyse-react`
- Existing Vercel link: `prj_YIVFSdsmEYUu3e6phctaY2JGgPYR` / `team_7YP6r8bUZx7McxQPeXCn44pH`
- Build: passing with `npm run build`
- Vercel configuration: `vercel.json` present with SPA fallback, security headers, and `/api` routing.

## Remaining credentials required

A Vercel authentication token is required to run the production deployment from this environment. If newsletter delivery is wanted, also provide `BUTTONDOWN_API_KEY`; it must be added as a Vercel production environment variable, never committed.

MCP configs are present for OriginKit, Figma (stdio), Figma Official (OAuth), and Penpot in `.mcp.json`, `.cursor/mcp.json`, and `.vscode/mcp.json`. Credentials have been changed to environment-variable placeholders in the working copy:

- `ORIGINKIT_API_KEY`
- `FIGMA_API_KEY`
- `PENPOT_USER_TOKEN`

The Figma Official server still requires one-time OAuth authorization in the editor.
