#!/usr/bin/env bash
# Verlyse Media — one-command deploy to production (Vercel).
# Usage:  bash scripts/deploy.sh
set -euo pipefail
cd "$(dirname "$0")/.."

if [ -z "${VERCEL_TOKEN:-}" ]; then
  echo "❌ VERCEL_TOKEN is not set."
  echo "   Run:  export VERCEL_TOKEN=your_token"
  exit 1
fi

echo "▶ Building…"
npm run build >/dev/null 2>&1 || { echo "❌ build failed"; exit 1; }
echo "✓ build clean"

echo "▶ Deploying to Vercel production…"
vercel deploy --prod --token "$VERCEL_TOKEN" --yes 2>&1 | tail -5

echo "✓ Done — the live site is updated."
