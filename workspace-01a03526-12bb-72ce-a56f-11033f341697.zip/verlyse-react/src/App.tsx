import { lazy, Suspense, useEffect } from 'react'
import { Link, Routes, Route, useLocation } from 'react-router-dom'
import type { ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Layout from './components/layout/Layout'

/* Route-level code splitting — each page loads in its own chunk, so the
   first paint ships only the cover, the chrome, and the shared editorial
   system. The magazine opens before the rest of the issue arrives. */
const Home = lazy(() => import('./pages/Home'))
const About = lazy(() => import('./pages/About'))
const Articles = lazy(() => import('./pages/Articles'))
const ArticleDetail = lazy(() => import('./pages/ArticleDetail'))
const Categories = lazy(() => import('./pages/Categories'))
const Community = lazy(() => import('./pages/Community'))
const Submit = lazy(() => import('./pages/Submit'))
const Ambassadors = lazy(() => import('./pages/Ambassadors'))
const Creators = lazy(() => import('./pages/Creators'))
const Contact = lazy(() => import('./pages/Contact'))
const WriterProfilePage = lazy(() => import('./pages/WriterProfilePage'))

/** Curtain-style page transition — a gold hairline sweeps across, then the page settles. */
function PageTransition({ children }: { children: ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 26 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -14 }}
      transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* the sweep — one gold hairline, drawn once, then gone */}
      <motion.span
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 top-0 z-[1150] h-px bg-gradient-to-r from-transparent via-gold to-transparent"
        initial={{ scaleX: 0, opacity: 1 }}
        animate={{ scaleX: 1, opacity: 0 }}
        transition={{ duration: 0.9, ease: [0.65, 0.05, 0.36, 1], delay: 0.15 }}
        style={{ originX: 0 }}
      />
      {children}
    </motion.div>
  )
}

/** Reset scroll to top on every navigation (before the new page paints). */
function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])
  return null
}

export default function App() {
  const location = useLocation()

  return (
    <>
      <ScrollToTop />
      <Layout>
      <Suspense fallback={<div className="min-h-[80vh] bg-wine-deep" aria-hidden="true" />}>
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<PageTransition><Home /></PageTransition>} />
          <Route path="/about" element={<PageTransition><About /></PageTransition>} />
          <Route path="/articles" element={<PageTransition><Articles /></PageTransition>} />
          <Route path="/article/:id" element={<PageTransition><ArticleDetail /></PageTransition>} />
          <Route path="/categories" element={<PageTransition><Categories /></PageTransition>} />
          <Route path="/community" element={<PageTransition><Community /></PageTransition>} />
          <Route path="/submit" element={<PageTransition><Submit /></PageTransition>} />
          <Route path="/ambassadors" element={<PageTransition><Ambassadors /></PageTransition>} />
          <Route path="/creators" element={<PageTransition><Creators /></PageTransition>} />
          <Route path="/contact" element={<PageTransition><Contact /></PageTransition>} />
          <Route path="/creator/:authorId" element={<PageTransition><WriterProfilePage /></PageTransition>} />
          <Route path="*" element={<PageTransition><NotFound /></PageTransition>} />
        </Routes>
      </AnimatePresence>
      </Suspense>
      </Layout>
    </>
  )
}

function NotFound() {
  useEffect(() => {
    document.title = 'Page not found — Verlyse Media'
  }, [])
  return (
    <section className="flex min-h-[70vh] items-center justify-center text-center">
      <div>
        <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-gold">A page that wasn’t written</p>
        <h1 className="mt-6 font-serif text-[clamp(2.4rem,5vw,4rem)] font-light leading-[1.05] text-ivory">
          This page is still <em className="italic text-gold">waiting for its feature</em>
        </h1>
        <p className="mx-auto mt-6 max-w-[40ch] font-serif text-lg font-light italic leading-[1.7] text-white/65">
          Every page in this magazine began as an empty one. Yours could be next — or you could return to the room.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-6">
          <Link to="/" className="btn btn-gold">Return to the magazine</Link>
          <Link to="/submit" className="border-b border-gold/60 pb-1 font-mono text-[10px] uppercase tracking-[0.28em] text-gold no-underline transition-colors hover:text-ivory">
            Send your voice →
          </Link>
        </div>
      </div>
    </section>
  )
}
