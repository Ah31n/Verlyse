import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { ARTICLES, getAuthor } from '../../data/content'

function esc(s: string) {
  return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;')
}

/** Global search overlay — ⌘K / Ctrl+K. Searches titles, authors, categories. */
export default function SearchOverlay() {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => {
    const onOpen = () => setOpen(true)
    window.addEventListener('verlyse:search', onOpen)
    return () => window.removeEventListener('verlyse:search', onOpen)
  }, [])

  useEffect(() => {
    setOpen(false)
  }, [location.pathname])

  useEffect(() => {
    document.body.classList.toggle('no-scroll', open)
    if (open) {
      const t = setTimeout(() => document.getElementById('searchInput')?.focus(), 120)
      return () => clearTimeout(t)
    }
  }, [open])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const query = q.trim().toLowerCase()
  const results = query
    ? ARTICLES.filter((a) => {
        const author = getAuthor(a.authorId)?.name ?? ''
        return (a.title + ' ' + a.category + ' ' + author).toLowerCase().includes(query)
      }).slice(0, 8)
    : []

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[1250] grid place-items-center p-4" role="dialog" aria-modal="true" aria-label="Search articles">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="absolute inset-0 bg-[rgba(14,3,7,0.94)]"
            onClick={() => setOpen(false)}
          />
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 18 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 w-full max-w-[680px] border border-gold/30 bg-[#1B0610] p-8 shadow-[0_60px_140px_rgba(0,0,0,0.7)] md:p-11"
          >
            {/* the card's corner ticks — an archival record, not a modal */}
            <span aria-hidden="true" className="absolute -left-1.5 -top-1.5 h-3.5 w-3.5 border-l border-t border-gold/70" />
            <span aria-hidden="true" className="absolute -right-1.5 -top-1.5 h-3.5 w-3.5 border-r border-t border-gold/70" />
            <span aria-hidden="true" className="absolute -bottom-1.5 -left-1.5 h-3.5 w-3.5 border-b border-l border-gold/70" />
            <span aria-hidden="true" className="absolute -bottom-1.5 -right-1.5 h-3.5 w-3.5 border-b border-r border-gold/70" />

            <div className="flex items-center justify-between gap-4">
              <p className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.28em] text-gold">
                <span aria-hidden="true" className="h-px w-6 bg-gold/60" />
                The archive — search it
              </p>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close search"
                className="grid h-9 w-9 place-items-center border border-gold/40 font-serif text-lg text-ivory transition-colors hover:bg-gold hover:text-charcoal"
              >
                ✕
              </button>
            </div>
            <input
              id="searchInput"
              type="search"
              autoComplete="off"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Stories, writers, genres…"
              aria-label="Search articles"
              className="mt-5 w-full border-0 border-b border-gold/40 bg-transparent pb-4 font-serif text-2xl font-light text-ivory outline-none placeholder:italic placeholder:text-ivory/35 focus:border-gold"
            />
            <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">
              {query ? (results.length ? `${results.length} found` : 'Nothing in the archive matches — not yet') : 'Begin typing · Esc to close'}
            </p>
            <ul className="mt-4 max-h-[44vh] overflow-y-auto">
              {results.map((a) => {
                const author = getAuthor(a.authorId)
                return (
                  <li key={a.id}>
                    <a
                      href={`/article/${a.id}`}
                      onClick={(e) => {
                        e.preventDefault()
                        setOpen(false)
                        navigate(`/article/${a.id}`)
                      }}
                      className="group block border-b border-white/10 py-4 pl-2 no-underline transition-colors duration-500 hover:bg-gold/[0.07] hover:pl-3"
                    >
                      <span className="flex items-baseline gap-3">
                        <span aria-hidden="true" className="font-mono text-[9px] tracking-[0.26em] text-gold">
                          {String(results.indexOf(a) + 1).padStart(2, '0')}
                        </span>
                        <span className="font-serif text-xl text-ivory transition-colors duration-500 group-hover:text-[#E8D9A8]">{esc(a.title)}</span>
                      </span>
                      <span className="mt-1 block pl-8 font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">
                        <span className="text-gold">{a.category}</span> ✦ {author?.name ?? ''} ✦ {a.readingTime}
                      </span>
                    </a>
                  </li>
                )
              })}
            </ul>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}
