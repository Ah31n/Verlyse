import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useSeo } from '../hooks/useSeo'
import SplitText from '../components/ui/SplitText'
import Reveal from '../components/ui/Reveal'
import { MetaRow, PageRail } from '../components/ui/primitives'
import { ARTICLES, getAuthor, type Article } from '../data/content'

/**
 * The Archive — the magazine's table of contents.
 * Every feature is an index entry: a ghost folio numeral, the title,
 * and a plate of the work that lifts into view when the entry is read.
 */
function ArticleRow({ article, lead = false, index = 0 }: { article: Article; lead?: boolean; index?: number }) {
  const author = getAuthor(article.authorId)
  /* the true position in the archive — stable even when the index is filtered */
  const folio = String(ARTICLES.findIndex((x) => x.id === article.id) + 1).padStart(2, '0')
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '0px 0px -8% 0px' }}
      transition={{ duration: 1.05, ease: [0.16, 1, 0.3, 1], delay: Math.min(index * 0.05, 0.3) }}
    >
      <Link to={`/article/${article.id}`} className="group relative block border-b border-white/10 py-8 no-underline transition-all duration-500 hover:bg-white/[0.04] md:py-10">
        {/* the drawn hairline — a gold rule is set when the entry is read */}
        <span aria-hidden="true" className="absolute inset-x-0 top-0 h-px origin-left scale-x-0 bg-gold transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-x-100" />

        {lead && (
          <div className="img-frame relative mb-8 aspect-[21/9] overflow-hidden">
            {/* object-cover: the photograph fills the banner edge-to-edge —
                no letterbox bars */}
            <img src={article.thumbnail ?? article.cover} alt={article.title} className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.08]" loading="lazy" />
            <span aria-hidden="true" className="absolute left-5 top-5 border border-gold/70 bg-[#1C0509]/55 px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.30em] text-ivory ">
              Latest feature
            </span>
          </div>
        )}

        <div className="grid grid-cols-1 items-center gap-x-10 gap-y-6 md:grid-cols-[110px_1fr_170px]">
          {/* folio — the index number, set like a ledger */}
          <div className="relative hidden items-baseline gap-3 md:flex" aria-hidden="true">
            <span className="font-mono text-[9px] uppercase tracking-[0.30em] text-gold">№</span>
            <span className="font-serif text-[clamp(2.4rem,4vw,3.6rem)] font-semibold leading-none text-transparent transition-all duration-700 [-webkit-text-stroke:1px_rgba(184,145,70,0.22)] group-hover:[-webkit-text-stroke:1px_rgba(184,145,70,0.55)]">
              {folio}
            </span>
          </div>

          <div className="min-w-0">
            <h2 className={`font-serif font-normal text-ivory transition-all duration-700 group-hover:italic group-hover:text-[#E8D9A8] ${lead ? 'text-[clamp(2.1rem,4vw,3.4rem)] leading-[1.08]' : 'text-[clamp(1.55rem,2.5vw,2.2rem)] leading-[1.14]'}`}>
              “{article.title}”
            </h2>
            <MetaRow category={article.category} author={author?.name} readingTime={article.readingTime} className="mt-3" />
            <p className="mt-4 max-w-[56ch] leading-[1.75] text-white/60">{article.excerpt}</p>
          </div>

          {/* the plate — the work itself, lifted like a kept print */}
          <div className="hidden md:block" aria-hidden="true">
            <div className="img-frame relative aspect-[3/4] w-[170px] rotate-[-2deg] overflow-hidden border border-white/10 opacity-0 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:rotate-0 group-hover:opacity-100 group-hover:border-gold/40">
              <img src={article.thumbnail ?? article.cover} alt="" loading="lazy" className="h-full w-full object-cover" />
              <span aria-hidden="true" className="absolute inset-0 border border-gold/30 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
            </div>
          </div>

          <span aria-hidden="true" className="hidden font-serif text-2xl text-gold md:block md:absolute md:right-6 md:opacity-0 md:transition-all md:duration-500 md:group-hover:translate-x-1 md:group-hover:opacity-100">
            ↗
          </span>
        </div>
      </Link>
    </motion.div>
  )
}

export default function Articles() {
  useSeo({
path: '/articles',
    title: 'Articles',
    description: 'The Verlyse Media archive — every feature presented, from “3:13” onwards.',
  })
  const [query, setQuery] = useState('')
  const [cat, setCat] = useState<string>('All')

  const cats = useMemo(() => ['All', ...new Set(ARTICLES.map((a) => a.category))], [])
  /* the latest feature — the most recent post, featured at the head of the
     index with the banner treatment */
  const latest = useMemo(
    () => [...ARTICLES].sort((a, b) => b.date.localeCompare(a.date))[0],
    [],
  )
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    const list = ARTICLES.filter((a) => {
      const author = getAuthor(a.authorId)?.name ?? ''
      const okCat = cat === 'All' || a.category === cat
      const okQ = !q || (a.title + ' ' + a.category + ' ' + author).toLowerCase().includes(q)
      return okCat && okQ
    })
    /* when the index is unfiltered, the latest feature leads the page */
    if (!q && cat === 'All' && list.length > 1 && list[0]?.id !== latest.id) {
      return [latest, ...list.filter((a) => a.id !== latest.id)]
    }
    return list
  }, [query, cat, latest])

  return (
    <>
      <section className="flex min-h-[70svh] items-end border-b border-white/10 bg-wine-deep pb-20 pt-36">
        <PageRail text="The archive — eighteen features, and counting" />
        <div className="mx-auto w-full max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal><p className="eyebrow">The Archive</p></Reveal>
          <SplitText as="h1" text="Contents" className="mt-6 text-[clamp(3.4rem,9.4vw,9rem)]" />
          <Reveal delay={0.2}>
            <p className="mt-6 max-w-[52ch] text-lg leading-[1.8] text-white/70">
              Every feature the magazine has presented, numbered in the order it was published, and the next one, waiting for a submission. The archive is young, and it grows one story at a time.
            </p>
          </Reveal>
          <Reveal delay={0.28}>
            <div className="mt-10 flex max-w-[640px] flex-wrap items-baseline gap-x-10 gap-y-2 border-t border-white/15 pt-5 font-mono text-[10px] uppercase tracking-[0.28em] text-white/65">
              <span>№ 01 — “Their Voices Matter”</span>
              <span>№ 18 — “The Garden Beyond My Tower”</span>
              <span className="text-white/55">№ 19 — yours?</span>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          {/* Search + filters */}
          <div className="mb-14 flex flex-col gap-8 border-b border-white/10 pb-10 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-md">
              <label htmlFor="art-search" className="kicker">Search the archive</label>
              <input
                id="art-search"
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Titles, writers, genres…"
                className="mt-3 w-full border-0 border-b border-gold/40 bg-transparent pb-3 font-serif text-2xl font-light text-ivory outline-none placeholder:italic placeholder:text-ivory/35 focus:border-gold"
              />
            </div>
            <div role="group" aria-label="Filter by category" className="flex flex-wrap gap-2">
              {cats.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCat(c)}
                  aria-pressed={cat === c}
                  className={`relative px-5 py-2.5 font-mono text-[10px] font-medium uppercase tracking-[0.28em] transition-colors duration-300 ${
                    cat === c ? 'text-gold before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gold before:content-[""] after:absolute after:inset-x-0 after:bottom-0 after:h-px after:bg-gold' : 'text-white/60 hover:text-ivory'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* the contents rail — what each column of the index holds */}
          <div aria-hidden="true" className="mb-2 hidden grid-cols-[110px_1fr_170px] gap-x-10 pb-4 font-mono text-[9px] uppercase tracking-[0.30em] text-white/60 md:grid">
            <span>№ — The index</span>
            <span className="flex items-baseline justify-between gap-4">
              <span>The features — {ARTICLES.length} presented</span>
              <span className="pr-10">The department</span>
            </span>
          </div>

          {/* The index */}
          {filtered.length === 0 ? (
            <p className="py-20 text-center font-serif text-2xl font-light italic text-white/65">
              Nothing matches — the archive is young, and it keeps its promises honestly.
            </p>
          ) : (
            <div>
              {filtered.map((a, i) => (
                <ArticleRow key={a.id} article={a} lead={i === 0 && !query && cat === 'All' && a.id === latest.id} index={i} />
              ))}
            </div>
          )}

          {/* № 19 — reserved, the next entry in the index */}
          <Reveal className="mt-16">
            <div className="group grid grid-cols-1 items-center gap-x-10 gap-y-5 border border-dashed border-white/15 px-6 py-10 transition-colors duration-700 hover:border-gold/35 md:grid-cols-[110px_1fr_auto] md:px-8">
              <div aria-hidden="true" className="hidden items-baseline gap-3 md:flex">
                <span className="font-mono text-[9px] uppercase tracking-[0.30em] text-gold">№</span>
                <span className="font-serif text-[clamp(2.4rem,4vw,3.6rem)] font-semibold leading-none text-transparent [-webkit-text-stroke:1px_rgba(184,145,70,0.22)] transition-all duration-700 group-hover:[-webkit-text-stroke:1px_rgba(184,145,70,0.55)]">19</span>
              </div>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-gold">Reserved — the next feature</p>
                <p className="mt-4 max-w-[46ch] font-serif text-xl font-light italic leading-[1.6] text-ivory/75">
                  The next story presented by Verlyse Media begins as a submission. This entry of the index is reserved for it — credited to its writer, in their own words.
                </p>
              </div>
              <div className="md:text-right">
                <Link to="/submit" className="btn btn-ghost">Send your work</Link>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.1} className="mt-14 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-6 font-mono text-[9px] uppercase tracking-[0.30em] text-white/60">
            <span>Eighteen features in the archive — each one credited, each one read</span>
            <span>End of the contents — for now</span>
          </Reveal>
        </div>
      </section>
    </>
  )
}
