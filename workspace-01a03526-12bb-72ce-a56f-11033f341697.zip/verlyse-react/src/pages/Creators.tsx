import { Link } from 'react-router-dom'
import { useSeo } from '../hooks/useSeo'
import Reveal from '../components/ui/Reveal'
import RevealImage from '../components/ui/RevealImage'
import { HiddenQuote } from '../components/ui/EasterEggs'
import { ARTICLES, AUTHORS, authorPhoto } from '../data/content'

/** The first work each creator is credited for on the feed. */
function workOf(authorId: string) {
  if (authorId === 'mochjixx') return ARTICLES.find((a) => a.id === 'a-students-worth') ?? ARTICLES[0]
  return ARTICLES.find((a) => a.authorId === authorId) ?? ARTICLES[0]
}

export default function Creators() {
  useSeo({
path: '/creators',
    title: 'Featured Creators',
    description: 'The creators featured by Verlyse Media — fifteen writers and artists, credited by name and handle on every feature.',
  })

  return (
    <>
      <section className="border-b border-white/10 bg-wine-deep pb-16 pt-44">
        <div className="mx-auto w-full max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal><p className="eyebrow">Featured creators</p></Reveal>
          <h1 className="mt-6 max-w-[14ch] font-serif text-[clamp(3.2rem,8.6vw,8.5rem)] font-light leading-[0.98] tracking-[-0.02em] text-ivory">
            The wall <em className="italic text-gold">of names</em>
          </h1>
          <Reveal delay={0.15}>
            <p className="mt-6 max-w-[52ch] text-lg leading-[1.8] text-white/70">
              Every feature names its writer, by name and handle, in the caption. This is the wall of those names — fifteen creators, from the founder’s call for women’s rights to the Kashmir cover.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <div className="grid grid-cols-1 gap-x-10 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
            {AUTHORS.map((a, i) => {
              const work = workOf(a.id)
              return (
                <Reveal key={a.id} delay={(i % 3) * 0.09} className={i % 3 === 1 ? 'lg:mt-16' : ''}>
                  <Link to={`/creator/${a.id}`} className="group block no-underline">
                    <div className="img-frame relative flex justify-center overflow-hidden">
                      {/* the founder's photograph — the same portrait used on
                          the profile — stands on the wall; every other creator
                          keeps their article's first page */}
                      {a.portrait && !a.hideArticlePhoto ? (
                        <div className="flex aspect-[4/5] w-full items-center justify-center bg-[#F2EADA] p-3">
                          <img
                            src={a.profilePhoto ?? authorPhoto(a.id)}
                            alt={`${a.name} — photograph`}
                            loading="lazy"
                            decoding="async"
                            draggable={false}
                            className="block max-h-full max-w-full object-contain shadow-[0_4px_14px_rgba(0,0,0,0.3)]"
                          />
                        </div>
                      ) : (
                        <RevealImage
                          src={work.cover}
                          alt={`${a.name} — “${work.title}”, first page`}
                          className="aspect-[4/5] h-full w-full transition-transform duration-[1400ms] ease-out group-hover:scale-[1.16]"
                          imgClassName="h-full w-full object-cover"
                        />
                      )}
                      <span aria-hidden="true" className="absolute inset-3 border border-gold/50 transition-colors duration-500 group-hover:border-gold/80" />
                    </div>
                    <h2 className="mt-5 font-serif text-2xl font-medium text-ivory transition-all duration-700 group-hover:italic group-hover:text-gold">
                      {a.name}
                    </h2>
                    <p className="mt-1.5 font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">{a.handle} · {a.role}</p>
                    <p className="mt-3 flex flex-wrap gap-2">
                      {[work.category, ...work.tags.slice(0, 1)].map((t, ti) => (
                        <span key={`${t}-${ti}`} className="border-y border-white/15 px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.30em] text-white/65">{t}</span>
                      ))}
                    </p>
                    <p className="mt-4 max-w-[36ch] text-sm leading-[1.65] text-white/60">{a.bio}</p>
                    <p className="mt-3 font-mono text-[9px] uppercase tracking-[0.30em] text-gold opacity-0 transition-opacity duration-500 group-hover:opacity-100">
                      Open the writer’s profile →
                    </p>
                    <p className="mt-2 font-serif text-[11px] italic text-white/55">
                      <HiddenQuote quote={`${a.favoriteQuote ?? '“' + work.title + '”'}`} />
                    </p>
                  </Link>
                </Reveal>
              )
            })}
          </div>

          <Reveal className="mt-20 border border-dashed border-white/15 p-10 text-center">
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-gold">The wall grows with every feature</p>
            <p className="mx-auto mt-4 max-w-[44ch] font-serif text-xl font-light italic text-ivory/70">
              The wall grows with every feature, and every feature begins with a submission. Send the story; the name will follow.
            </p>
            <Link to="/submit" className="btn btn-gold mt-8">Send your work</Link>
          </Reveal>
        </div>
      </section>
    </>
  )
}
