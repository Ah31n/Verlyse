import { Link, useParams } from 'react-router-dom'
import { useSeo } from '../hooks/useSeo'
import Reveal from '../components/ui/Reveal'
import SplitText from '../components/ui/SplitText'
import WriterProfile from '../components/ui/WriterProfile'
import { getAuthor } from '../data/content'

export default function WriterProfilePage() {
  const { authorId } = useParams<{ authorId: string }>()
  const author = authorId ? getAuthor(authorId) : undefined

  useSeo({
    title: author ? `${author.name} — Writer` : 'Writer not found',
    description: author
      ? `${author.name} (${author.handle}) — a writer on Verlyse Media. ${author.favoriteQuote ?? author.bio}`
      : 'This writer has not been featured yet.',
  })

  if (!author) {
    return (
      <section className="flex min-h-[70vh] items-center justify-center text-center">
        <div>
          <p className="font-serif text-4xl font-light text-ivory">The writer isn’t here yet</p>
          <p className="mt-4 font-mono text-xs uppercase tracking-[0.24em] text-white/65">
            <Link to="/creators" className="text-gold no-underline">Back to the wall of names →</Link>
          </p>
        </div>
      </section>
    )
  }

  return (
    <>
      {/* the profile opening — quiet, like the first page of a chapter */}
      <section className="relative overflow-hidden border-b border-white/10 bg-wine-deep pb-16 pt-44">
        <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-72 bg-[radial-gradient(62%_55%_at_50%_6%,rgba(184,145,70,0.05),transparent_74%)]" />
        <div className="relative mx-auto w-full max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal><p className="eyebrow">The writer</p></Reveal>
          <div className="mt-6 flex flex-wrap items-end justify-between gap-6">
            <div>
              <SplitText
                as="h1"
                text={author.name}
                className="text-[clamp(3rem,8vw,7rem)]"
              />
              <Reveal delay={0.2}>
                <p className="mt-5 font-mono text-[10px] uppercase tracking-[0.28em] text-white/60">
                  {author.handle} · {author.role}
                </p>
              </Reveal>
            </div>
            <Reveal delay={0.25}>
              <p className="max-w-[30ch] text-right font-serif text-base font-light italic leading-[1.7] text-white/60">
                One of the fourteen names the magazine credits, by name and handle, on every feature.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* the profile itself */}
      <section className="relative border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <WriterProfile author={author} />
        </div>
      </section>
    </>
  )
}
