import { useRef } from 'react'
import { Link } from 'react-router-dom'
import { useSeo } from '../hooks/useSeo'
import SplitText from '../components/ui/SplitText'
import Reveal from '../components/ui/Reveal'
import { PageRail } from '../components/ui/primitives'
import { ARTICLES, BRAND, COMMUNITY_STATS, COMMUNITY_VOICES, type Article } from '../data/content'

/** The perforated rail of the film strip — sprocket holes, punched in the dark. */
function FilmRail() {
  return (
    <div
      aria-hidden="true"
      className="h-[10px] w-full bg-[repeating-linear-gradient(90deg,#14060B_0px,#14060B_6px,#0A0306_6px,#0A0306_26px)]"
    />
  )
}

/** One frame of the reel — a cover, its folio, and the title beneath it. */
function FilmFrame({ article }: { article: Article }) {
  return (
    <Link
      to={`/article/${article.id}`}
      className="group block w-[240px] shrink-0 no-underline md:w-[264px]"
    >
      <div className="img-frame relative aspect-[4/5] overflow-hidden border border-white/12 transition-colors duration-700 group-hover:border-gold/50">
        <img
          src={article.cover}
          alt={`${article.title} — cover`}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.1]"
        />
        <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-px origin-left scale-x-0 bg-gold transition-transform duration-700 group-hover:scale-x-100" />
        <span aria-hidden="true" className="absolute left-3 top-3 border border-gold/60 bg-[#14060B]/60 px-2 py-1 font-mono text-[8px] uppercase tracking-[0.26em] text-ivory opacity-0  transition-opacity duration-500 group-hover:opacity-100">
          Watch the feature →
        </span>
      </div>
      <p className="mt-2.5 font-serif text-[15px] font-light italic leading-snug text-ivory/80 transition-colors duration-500 group-hover:text-[#E8D9A8]">
        “{article.title}”
      </p>
      <p className="mt-1 font-mono text-[8px] uppercase tracking-[0.26em] text-white/60">{article.date}</p>
    </Link>
  )
}

export default function Community() {
  useSeo({
path: '/community',
    title: 'Community',
    description: 'The Verlyse Media community — 18 features, 1281 appreciations, 576 conversations, and a rule of transparency.',
  })

  const covers = ARTICLES.slice().sort((a, b) => a.date.localeCompare(b.date))
  /* the reel is held, not driven: drag to move it, like a strip of film */
  const reelRef = useRef<HTMLDivElement>(null)
  const drag = useRef<{ x: number; l: number } | null>(null)
  const dragged = useRef(false)
  const startDrag = (e: React.PointerEvent) => {
    const el = reelRef.current
    if (!el || e.pointerType !== 'mouse' && e.pointerType !== 'touch' && e.pointerType !== 'pen') return
    dragged.current = false
    drag.current = { x: e.clientX, l: el.scrollLeft }
    el.classList.add('is-dragging')
    try { el.setPointerCapture(e.pointerId) } catch { /* noop */ }
  }
  const moveDrag = (e: React.PointerEvent) => {
    const el = reelRef.current
    const d = drag.current
    if (!el || !d) return
    const dx = e.clientX - d.x
    if (Math.abs(dx) > 4) dragged.current = true
    if (dragged.current) el.scrollLeft = d.l - dx
  }
  const endDrag = () => {
    drag.current = null
    reelRef.current?.classList.remove('is-dragging')
  }
  const swallowClickAfterDrag = (e: React.MouseEvent) => {
    if (dragged.current) {
      e.preventDefault()
      e.stopPropagation()
      dragged.current = false
    }
  }

  return (
    <>
      <section className="flex min-h-[70svh] items-end border-b border-white/10 bg-wine-deep pb-20 pt-36">
        <PageRail text={`The room — ${COMMUNITY_STATS[1].value} appreciations, ${COMMUNITY_STATS[2].value} conversations`} />
        <div className="mx-auto w-full max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal><p className="eyebrow">Community</p></Reveal>
          <SplitText as="h1" text="A room that writes back" italicWord="writes" className="mt-6 text-[clamp(3.4rem,9.4vw,9rem)]" />
          <Reveal delay={0.2}>
            <p className="mt-6 max-w-[52ch] text-lg leading-[1.8] text-white/70">
              Eighteen features, fifteen credited creators, one thousand two hundred and eighty-one appreciations and five hundred and seventy-six conversations. This is the room those numbers stand for.
            </p>
          </Reveal>
        </div>
      </section>

      {/* The ledger — real numbers from the feed */}
      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-[1.15fr_0.85fr] lg:gap-20">
            <Reveal className="border-t border-white/15 pt-10">
              <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">{COMMUNITY_STATS[0].label}</p>
              <p className="mt-4 font-serif text-[clamp(6rem,13vw,11rem)] font-light leading-[0.9] tracking-[-0.02em] text-ivory">{COMMUNITY_STATS[0].value}</p>
              <p className="mt-6 max-w-[34ch] text-base leading-[1.8] text-white/65">{COMMUNITY_STATS[0].note}</p>
            </Reveal>
            <div className="border-t border-white/15">
              {COMMUNITY_STATS.slice(1).map((st, i) => (
                <Reveal key={st.label} delay={0.1 + i * 0.08}>
                  <div className="flex items-baseline justify-between gap-6 border-b border-white/10 py-7">
                    <span className="font-serif text-3xl font-light text-ivory md:text-4xl">{st.value}</span>
                    <span className="text-right">
                      <span className="block font-mono text-[10px] uppercase tracking-[0.28em] text-white/50">{st.label}</span>
                      <span className="mt-2 block max-w-[30ch] text-sm leading-relaxed text-white/60">{st.note}</span>
                    </span>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* The voice — the real comments, monumental and honest */}
      <section className="border-t border-white/10 py-[clamp(8rem,16vh,12rem)]">
        <div className="mx-auto max-w-[980px] px-[clamp(1.75rem,5.5vw,4.75rem)] text-center">
          <Reveal>
            <p className="kicker">A voice in the room</p>
          </Reveal>
          {COMMUNITY_VOICES.map((v) => (
            <Reveal key={v.handle + v.text.slice(0, 8)} delay={0.1}>
              <blockquote className="mx-auto mt-14 max-w-[820px]">
                <span aria-hidden="true" className="flex items-center justify-center gap-4">
                  <span className="h-px w-14 bg-gold/40" />
                  <span className="font-serif text-2xl leading-none text-gold">“</span>
                  <span className="h-px w-14 bg-gold/40" />
                </span>
                <p className="pull-quote mt-8 text-[clamp(2rem,4.6vw,3.9rem)] leading-[1.18] tracking-[-0.01em] text-ivory">
                  {v.text}
                </p>
                <cite className="mt-8 block font-mono text-[10px] uppercase tracking-[0.28em] text-gold not-italic">
                  {v.handle}
                </cite>
                <p className="mt-1.5 font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">beneath “{v.post}”</p>
              </blockquote>
            </Reveal>
          ))}
          <Reveal delay={0.22} className="mx-auto mt-16 max-w-[640px]">
            <div className="relative rotate-[-0.7deg] border border-gold/25 bg-wine-deep/60 p-8 transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] hover:rotate-0 md:p-10">
              <span aria-hidden="true" className="absolute -left-1.5 -top-1.5 h-3.5 w-3.5 border-l border-t border-gold/70" />
              <span aria-hidden="true" className="absolute -bottom-1.5 -right-1.5 h-3.5 w-3.5 border-b border-r border-gold/70" />
              <p className="kicker mb-5">Our answer — a note from the desk</p>
              <p className="font-serif text-lg font-light italic leading-[1.85] text-ivory/85">
                {BRAND.disclosure}
              </p>
              <p className="mt-5 font-mono text-[9px] uppercase tracking-[0.30em] text-white/50">
                We would rather be asked and answer honestly than hide the hand that set the type.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* The feed in pictures — a film strip of the real covers, drifting like a reel */}
      <section className="border-t border-white/10 py-[clamp(5rem,10vh,8rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal>
            <div className="mb-12 flex flex-wrap items-baseline justify-between gap-4">
              <p className="kicker">The feed in pictures</p>
              <p className="font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">
                {ARTICLES.length} covers, from the first post to the Kashmir cover — the reel is in your hands, drag it
              </p>
            </div>
          </Reveal>
        </div>

        <div className="overflow-hidden bg-[#14060B]">
          <FilmRail aria-hidden="true" />
          <div
            ref={reelRef}
            className="vm-film-scroll overflow-x-auto overscroll-x-contain py-8"
            role="region"
            aria-label="The feed in pictures — all eighteen covers, in order"
            onPointerDown={startDrag}
            onPointerMove={moveDrag}
            onPointerUp={endDrag}
            onPointerLeave={endDrag}
            onPointerCancel={endDrag}
            onClickCapture={swallowClickAfterDrag}
          >
            <div className="flex w-max gap-6 px-[clamp(1.75rem,5.5vw,4.75rem)]">
              {covers.map((a) => (
                <FilmFrame key={a.id} article={a} />
              ))}
            </div>
          </div>
          <FilmRail aria-hidden="true" />
        </div>
      </section>

      {/* Letter from the editors */}
      <section className="border-t border-white/10 bg-charcoal py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <div className="grid grid-cols-1 items-center gap-[clamp(3rem,7vw,8rem)] lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <Reveal><p className="kicker">A letter from the desk</p></Reveal>
              <Reveal delay={0.08}>
                <h2 className="mt-6 font-serif text-[clamp(2.4rem,4.6vw,4rem)] font-light leading-[1.06]">
                  You are <em className="italic text-gold">already</em> part of this
                </h2>
              </Reveal>
              <Reveal delay={0.16}>
                <p className="mt-7 max-w-[54ch] leading-[1.85] text-white/70">
                  The feed opened with a piece written by the founder herself — “Their Voices Matter,” a call for Afghan women’s rights — and it was read, credited, and answered. Every feature after it began the same way: a submission, read carefully, credited fully, and presented with care.
                </p>
              </Reveal>
              <Reveal delay={0.24} className="mt-9">
                <Link to="/submit" className="btn btn-gold">Send your work</Link>
              </Reveal>
            </div>
            <Reveal className="text-center">
              <p aria-hidden="true" className="font-serif text-[clamp(4rem,9vw,7.5rem)] font-semibold text-transparent [-webkit-text-stroke:1px_rgba(248,246,242,0.18)]">Verlyse</p>
              <p className="mt-5 font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">{BRAND.handle} · the conversation is the magazine</p>
            </Reveal>
          </div>
        </div>
      </section>
    </>
  )
}
