import { Link } from 'react-router-dom'
import { useSeo } from '../hooks/useSeo'
import SplitText from '../components/ui/SplitText'
import Reveal from '../components/ui/Reveal'
import { SectionHead, PageRail } from '../components/ui/primitives'
import { BRAND } from '../data/content'

export default function Ambassadors() {
  useSeo({
path: '/ambassadors',
    title: 'Brand Ambassador',
    description: 'The Verlyse Media Brand Ambassador program — application open, as announced on the profile.',
  })

  return (
    <>
      <section className="flex min-h-[70svh] items-end border-b border-white/10 bg-wine-deep pb-20 pt-36">
        <PageRail text="The application is open — the form is linked below" />
        <div className="mx-auto w-full max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal><p className="eyebrow">Brand Ambassador Program</p></Reveal>
          <SplitText as="h1" text="Bring the platform to your campus" italicWord="campus" className="mt-6 text-[clamp(3.4rem,9.4vw,9rem)]" />
          <Reveal delay={0.2}>
            <p className="mt-6 max-w-[52ch] text-lg leading-[1.8] text-white/70">
              The profile announces it plainly: “Brand Ambassador &amp; submission application now open.” The application form is open — <a href={BRAND.ambassadorForm} target="_blank" rel="noopener noreferrer" className="font-mono text-[12px] tracking-[0.08em] text-gold underline decoration-gold/40 underline-offset-4 transition-colors hover:text-ivory">apply through the link below →</a>
            </p>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto grid max-w-page grid-cols-1 items-center gap-[clamp(3rem,7vw,8rem)] px-[clamp(1.75rem,5.5vw,4.75rem)] lg:grid-cols-[1.2fr_0.8fr]">
          <div>
            <Reveal>
              <p className="max-w-[28ch] font-serif text-[clamp(1.5rem,2.4vw,2rem)] font-light italic leading-[1.45] text-ivory">
                Ambassadors are the magazine’s hands in the world — one reader per campus, sharing the features, opening the room.
              </p>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mt-7 max-w-[54ch] leading-[1.85] text-white/70">
                The program is announced on the profile and led by a head of brand ambassador, credited there by the platform itself. What the role requires, and what it offers, is set out in the application form — the exact details of the program live in that form, and the form is open.
              </p>
            </Reveal>
            <Reveal delay={0.18} className="mt-9 flex flex-wrap items-center gap-6">
              <a
                href={BRAND.ambassadorForm}
                target="_blank" rel="noopener noreferrer"
                className="btn btn-gold"
              >
                Apply as an ambassador
              </a>
              <Link to="/submit" className="border-b border-gold/60 pb-1 font-mono text-[10px] uppercase tracking-[0.28em] text-gold no-underline transition-colors hover:text-ivory">
                or send your work →
              </Link>
            </Reveal>
          </div>
          <Reveal className="text-right">
            <p aria-hidden="true" className="font-serif text-[clamp(6rem,14vw,12rem)] font-semibold leading-[0.85] text-transparent [-webkit-text-stroke:1px_rgba(184,145,70,0.5)]">01</p>
            <p className="mt-6 font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">Ambassador per campus — one, to start</p>
          </Reveal>
        </div>
      </section>

      {/* The room — the team behind the magazine */}
      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <SectionHead eyebrow="The team" page="P. 02" ghost="02" />
          <div className="border-t border-white/10">
            {BRAND.team.map((m, i) => (
              <Reveal key={m.name} delay={Math.min(i * 0.05, 0.3)} className="group">
                <div className="grid grid-cols-1 gap-1.5 border-b border-white/10 py-6 md:grid-cols-[64px_200px_1fr_auto] md:items-center md:gap-x-8 md:py-8">
                  {/* the monogram — the room's mark, the same diamond that signs each feature */}
                  <span aria-hidden="true" className="relative hidden h-12 w-12 place-items-center md:grid">
                    <span className="absolute inset-0 rotate-45 border border-gold/40 transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:rotate-[135deg]" />
                    <span className="font-serif text-lg italic text-gold">{m.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}</span>
                  </span>
                  <p className="font-mono text-[10px] uppercase leading-[1.7] tracking-[0.28em] text-gold md:pt-1.5">{m.role}</p>
                  <div>
                    <p className="font-serif text-[clamp(1.35rem,2vw,1.7rem)] font-normal leading-snug text-ivory">{m.name}</p>
                    <p className="mt-2 max-w-[56ch] text-sm leading-[1.7] text-white/60">{m.description}</p>
                  </div>
                  {m.handle && (
                    <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-white/55 md:pt-1.5 md:text-right">{m.handle}</p>
                  )}
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-12">
            <p className="max-w-[58ch] text-sm leading-[1.8] text-white/55">
              The team as it stands today — every role above belongs to the people who make Verlyse Media. Where a handle is public, it sits beside the name.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <SectionHead eyebrow="Apply" page="P. 03" ghost="03" />
          <Reveal className="border border-gold/25 bg-gradient-to-b from-wine-deep to-[#2A0811] p-12 text-center md:p-16">
            <p className="font-serif text-[clamp(2rem,4vw,3.4rem)] font-light text-ivory">The application is open</p>
            <p className="mx-auto mt-5 max-w-[46ch] [overflow-wrap:anywhere] font-serif text-xl font-light italic leading-[1.6] text-white/60">
              “Brand Ambassador &amp; submission application now open” — the announcement on the profile, word for word. The application form is open — <a href={BRAND.ambassadorForm} target="_blank" rel="noopener noreferrer" className="font-mono text-[11px] tracking-[0.08em] text-gold underline decoration-gold/40 underline-offset-4 transition-colors hover:text-ivory">apply now →</a>
            </p>
            <p className="mt-8 font-mono text-[10px] uppercase tracking-[0.28em] text-gold">
              Questions? Write to us at {BRAND.handle} on Instagram
            </p>
          </Reveal>
        </div>
      </section>
    </>
  )
}
