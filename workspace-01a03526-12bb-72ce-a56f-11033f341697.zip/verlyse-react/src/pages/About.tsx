import { motion } from 'framer-motion'
import { useSeo } from '../hooks/useSeo'
import SplitText from '../components/ui/SplitText'
import Reveal from '../components/ui/Reveal'
import { SectionHead, PageRail } from '../components/ui/primitives'
import { MotifGlyph } from '../components/ui/Motifs'
import { BRAND } from '../data/content'

const VALUES = [
  { n: 'I', t: 'Creator credit', g: 'letter', d: 'All 18 features name their writers in the caption, by name and handle. The byline is not a courtesy; it is the point.' },
  { n: 'II', t: 'Transparency', g: 'code', d: 'The captions disclose the tools used to create posts — and when a post is made entirely by its creator, that is stated too.' },
  { n: 'III', t: 'Care in presentation', g: 'quote', d: 'Submissions are transformed into visually engaging posts that reflect a signature aesthetic — or featured as already-designed work that fits.' },
  { n: 'IV', t: 'The conversation', g: 'voices', d: '576 conversations beneath the features — all of them read, several of them quoted on the community page.' },
]

const FOUNDER_TIMELINE = [
  { date: 'Before', title: 'The reason', desc: 'Alina worked at another company where her efforts and creativity were not truly appreciated. Instead of letting that discourage her, she used it as motivation — a platform where creators feel valued.' },
  { date: '26.06.2026', title: 'The feed opens', desc: '“Their Voices Matter” — her call for Afghan women’s rights — is the first post on the feed, written by the founder herself.' },
  { date: '02.07.2026', title: 'Her prose poem', desc: '“Hope Becomes Mythology,” inspired by The Great Gatsby, is published on the feed — the fragile line between love and idealization.' },
  { date: '07.07.2026', title: '“Meet Alina Javed”', desc: 'havexmedia publishes a feature on the platform’s founder — at sixteen, building something meaningful.' },
  { date: 'Now', title: 'The room', desc: '18 features, 15 creators, 1281 appreciations — and the real achievement: the trust people place in the platform.' },
]

const MILESTONES = [
  { year: '26.06', title: 'The feed opens — a call for women’s rights', desc: '“Their Voices Matter,” written by the founder herself, opens the feed — a call for the women of Afghanistan, answered with 133 appreciations.', cover: '/img/works/DaDY7WRkw0y-1.webp' },
  { year: '16.07', title: '“3:13” — the horror feature', desc: 'Anshujit Singh’s psychological horror, presented in three posters with the writer’s note in his own words.', cover: '/img/poster-3-13-1.webp' },
  { year: 'Now', title: '18 features, 15 creators', desc: 'Poetry, essays, art, calligraphy, stories, social issues and a student’s Khageena — every one credited, every one read.', cover: '/img/works/DbaNAZTk5X9-1.webp' },
]

export default function About() {
  useSeo({
path: '/about',
    title: 'About',
    description: 'About Verlyse Media — where vision becomes a voice. Submissions presented with credit, care and transparency.',
  })

  return (
    <>
      <section className="relative flex min-h-[70svh] items-end border-b border-white/10 bg-wine-deep pb-20 pt-36">
        <PageRail text="The story — short and true" />
        <div className="mx-auto w-full max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal><p className="eyebrow">About Verlyse Media</p></Reveal>
          <SplitText as="h1" text="We present the young" italicWord="present" className="mt-6 text-[clamp(3.4rem,9.4vw,9rem)]" />
          <Reveal delay={0.2}>
            <p className="mt-6 max-w-[52ch] text-lg leading-[1.8] text-white/70">
              {BRAND.tagline}. A magazine that takes submissions from writers no one has heard of yet, credits them by name, and sets their work out with care.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Editorial essay */}
      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto grid max-w-page grid-cols-1 gap-[clamp(2rem,5vw,6rem)] px-[clamp(1.75rem,5.5vw,4.75rem)] lg:grid-cols-[0.78fr_1.22fr]">
          <aside className="flex flex-col gap-6 pt-6">
            {['A platform for submissions', 'One feature at a time', 'Credited, designed, shared'].map((n, i) => (
              <Reveal key={n} delay={i * 0.08}>
                <p className="border-l border-gold pl-5 font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">{n}</p>
              </Reveal>
            ))}
          </aside>
          <article>
            <Reveal>
              <p className="max-w-[30ch] font-serif text-[clamp(1.5rem,2.4vw,2rem)] font-light italic leading-[1.45] text-ivory">
                {BRAND.mission.split('. ')[0]}.
              </p>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mt-8 max-w-[58ch] leading-[1.9] text-white/70 drop-cap">
                On the twenty-sixth of June 2026, the feed opened with “Their Voices Matter” — a call for Afghan women’s rights, written by the founder herself. The first submitted feature followed on the thirtieth: Shaza Fatima’s essay on why the arts deserve the same respect as every other field. Both were published with names and handles in the caption, and with each writer’s words intact.
              </p>
            </Reveal>
            <Reveal delay={0.18}>
              <p className="mt-7 max-w-[58ch] leading-[1.9] text-white/70">
                The caption of the feature states the tool used to create the post — Microsoft Designer. The writing, the voice, and the idea belong to the writer; the tools behind the presentation are disclosed. That is the practice, stated plainly.
              </p>
            </Reveal>
            <Reveal delay={0.24}>
              <p className="mt-7 max-w-[58ch] leading-[1.9] text-white/70">
                The magazine is young, its archive is short, and everything in it is true.
              </p>
            </Reveal>
            <Reveal delay={0.26} className="mt-10 border-l-2 border-gold pl-7">
              <p className="font-serif text-[clamp(1.35rem,2.1vw,1.75rem)] font-light italic leading-[1.45] text-ivory">
                “The real horror isn't what's in the closet. It's that eventually, it will be your turn to wait.”
              </p>
              <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">— from the writer's note, “3:13” by Anshujit Singh</p>
            </Reveal>
          </article>
        </div>
      </section>

      {/* Values */}
      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <h2 className="sr-only">What we believe</h2>
          <SectionHead eyebrow="What we believe" page="P. 02" ghost="02" />
          <div className="grid grid-cols-1 border-t border-white/10 md:grid-cols-2">
            {VALUES.map((v, i) => (
              <Reveal key={v.n} delay={i * 0.07} className={`group relative border-b border-white/10 py-10 ${i % 2 === 0 ? 'md:border-r md:pr-12' : 'md:pl-12'}`}>
                {/* the charter's mark — a living glyph from the publications themselves */}
                <span aria-hidden="true" className="pointer-events-none absolute right-0 top-10 opacity-[0.16] transition-opacity duration-700 md:right-4 group-hover:opacity-40">
                  <MotifGlyph type={v.g} />
                </span>
                <span className="font-mono text-[10px] tracking-[0.28em] text-gold">{v.n}</span>
                <h3 className="mt-4 font-serif text-2xl font-medium text-ivory">{v.t}</h3>
                <p className="mt-3 max-w-[36ch] text-sm leading-relaxed text-white/60">{v.d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Milestones */}
      <section className="border-t border-white/10 bg-charcoal py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-[860px] px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <h2 className="sr-only">Milestones</h2>
          <SectionHead eyebrow="Milestones" page="P. 03" ghost="03" />
          {MILESTONES.map((m, i) => (
            <Reveal key={m.year} delay={i * 0.08} className="group">
              <div className="grid grid-cols-1 gap-4 border-b border-white/10 py-8 md:grid-cols-[120px_88px_1fr] md:gap-8">
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-gold md:pt-2">{m.year}</p>
                {/* the plate — the feed as it was on that day */}
                <div className="w-20 md:w-24">
                  <div className="img-frame relative aspect-[3/4] rotate-[-1.5deg] overflow-hidden border border-white/12 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:rotate-0 group-hover:border-gold/40">
                    <img src={m.cover} alt="" loading="lazy" className="h-full w-full object-cover" />
                    <span aria-hidden="true" className="absolute inset-0 border border-gold/0 transition-colors duration-500 group-hover:border-gold/40" />
                  </div>
                </div>
                <div>
                  <h3 className="font-serif text-[clamp(1.35rem,2vw,1.7rem)] font-normal text-ivory">{m.title}</h3>
                  <p className="mt-2 max-w-[52ch] leading-[1.7] text-white/60">{m.desc}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

            {/* Founder — a conversation with the founder */}
      <section className="relative overflow-hidden border-t border-white/10 py-[clamp(8rem,16vh,12rem)]">
        <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-72 bg-[radial-gradient(62%_55%_at_50%_6%,rgba(184,145,70,0.05),transparent_74%)]" />

        <div className="relative mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal><p className="kicker">A conversation with the founder</p></Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-6 max-w-[18ch] font-serif text-[clamp(2.8rem,6vw,5.4rem)] font-light leading-[1.02] tracking-[-0.02em] text-ivory">
              Why a sixteen-year-old <em className="italic text-gold">built a magazine</em>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="pull-quote mt-10 max-w-[64ch] text-[clamp(1.4rem,2.2vw,1.9rem)] leading-[1.6] text-ivory/85">
              At just sixteen, Alina Javed is proving that age is no barrier to building something meaningful — and that a platform’s real achievement lies in the trust people place in it.
            </p>
          </Reveal>

          <div className="mt-16 grid grid-cols-1 items-start gap-[clamp(3rem,7vw,8rem)] lg:grid-cols-[0.92fr_1.08fr]">
            <div className="lg:sticky lg:top-28">
              <Reveal>
                <figure className="relative">
                  <div aria-hidden="true" className="absolute -inset-4 translate-x-5 translate-y-5 border border-gold/30" />
                  <div className="img-frame relative overflow-hidden">
                    <img
                      src="/img/authors/alina-javed-about.jpg"
                      alt="Alina Javed, founder of Verlyse Media — portrait"
                      loading="lazy"
                      className="w-full object-contain"
                    />
                    <span aria-hidden="true" className="pointer-events-none absolute inset-3 border border-gold/40" />
                  </div>
                  <figcaption className="fig-cap mt-5 flex items-center justify-between border-t border-white/10 pt-3 text-white/50">
                    <span>Alina Javed — founder, sixteen</span>
                    <span>Plate 01 — portrait, 2026</span>
                  </figcaption>
                </figure>
              </Reveal>

              <Reveal delay={0.15} className="mt-14">
                <div className="border-t border-white/10 pt-6">
                  <p className="font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">Signed —</p>
                  <p className="mt-5 inline-block font-serif text-4xl font-light italic text-gold" style={{ transform: 'rotate(-2deg)' }}>
                    Alina Javed
                  </p>
                  <svg viewBox="0 0 220 22" fill="none" aria-hidden="true" className="mt-1 block h-[22px] w-56 overflow-visible">
                    <motion.path
                      d="M6 13 C 45 4, 130 18, 214 9"
                      stroke="#B89146"
                      strokeWidth="1.7"
                      strokeLinecap="round"
                      initial={{ pathLength: 0 }}
                      whileInView={{ pathLength: 1 }}
                      viewport={{ once: true, margin: '0px 0px -10% 0px' }}
                      transition={{ duration: 1.5, ease: 'easeInOut', delay: 0.35 }}
                    />
                  </svg>
                  <p className="mt-3 font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">Founder — Verlyse Media · @lina_.jved</p>
                </div>
              </Reveal>
            </div>

            <div>
              <Reveal>
                <p className="max-w-[60ch] leading-[1.95] text-white/70 drop-cap">
                  Creativity has always been at the heart of her journey — from designing original visuals to editing content and writing meaningful stories. For her, creativity isn’t just a hobby; it’s a way of expressing emotions, sharing perspectives, and connecting with people. She believes words have the power to inspire, influence, and leave a lasting impact — a belief that became one of the foundations of the platform.
                </p>
              </Reveal>
              <Reveal delay={0.1}>
                <p className="mt-8 max-w-[60ch] leading-[1.95] text-white/70">
                  Every successful venture begins with a reason. Before launching Verlyse Media, Alina worked with another company where her efforts and creativity were not truly appreciated. Instead of allowing that experience to discourage her, she used it as motivation — building a platform where creators could feel valued, receive recognition for their work, and become part of a supportive community. That vision became Verlyse Media.
                </p>
              </Reveal>

              <Reveal className="mt-14">
                <div className="border-l border-gold/25 pl-8">
                  {FOUNDER_TIMELINE.map((m, i) => (
                    <motion.div
                      key={m.title}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '0px 0px -10% 0px' }}
                      transition={{ duration: 0.95, ease: [0.16, 1, 0.3, 1], delay: i * 0.1 }}
                      className="relative border-b border-white/10 py-8 last:border-b-0"
                    >
                      <span aria-hidden="true" className="absolute -left-[37px] top-9 h-2.5 w-2.5 rounded-full border border-gold bg-wine-deep" />
                      <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-gold">{m.date}</p>
                      <h3 className="mt-2 font-serif text-2xl font-normal text-ivory">{m.title}</h3>
                      <p className="mt-2 max-w-[52ch] text-sm leading-[1.85] text-white/60">{m.desc}</p>
                    </motion.div>
                  ))}
                </div>
              </Reveal>

              <Reveal className="mt-14 border-y border-gold/25 py-10">
                <p className="pull-quote text-[clamp(1.5rem,2.4vw,2.1rem)] text-ivory">
                  “Great ideas don’t wait for the ‘perfect’ age or the ‘perfect’ opportunity. Sometimes, all it takes is believing in your vision and having the courage to create it yourself.”
                </p>
                <p className="mt-4 font-mono text-[9px] uppercase tracking-[0.30em] text-white/50">— on Alina Javed, havexmedia · 07.07.2026</p>
              </Reveal>

              <Reveal delay={0.08} className="mt-10">
                <p className="pull-quote max-w-[52ch] text-[clamp(1.15rem,1.7vw,1.4rem)] leading-[1.7] text-white/65">
                  “The real achievement lies in the trust people place in the platform.”
                </p>
                <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.30em] text-white/50">— from the feature on the founder</p>
              </Reveal>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
