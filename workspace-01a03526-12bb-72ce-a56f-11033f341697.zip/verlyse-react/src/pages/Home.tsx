import { Link } from 'react-router-dom'
import { motion, useReducedMotion } from 'framer-motion'
import { useRef } from 'react'
import { useSeo } from '../hooks/useSeo'
import Reveal from '../components/ui/Reveal'
import CountUp from '../components/ui/CountUp'
import VoiceCarousel from '../components/ui/VoiceCarousel'
import { MotifDivider } from '../components/ui/ArticleClosing'
import { AnticipatedTitle, ReflectionLine } from '../components/ui/ScrollBeat'
import { LibraryCard, HiddenQuote } from '../components/ui/EasterEggs'
import { MetaRow, SectionHead, UnderlineLink } from '../components/ui/primitives'
import { ARTICLES, BRAND, CATEGORIES, COMMUNITY_STATS, getAuthor } from '../data/content'

/**
 * Home — the cover of the magazine.
 * Typographic masthead over brand atmosphere, a feature card, a live ledger
 * of real numbers, and a strip of the platform's actual featured works.
 */


/** The cover: masthead + breathing headline + ledger + feature card. */
function Cover() {
  const ref = useRef<HTMLDivElement>(null)
  const reduce = useReducedMotion()
  const feature = ARTICLES[0]
  const author = getAuthor(feature.authorId)!
  const E = [0.22, 1, 0.36, 1] as const
  /* entrance timeline, synced to the preloader curtain (≈2.0s) */
  const T = { bg: 1.6, mast: 1.7, rule: 1.85, bio: 2.0, h1a: 2.1, h1b: 2.25, ink: 2.6, plate: 2.2, deck: 2.8, cta: 3.05, ledger: 3.35 }

  return (
    <section ref={ref} className="relative flex min-h-[100svh] items-end overflow-hidden border-b border-white/10 bg-wine-deep">
      {/* ——— Layer 1 · brand atmosphere ——— */}
      <div className="absolute inset-x-0 -top-[10%] bottom-[-10%] z-0" aria-hidden="true">
        <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_50%_0%,rgba(92,18,36,0.9),transparent_62%),radial-gradient(90%_70%_at_90%_100%,rgba(184,145,70,0.14),transparent_60%),linear-gradient(170deg,#3B0D17_0%,#2E0913_55%,#1C1C1C_100%)]" />
      </div>

      {/* ——— Layer 2 · clean atmospheric light — a soft top glow and a warm floor, no grain ——— */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-[1] bg-[radial-gradient(85%_45%_at_50%_0%,rgba(248,246,242,0.045),transparent_60%),radial-gradient(70%_45%_at_88%_100%,rgba(184,145,70,0.07),transparent_62%)]" />

      {/* ——— Layer 3 · ghost masthead wordmark, engraved and still ——— */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-[12%] z-0 flex justify-center">
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 24 }}
          animate={{ opacity: reduce ? 0.9 : 1, y: 0 }}
          transition={{ duration: 2.8, delay: 1.7, ease: [0.16, 1, 0.3, 1] }}
          className="select-none whitespace-nowrap font-serif text-[clamp(9rem,26vw,24rem)] font-semibold leading-[0.8] text-transparent [-webkit-text-stroke:1px_rgba(184,145,70,0.13)]"
        >
          Verlyse
        </motion.p>
      </div>

      {/* ——— Layer 4 · deep editorial vignette ——— */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-[1] bg-[radial-gradient(110%_80%_at_16%_30%,rgba(22,5,10,0.55),transparent_58%)]" />

      {/* ——— Masthead band — sits BELOW the fixed navigation row in its own
          space (top-[86px] = the header's unscrolled height), so the eyebrow
          and "Est. 2026" never pass behind/through the nav ——— */}
      <motion.div
        initial={reduce ? false : { opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.1, delay: T.mast, ease: E }}
        className="absolute inset-x-0 top-[86px] z-[3]"
      >
        <div className="mx-auto flex max-w-page items-center justify-between border-b border-white/15 px-[clamp(1.75rem,5.5vw,4.75rem)] py-4">
          <span className="font-serif text-sm uppercase tracking-[0.3em] text-ivory/90">
            Verlyse <em className="italic text-gold">Media</em>
          </span>
          <span className="hidden font-mono text-[9px] uppercase tracking-[0.34em] text-white/60 md:inline">Student-led · culture · global issues · creativity</span>
          <span className="font-mono text-[9px] uppercase tracking-[0.34em] text-white/60">Est. 2026</span>
        </div>
      </motion.div>

      {/* ——— The editorial plate — the current feature, revealed like a print ——— */}
      <motion.div
        initial={{ opacity: 0, y: reduce ? 0 : 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, delay: T.plate, ease: E }}
        className="absolute right-[clamp(1.75rem,5.5vw,4.75rem)] top-1/2 z-[3] hidden w-[272px] -translate-y-1/2 xl:block"
      >
        <Link to={`/article/${feature.id}`} className="group block no-underline" aria-label={`Read “${feature.title}” — the current feature`}>
          <div className="relative">
            {/* offset print frame */}
            <div aria-hidden="true" className="absolute -inset-3 -z-10 translate-x-3 translate-y-3 border border-gold/40 transition-transform duration-700 ease-out group-hover:translate-x-2 group-hover:translate-y-2" />
            {/* corner ticks */}
            <span aria-hidden="true" className={`absolute -left-2 -top-2 h-4 w-4 border-l border-t border-gold ${reduce ? '' : 'animate-vm-breathe'}`} />
            <span aria-hidden="true" className={`absolute -right-2 -top-2 h-4 w-4 border-r border-t border-gold ${reduce ? '' : 'animate-vm-breathe'}`} style={{ animationDelay: '1.2s' }} />
            <span aria-hidden="true" className={`absolute -bottom-2 -left-2 h-4 w-4 border-b border-l border-gold ${reduce ? '' : 'animate-vm-breathe'}`} style={{ animationDelay: '2.1s' }} />
            <span aria-hidden="true" className={`absolute -bottom-2 -right-2 h-4 w-4 border-b border-r border-gold ${reduce ? '' : 'animate-vm-breathe'}`} style={{ animationDelay: '0.6s' }} />

            {/* smooth image reveal: the plate lifts from the paper */}
            <motion.div
              className="overflow-hidden border border-white/10"
              initial={{ clipPath: 'inset(100% 0% 0% 0%)' }}
              animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
              transition={{ duration: 1.5, delay: T.plate + 0.25, ease: [0.65, 0.05, 0.36, 1] }}
            >
              <img
                src={feature.cover}
                alt={`The current feature, “${feature.title}”`}
                className={`aspect-[4/5] w-full object-cover ${reduce ? '' : 'animate-vm-kenburns'}`}
              />
            </motion.div>

            {/* plate caption — set like a print's marginalia */}
            <div className="mt-4 border-t border-white/10 pt-3">
              <p className="font-mono text-[9px] uppercase tracking-[0.30em] text-gold">The first feature — plate I</p>
              <p className="mt-1 font-serif text-xl leading-none text-ivory">“{feature.title}”</p>
              <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.34em] text-white/60">By {author.name} · {author.handle}</p>
              <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.34em] text-white/60">{feature.category} — presented {feature.date}</p>
            </div>
          </div>
        </Link>
      </motion.div>

      {/* ——— Left-set editorial copy ——— */}
      <div className="relative z-[2] mx-auto w-full max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)] pb-28 pt-44">
        {/* eyebrow: bio + drawing gold rule */}
        <div className="flex items-center gap-5">
          <motion.span
            aria-hidden="true"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1.1, delay: T.rule, ease: E }}
            className="h-px w-12 origin-left bg-gold"
          />
          <motion.p
            initial={{ opacity: 0, y: reduce ? 0 : 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: T.bio, ease: E }}
            className="eyebrow !mb-0"
          >
            {BRAND.bio}
          </motion.p>
        </div>

        {/* headline — mask reveal, blur-to-sharp, like ink settling on paper */}
        <h1 className="mt-9 max-w-[15ch] font-serif text-[clamp(2.55rem,9.2vw,8.4rem)] font-light leading-[1.08] tracking-[-0.025em]">
          <span className="block overflow-hidden pb-[0.14em]">
            <motion.span
              className="inline-block"
              initial={{ y: '118%' }}
              animate={{ y: 0 }}
              transition={{ duration: 1.1, delay: T.h1a, ease: E }}
            >
              Where Vision
            </motion.span>
          </span>
          <span className="block overflow-hidden pb-[0.14em]">
            <motion.span
              className="inline-block"
              initial={{ y: '118%' }}
              animate={{ y: 0 }}
              transition={{ duration: 1.1, delay: T.h1b, ease: E }}
            >
              Becomes A <em className="italic text-gold">Voice</em>
            </motion.span>
          </span>
        </h1>

        {/* the ink flourish — a hand-drawn underline, drawn after the words land */}
        <motion.svg
          aria-hidden="true"
          viewBox="0 0 340 26"
          fill="none"
          initial={reduce ? false : { opacity: 0, y: 8 }}
          animate={{ opacity: reduce ? 0 : 1, y: 0 }}
          transition={{ duration: 0.8, delay: T.ink, ease: E }}
          className="mt-1 h-[26px] w-[min(420px,80%)] overflow-visible"
        >
          <motion.path
            d="M6 18 C 90 5, 205 5, 334 13"
            stroke="#B89146"
            strokeWidth="2.2"
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: reduce ? 1 : undefined }}
            transition={{ duration: 1.2, delay: T.ink + 0.15, ease: 'easeInOut' }}
          />
        </motion.svg>

        {/* deck — the magazine's promise, in its own voice */}
        <motion.p
          initial={{ opacity: 0, y: reduce ? 0 : 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: T.deck, ease: E }}
          className="mt-8 max-w-[44ch] text-lg leading-[1.8] text-ivory/85"
        >
          A platform for artists, writers and storytellers — where every meaningful creation gets an audience, a credit, and a room of its own.
        </motion.p>

        {/* gestures */}
        <motion.div
          initial={{ opacity: 0, y: reduce ? 0 : 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: T.cta, ease: E }}
          className="mt-10 flex flex-wrap items-center gap-8"
        >
          <Link to="/submit" className="btn btn-gold">Send your work</Link>
          <UnderlineLink to={`/article/${feature.id}`}>Read the current feature</UnderlineLink>
        </motion.div>

        {/* the ledger — real numbers, set like marginalia */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: T.ledger, ease: E }}
          className="mt-14 grid max-w-[560px] grid-cols-2 gap-x-6 gap-y-5 border-t border-white/15 pt-5 sm:flex sm:items-start sm:justify-between sm:gap-6"
          aria-label="The magazine in numbers"
        >
          {COMMUNITY_STATS.map((st, i) => (
            <motion.span
              key={st.label}
              className="flex flex-col gap-1.5 sm:min-w-0 sm:flex-1 sm:pr-3 sm:last:pr-0"
              initial={{ opacity: 0, y: reduce ? 0 : 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: T.ledger + 0.15 + i * 0.14, ease: E }}
            >
              <CountUp value={parseInt(st.value, 10)} className="font-serif text-3xl font-light leading-none text-ivory" />
              {/* the hero is marginalia — short labels sit on one line */}
              <span className="mt-1 whitespace-nowrap font-mono text-[9px] uppercase leading-none tracking-[0.30em] text-white/50">
                {st.label === 'Features presented' ? 'Features' : st.label === 'Creators credited' ? 'Creators' : st.label}
              </span>
            </motion.span>
          ))}
        </motion.div>
      </div>

      {/* folio bar */}
      <div className="absolute inset-x-0 bottom-0 z-[2]" aria-hidden="true">
        <motion.div
          initial={reduce ? false : { y: 12 }}
          animate={{ y: 0 }}
          transition={{ duration: 1.2, delay: 2.2, ease: [0.16, 1, 0.3, 1] }}
        >
        <div className="mx-auto flex max-w-page items-center justify-between border-t border-white/15 px-[clamp(1.75rem,5.5vw,4.75rem)] py-4 font-mono text-[9px] uppercase tracking-[0.34em] text-white/65">
          <span>Verlyse Media presents</span>
          <span className="hidden sm:inline">The first feature — “{feature.title}” · {feature.date}</span>
          <span>{BRAND.handle}</span>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

/** The issue band — the magazine's real numbers, set still. */
function IssueBand() {
  return (
    <section className="border-b border-white/10 bg-wine py-7" aria-label="The magazine in numbers">
      <div className="mx-auto flex max-w-page flex-wrap items-center justify-center gap-x-10 gap-y-3 px-[clamp(1.75rem,5.5vw,4.75rem)] font-serif text-xl font-light italic leading-none text-ivory/85 md:text-2xl">
        <span>18 features</span>
        <i aria-hidden="true" className="text-[0.7em] not-italic text-gold">✦</i>
        <span>15 creators</span>
        <i aria-hidden="true" className="text-[0.7em] not-italic text-gold">✦</i>
        <span>1281 appreciations</span>
        <i aria-hidden="true" className="text-[0.7em] not-italic text-gold">✦</i>
        <span>576 conversations</span>
        <i aria-hidden="true" className="text-[0.7em] not-italic text-gold">✦</i>
        <span className="text-ivory/60">one room</span>
        <i aria-hidden="true" className="text-[0.7em] not-italic text-gold">✦</i>
        <span className="text-gold/90">and the next one could be yours</span>
      </div>
    </section>
  )
}

/* ------------------------------------------------------------------ */
/* Featured stories — the latest issue, set like a magazine spread.   */
/* ------------------------------------------------------------------ */
type StorySize = 'cover' | 'stack' | 'spread' | 'bottom'

const STORY_IMAGE: Record<StorySize, string> = {
  cover: 'aspect-[4/5]',
  stack: 'aspect-[3/4]',
  spread: 'aspect-[3/4]',
  bottom: 'aspect-[16/10]',
}
const STORY_TITLE: Record<StorySize, string> = {
  cover: 'text-[clamp(2.1rem,3.6vw,3.4rem)]',
  stack: 'text-xl md:text-2xl',
  spread: 'text-xl md:text-2xl',
  bottom: 'text-2xl md:text-3xl',
}

function StoryCard({
  work,
  index,
  size = 'spread',
  showExcerpt = false,
}: {
  work: (typeof ARTICLES)[number]
  index: string
  size?: StorySize
  showExcerpt?: boolean
}) {
  const au = getAuthor(work.authorId)
  const cover = size === 'cover'
  return (
    <Link
      to={`/article/${work.id}`}
      className={`group block no-underline ${cover ? 'lg:flex lg:h-full lg:flex-col' : ''}`}
      aria-label={`Read “${work.title}”`}
    >
      <div
        className={`img-frame relative overflow-hidden border border-white/10 transition-colors duration-700 group-hover:border-gold/45 ${
          cover ? 'aspect-[4/5] lg:aspect-auto lg:flex-1' : STORY_IMAGE[size]
        }`}
      >
        <img
          src={work.cover}
          alt={`${work.title} — ${work.category}`}
          loading="lazy"
          className={`h-full w-full object-cover ${cover ? 'animate-vm-kenburns' : 'transition-transform duration-[1800ms] ease-out group-hover:scale-[1.06]'}`}
        />
        <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-[#1C0509]/70 via-transparent to-transparent opacity-0 transition-opacity duration-700 group-hover:opacity-100" />
        <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-px origin-left scale-x-0 bg-gold transition-transform duration-700 ease-out group-hover:scale-x-100" />

        {cover && (
          <span
            aria-hidden="true"
            className="absolute left-5 top-1/2 hidden -translate-y-1/2 -rotate-90 origin-left whitespace-nowrap font-mono text-[9px] uppercase tracking-[0.42em] text-gold/90 md:block"
          >
            Cover story — Verlyse Media
          </span>
        )}

        <span
          aria-hidden="true"
          className="absolute right-4 top-4 translate-y-1 border border-gold/70 bg-[#1C0509]/55 px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.30em] text-ivory opacity-0  transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100"
        >
          Read feature →
        </span>

        <span
          aria-hidden="true"
          className={`absolute font-mono uppercase tracking-[0.26em] transition-colors duration-500 group-hover:text-gold ${cover ? 'right-5 top-5 text-[10px] text-white/70' : 'bottom-3 right-3 text-[9px] text-white/70'}`}
        >
          {index}
        </span>
      </div>

      <div className="mt-5">
        <MetaRow category={work.category} author={au?.name} readingTime={work.readingTime} />
        <h3 className={`mt-3 font-serif font-normal leading-[1.12] text-ivory transition-all duration-700 group-hover:italic group-hover:text-[#E8D9A8] ${STORY_TITLE[size]}`}>
          {cover ? (
            <>
              <span aria-hidden="true" className="mr-3 font-mono text-[0.42em] font-normal tracking-[0.3em] text-gold not-italic">01</span>
              “{work.title}”
            </>
          ) : (
            <>“{work.title}”</>
          )}
        </h3>
        {showExcerpt && (
          <p className="mt-4 max-w-[46ch] text-[15px] leading-[1.8] text-white/60">{work.excerpt}</p>
        )}
        {cover && (
          <p className="mt-5">
            <span className="border-b border-gold/60 pb-1 font-mono text-[10px] uppercase tracking-[0.28em] text-gold transition-colors duration-500 group-hover:text-ivory">
              Continue reading <span aria-hidden="true">→</span>
            </span>
          </p>
        )}
      </div>
    </Link>
  )
}

function WorksStrip() {
  const works = ARTICLES.slice().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8)
  const [cover, s1, s2, ...rest] = works
  const spread = rest.slice(0, 3)
  const bottom = rest.slice(3, 5)

  return (
    <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
      <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
        {/* ——— the contents page ——— */}
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6 border-b border-white/10 pb-10">
            <div>
              <p className="kicker mb-5">The feed — issue 01</p>
              <AnticipatedTitle className="max-w-[18ch]">
                <h2 className="font-serif text-[clamp(2.4rem,4.8vw,4.2rem)] font-light leading-[1.02] text-ivory">
                  In this <em className="italic text-gold">issue</em>
                </h2>
              </AnticipatedTitle>
            </div>
            <div className="text-right">
              <p className="font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">Features 01–08 · June–August 2026</p>
              <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">18 features · 15 creators · 1281 appreciations</p>
              <p className="mt-3 max-w-[30ch] font-serif text-base font-light italic leading-[1.6] text-ivory/70">
                The next issue could begin with your name.
              </p>
              <div className="mt-4">
                <UnderlineLink to="/articles">All 18 works</UnderlineLink>
              </div>
            </div>
          </div>
        </Reveal>

        {/* ——— the cover story + supporting stack ——— */}
        <div className="mt-16 grid grid-cols-1 gap-x-14 gap-y-16 lg:grid-cols-12">
          <Reveal className="lg:col-span-7 lg:h-full">
            <StoryCard work={cover} index="Cover" size="cover" showExcerpt />
          </Reveal>

          <div className="flex flex-col gap-y-14 lg:col-span-5">
            <Reveal>
              <StoryCard work={s1} index="02" size="stack" />
            </Reveal>

            {/* the issue note — a quiet interlude between the stack stories */}
            <Reveal delay={0.06} className="border-y border-gold/20 py-8">
              <p className="pull-quote text-[clamp(1.15rem,1.7vw,1.4rem)] leading-[1.6] text-ivory/80">
                Every feature in this issue begins the same way — a submission, read carefully, credited fully, and presented with care.
              </p>
              <p className="mt-3 font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">— the desk, Verlyse Media</p>
            </Reveal>

            <Reveal delay={0.1} className="lg:mt-10">
              <StoryCard work={s2} index="03" size="stack" />
            </Reveal>
          </div>
        </div>

        {/* ——— the spread — three supporting stories, the middle floating lower ——— */}
        <div className="mt-20 grid grid-cols-1 gap-x-12 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
          {spread.map((w, i) => (
            <Reveal key={w.id} delay={i * 0.07} className={i === 1 ? 'lg:mt-20' : ''}>
              <StoryCard work={w} index={`0${i + 4}`} size="spread" />
            </Reveal>
          ))}
        </div>

        {/* ——— the closing duo — wide crops, set lower like the back pages ——— */}
        <div className="mt-6 grid grid-cols-1 gap-x-12 gap-y-16 md:grid-cols-2">
          <Reveal className="md:mt-24">
            <StoryCard work={bottom[0]} index="07" size="bottom" />
          </Reveal>
          <Reveal delay={0.08}>
            <StoryCard work={bottom[1]} index="08" size="bottom" />
          </Reveal>
        </div>

        {/* ——— end of the issue ——— */}
        <Reveal className="mt-24">
          <div className="flex flex-col items-center gap-5">
            <span aria-hidden="true" className="font-mono text-[10px] uppercase tracking-[0.28em] text-white/50">End of the issue</span>
            <span aria-hidden="true" className="flex items-center gap-4">
              <span className="h-px w-24 bg-gold/40" />
              <span className="text-gold">✦</span>
              <span className="h-px w-24 bg-gold/40" />
            </span>
            <p className="pull-quote text-lg text-ivory/60">
              The archive continues — every feature, every creator, every page.
            </p>
            <UnderlineLink to="/articles">Browse the full archive</UnderlineLink>
          </div>
        </Reveal>
      </div>
    </section>
  )
}

/** The current feature — three plates in a staggered editorial composition. */
function FeatureSection({ feature, authorName }: { feature: (typeof ARTICLES)[number]; authorName: string }) {
  const plates = feature.slides ?? []
  return (
    <section className="border-t border-white/10 py-[clamp(8rem,16vh,12rem)]">
      <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
        <SectionHead eyebrow="The first feature" page="P. 02" ghost="02" />
        <div className="grid grid-cols-1 items-center gap-[clamp(3rem,7vw,8rem)] lg:grid-cols-[1.02fr_0.98fr]">
          <Reveal>
            <div className="grid grid-cols-3 items-start gap-3">
              {plates.map((src, i) => (
                <figure key={src} className={`img-frame overflow-hidden border border-white/10 ${i === 1 ? 'mt-12' : i === 2 ? 'mt-6' : ''}`}>
                  <img
                    src={src}
                    alt={`${feature.title} — plate ${i + 1} of ${plates.length}`}
                    loading="lazy"
                    className="aspect-[4/5] w-full object-cover transition-transform duration-[1400ms] ease-out hover:scale-[1.07]"
                  />
                  <figcaption className="border-t border-white/10 px-2 py-2 font-mono text-[8px] uppercase tracking-[0.26em] text-white/50">
                    {String(i + 1).padStart(2, '0')} / {plates.length}
                  </figcaption>
                </figure>
              ))}
            </div>
            <p className="mt-5 font-mono text-[10px] uppercase tracking-[0.28em] text-white/50">
              The feature as presented — three plates, 4:5
            </p>
          </Reveal>

          <div>
            <Reveal>
              <p className="kicker">Feature — presented by Verlyse Media</p>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-6 font-serif text-[clamp(2.9rem,6.2vw,5.6rem)] font-light leading-[1.02] tracking-[-0.02em]">
                “{feature.title}”
              </h2>
            </Reveal>
            <Reveal delay={0.14} className="mt-6">
              <MetaRow category={feature.category} author={authorName} readingTime={feature.readingTime} />
            </Reveal>
            <Reveal delay={0.2}>
              <p className="mt-7 max-w-[54ch] leading-[1.85] text-white/70">{feature.excerpt}</p>
            </Reveal>
            <Reveal delay={0.26}>
              <p className="mt-5 font-serif text-lg font-light italic text-ivory/85">
                By {authorName} — {getAuthor(feature.authorId)?.handle}
              </p>
            </Reveal>
            <Reveal delay={0.32} className="mt-9">
              <UnderlineLink to={`/article/${feature.id}`}>Read the full feature</UnderlineLink>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  )
}

/** The community ledger. */
/** The community ledger — the magazine's own numbers, set like marginalia. */
function Pulse() {
  return (
    <section className="border-t border-white/10 bg-wine-deep py-[clamp(6rem,14vh,11rem)]">
      <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6 border-b border-white/10 pb-10">
            <p className="kicker mb-5">Community pulse</p>
            <p className="max-w-[36ch] text-right font-serif text-base font-light italic leading-[1.7] text-white/60">
              The room is young, and it grows one voice at a time.
            </p>
          </div>
        </Reveal>
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-[1.15fr_0.85fr] lg:gap-20">
          <Reveal className="border-t border-white/15 pt-10">
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">Features presented</p>
            <p className="mt-4 font-serif text-[clamp(6rem,13vw,11rem)] font-light leading-[0.9] tracking-[-0.02em] text-ivory">18</p>
            <p className="mt-6 max-w-[34ch] text-base leading-[1.8] text-white/65">
              Every post on the feed — from the founder’s call for women’s rights to the Kashmir cover.
            </p>
          </Reveal>
          <div className="border-t border-white/15">
            {[
              ['1281', 'Appreciations', 'Likes across the feed — each of them an answer to a writer.'],
              ['576', 'Conversations', 'Comments beneath the features, all of them read.'],
              ['14', 'Creators credited', 'Every feature names its writer, by name and handle.'],
            ].map(([v, l, n], i) => (
              <Reveal key={l} delay={0.1 + i * 0.08}>
                <div className="flex items-baseline justify-between gap-6 border-b border-white/10 py-7">
                  <CountUp value={parseInt(v, 10)} className="font-serif text-3xl font-light text-ivory md:text-4xl" />
                  <span className="text-right">
                    <span className="block font-mono text-[10px] uppercase tracking-[0.28em] text-white/50">{l}</span>
                    <span className="mt-2 block max-w-[30ch] text-sm leading-relaxed text-white/60">{n}</span>
                  </span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/** Departments — an index of rooms. */
/** Departments — the rooms, set like an open house: each one a possibility. */
function Departments() {
  return (
    <section className="border-t border-white/10 py-[clamp(8rem,16vh,12rem)]">
      <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6 border-b border-white/10 pb-10">
            <div>
              <p className="kicker mb-5">Departments — the rooms</p>
              <h2 className="max-w-[18ch] font-serif text-[clamp(2.4rem,4.8vw,4.2rem)] font-light leading-[1.02] text-ivory">
                Seven rooms, <em className="italic text-gold">all of them open</em>
              </h2>
            </div>
            <p className="max-w-[32ch] text-right font-serif text-base font-light italic leading-[1.7] text-white/60">
              Each one was opened by a writer who sent their work in. Yours could open the next.
            </p>
          </div>
        </Reveal>

        <div className="mt-14 border-t border-white/10">
          {CATEGORIES.map((c, i) => (
            <Reveal key={c.slug} delay={Math.min(i * 0.05, 0.25)}>
              <div className="group grid grid-cols-1 items-center gap-3 border-b border-white/10 py-8 transition-all duration-700 hover:bg-white/[0.04] md:grid-cols-[4rem_1fr_auto] md:px-5 md:py-10">
                <span className="font-mono text-xs tracking-[0.2em] text-gold">{String(i + 1).padStart(2, '0')}</span>
                <div>
                  <h3 className="font-serif text-[clamp(2rem,3.8vw,3.4rem)] font-normal leading-[1.04] text-ivory transition-all duration-700 group-hover:translate-x-3 group-hover:italic">
                    {c.name}
                  </h3>
                  <p className="mt-2 max-w-[52ch] text-sm leading-relaxed text-white/60">{c.blurb}</p>
                </div>
                <p className="text-left font-mono text-[10px] uppercase tracking-[0.28em] text-white/60 md:text-right">
                  {c.count} feature{c.count === 1 ? '' : 's'}
                </p>
              </div>
            </Reveal>
          ))}
          <Reveal delay={0.18}>
            <Link to="/categories" className="group grid grid-cols-1 items-center gap-3 border-b border-white/10 py-8 transition-all duration-700 hover:bg-white/[0.04] md:grid-cols-[4rem_1fr_auto] md:px-5 md:py-10">
              <span className="font-mono text-xs tracking-[0.2em] text-gold">08</span>
              <div>
                <h3 className="font-serif text-[clamp(2rem,3.8vw,3.4rem)] font-normal italic leading-[1.04] text-white/60 transition-all duration-700 group-hover:translate-x-3 group-hover:text-ivory">
                  Your department
                </h3>
                <p className="mt-2 max-w-[52ch] text-sm leading-relaxed text-white/60">
                  Every room on this page was opened — or will be opened — by a writer who sent their work in. Yours could open the next one.
                </p>
              </div>
              <p className="text-left font-mono text-[10px] uppercase tracking-[0.28em] text-white/60 md:text-right">
                See the rooms <span aria-hidden="true">→</span>
              </p>
            </Link>
          </Reveal>
        </div>
      </div>
    </section>
  )
}

function Invitation() {
  return (
    <section className="border-t border-white/10 py-[clamp(8rem,16vh,12rem)]">
      <div className="mx-auto grid max-w-page grid-cols-1 items-center gap-[clamp(3rem,7vw,8rem)] px-[clamp(1.75rem,5.5vw,4.75rem)] lg:grid-cols-[0.9fr_1.1fr]">
        <Reveal className="relative">
          <figure className="img-frame aspect-[4/5] max-w-[88%] overflow-hidden">
            <img
              src="/img/poster-3-13-3.webp"
              alt="Plate III — “3:13” by Anshujit Singh"
              loading="lazy"
              className="h-full w-full object-cover"
            />
          </figure>
          <figcaption className="mt-4 font-mono text-[10px] uppercase tracking-[0.28em] text-white/55">
            Plate III — “3:13” · the call is always you
          </figcaption>
          <div aria-hidden="true" className="absolute -bottom-7 -left-7 -right-7 top-7 border border-gold/50" />
        </Reveal>

        <div>
          <Reveal>
            <p className="kicker">Submissions — open</p>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="mt-6 max-w-[16ch] font-serif text-[clamp(2.6rem,5.4vw,4.6rem)] font-light leading-[1.04] tracking-[-0.02em] text-ivory">
              Have something worth sharing?
            </h2>
          </Reveal>
          <Reveal delay={0.18}>
            <p className="mt-7 max-w-[54ch] leading-[1.85] text-white/70">
              Every feature on Verlyse Media begins the same way: someone sends a story in. If you have written one — a story, a poem, an essay — we would like to read it. That is the whole of the magazine, and the beginning of the next feature.
            </p>
          </Reveal>
          <Reveal delay={0.24}>
            <p className="mt-5 max-w-[54ch] text-sm leading-[1.85] text-white/55">{BRAND.disclosure}</p>
          </Reveal>
          <Reveal delay={0.3} className="mt-10 flex flex-wrap items-center gap-8">
            <Link to="/submit" className="btn btn-gold">Send your work</Link>
            <span className="font-serif text-lg font-light italic text-ivory/70">— The Desk, Verlyse Media</span>
            <HiddenQuote quote="Every feature begins as a kept page — including the next one." />
          </Reveal>
          <ReflectionLine className="mt-20 max-w-[40ch]">
            <p className="font-serif text-[clamp(1.4rem,2.4vw,2rem)] font-light italic leading-[1.6] text-ivory/70">
              Every story in this magazine began as a kept page. The next one is still in someone's hands — and it might be in yours.
            </p>
          </ReflectionLine>
        </div>
      </div>
    </section>
  )
}

/** The colophon teaser. */
function Colophon() {
  return (
    <section className="border-t border-white/10 bg-charcoal py-[clamp(6rem,14vh,11rem)]">
      <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
        <div className="grid grid-cols-1 items-center gap-[clamp(3rem,7vw,8rem)] lg:grid-cols-[1fr_1fr]">
          <div>
            <Reveal><p className="kicker">About Verlyse Media</p></Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-6 font-serif text-[clamp(2.6rem,5.4vw,4.8rem)] font-light leading-[1.04] tracking-[-0.02em]">
                Where <em className="italic text-gold">vision</em> becomes a voice
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-7 max-w-[52ch] leading-[1.85] text-white/70">
                A platform for artists, writers and storytellers — where every meaningful creation gets an audience, a credit, and a room of its own. The feed opened on the twenty-sixth of June 2026 with the founder’s call for Afghan women’s rights, “Their Voices Matter” — and has presented eighteen features since.
              </p>
            </Reveal>
            <Reveal delay={0.24} className="mt-9">
              <UnderlineLink to="/about">Read the story</UnderlineLink>
            </Reveal>
          </div>
          <Reveal className="relative">
            <div className="img-frame aspect-[4/5] max-w-[92%]">
              <img src="/img/works/DaDY7WRkw0y-2.webp" alt="Plate II of the first feature, “Their Voices Matter”" className="h-full w-full object-cover" loading="lazy" />
            </div>
            <div aria-hidden="true" className="absolute -bottom-7 -left-7 -right-7 top-7 border border-gold/50" />
          </Reveal>
          <div className="mt-10 flex justify-end">
            <LibraryCard />
          </div>
        </div>
      </div>
    </section>
  )
}

export default function Home() {
  useSeo({
    title: 'Where Vision Becomes A Voice',
    description: 'Verlyse Media — a student-led platform sharing youth perspectives on culture, global issues and creativity.',
  })
  const feature = ARTICLES[0]
  const author = getAuthor(feature.authorId)!

  return (
    <>
      <Cover />
      <IssueBand />
      <WorksStrip />
      <MotifDivider label="The feature" motif="quote" />
      <FeatureSection feature={feature} authorName={author.name} />
      <MotifDivider label="The room" motif="voices" />
      <Pulse />
      <Departments />
      <VoiceCarousel />
      <MotifDivider label="The invitation" motif="feather" />
      <Invitation />
      <Colophon />
    </>
  )
}
