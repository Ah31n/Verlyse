import { Link } from 'react-router-dom'
import { useSeo } from '../hooks/useSeo'
import SplitText from '../components/ui/SplitText'
import Reveal from '../components/ui/Reveal'
import { PageRail } from '../components/ui/primitives'

import { CATEGORIES } from '../data/content'

/**
 * Departments — the rooms of the magazine, set as door-plates.
 * Each open room carries its number and the count of features inside it;
 * the eighth door is drawn unopened, waiting for the submission that opens it.
 */
export default function Categories() {
  useSeo({
path: '/categories',
    title: 'Categories',
    description: 'The departments of Verlyse Media — Horror and Stories now, with more opening as the archive grows.',
  })

  return (
    <>
      <section className="flex min-h-[58svh] items-end border-b border-white/10 bg-wine-deep pb-20 pt-36">
        <PageRail text="The rooms — seven open, one waiting" />
        <div className="mx-auto w-full max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <Reveal><p className="eyebrow">Departments</p></Reveal>
          <SplitText as="h1" text="The rooms" className="mt-6 text-[clamp(3.4rem,9.4vw,9rem)]" />
          <Reveal delay={0.2}>
            <p className="mt-6 max-w-[52ch] text-lg leading-[1.8] text-white/70">
              The rooms of the magazine. Seven are open; the eighth is drawn closed, waiting for the first submission that belongs to it.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-white/10 py-[clamp(6rem,14vh,11rem)]">
        <div className="mx-auto max-w-page px-[clamp(1.75rem,5.5vw,4.75rem)]">
          <div className="border-t border-white/10">
            {CATEGORIES.map((c, i) => (
              <Reveal key={c.slug} delay={Math.min(i * 0.06, 0.3)}>
                <Link to="/articles" className="group relative grid grid-cols-1 items-center gap-5 border-b border-white/10 py-10 no-underline transition-all duration-700 hover:bg-white/[0.04] md:grid-cols-[150px_1fr_auto] md:px-6 md:py-12">
                  {/* the door-frame — drawn on hover, like a door beginning to open */}
                  <span aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-px origin-left scale-x-0 bg-gold transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-x-100" />
                  <span aria-hidden="true" className="pointer-events-none absolute inset-x-6 bottom-0 h-px origin-right scale-x-0 bg-gold/50 transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-x-100" />

                  {/* the door-plate — room number over the count of features inside */}
                  <div className="flex items-center gap-5 md:block" aria-hidden="true">
                    <p className="font-mono text-[9px] uppercase tracking-[0.30em] text-gold">Room {String(i + 1).padStart(2, '0')}</p>
                    <p className="mt-2 font-serif text-[clamp(2.6rem,4.4vw,3.8rem)] font-semibold leading-none text-transparent transition-all duration-700 [-webkit-text-stroke:1px_rgba(184,145,70,0.22)] group-hover:[-webkit-text-stroke:1px_rgba(184,145,70,0.55)]">
                      {String(i + 1).padStart(2, '0')}
                    </p>
                    <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.30em] text-white/60">
                      {c.count} feature{c.count === 1 ? '' : 's'} within
                    </p>
                  </div>

                  <div>
                    <h2 className="font-serif text-[clamp(2rem,3.6vw,3.2rem)] font-normal leading-[1.05] text-ivory transition-all duration-700 group-hover:translate-x-3 group-hover:italic group-hover:text-[#E8D9A8]">
                      {c.name}
                    </h2>
                    <p className="mt-3 max-w-[52ch] text-sm leading-relaxed text-white/60">{c.blurb}</p>
                  </div>

                  <p className="hidden font-mono text-[10px] uppercase tracking-[0.28em] text-white/50 transition-colors duration-500 group-hover:text-gold md:block md:text-right">
                    Enter the room <span aria-hidden="true">→</span>
                  </p>
                </Link>
              </Reveal>
            ))}

            {/* Room 08 — drawn closed, waiting for the submission that opens it */}
            <Reveal delay={0.18}>
              <div className="group relative grid grid-cols-1 items-center gap-5 border-b border-dashed border-white/15 py-10 md:grid-cols-[150px_1fr_auto] md:px-6 md:py-12">
                <div className="flex items-center gap-5 md:block" aria-hidden="true">
                  <p className="font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">Room 08 — unopened</p>
                  <p className="mt-2 font-serif text-[clamp(2.6rem,4.4vw,3.8rem)] font-semibold leading-none text-transparent [-webkit-text-stroke:1px_rgba(248,246,242,0.16)]">
                    08
                  </p>
                  <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.30em] text-white/55">0 features within</p>
                </div>
                <div>
                  <h2 className="font-serif text-[clamp(2rem,3.6vw,3.2rem)] font-normal italic leading-[1.05] text-white/60 transition-all duration-700 group-hover:text-ivory">
                    Your department
                  </h2>
                  <p className="mt-3 max-w-[52ch] text-sm leading-relaxed text-white/60">
                    Every room on this page was opened — or will be opened — by a writer who sent their work in. The eighth door opens with the first submission that belongs to it.
                  </p>
                </div>
                <div className="md:text-right">
                  <Link to="/submit" className="btn btn-ghost">Send your work</Link>
                </div>
              </div>
            </Reveal>
          </div>

          <Reveal delay={0.1} className="mt-14 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-6 font-mono text-[9px] uppercase tracking-[0.30em] text-white/60">
            <span>Seven rooms open · one drawn closed · the next key is a submission</span>
            <span>All features, presented — № 01 to № 18</span>
          </Reveal>
        </div>
      </section>
    </>
  )
}
