import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    target: 'es2020',
    cssMinify: true,
    rollupOptions: {
      output: {
        // One single JS file instead of route-split chunks. The site is small
        // (~450 KB total) and free hosts like InfinityFree run HTTP/1.1 with
        // high per-request latency — one file loads far faster than 19 round-trips.
        inlineDynamicImports: true,
      },
    },
  },
})
