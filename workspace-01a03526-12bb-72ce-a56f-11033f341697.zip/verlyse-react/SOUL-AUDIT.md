# The Soul Audit — Verlyse Media

*"Never sacrifice authenticity for visual effects. Whenever there is a choice between being more impressive and being more meaningful, always choose meaning."*

This pass did not add a single feature. It did the only thing that matters at the end: **verified the soul against the truth**, and fixed the one place where the site had quietly drifted from it.

**Validation: 108 automated checks green · axe-core zero violations · zero production console warnings/errors.**

---

## The verification — every claim against the raw datasets

Every number, date, name and voice on the site was cross-checked against the Instagram datasets in `uploads/`:

| Claim on the site | The dataset says | Verdict |
|---|---|---|
| 18 features | 18 unique posts | ✓ exact |
| 1,281 appreciations | sum of all likes | ✓ exact |
| 576 conversations | sum of all comments | ✓ exact |
| Per-article likes (18 articles) | each post's count | ✓ all exact |
| Per-article comments (18 articles) | each post's count | ✓ all exact |
| Publication dates (18 articles) | each post's timestamp | ✓ all exact |
| "Their Voices Matter · 133 appreciations" (About) | post DaDY7WRkw0y | ✓ exact |
| 7 quoted voices on the letters page | verbatim comments in the posts | ✓ all seven real |
| 15 creators on the wall | handles credited in captions | ✓ census-complete |

Nothing invented. Nothing approximated. The one "miss" in the first pass was a straight-vs-curly apostrophe in my own search script — the comment was real.

## What the audit found — and fixed

**The poem's writer was unnamed.** "A Student's Worth" presents Adeena Irfan's painting — but the caption credits the poem beneath it to **@mochjixx**. The article page showed only the artist's byline while the reader read the poet's words. That is exactly the kind of drift the soul audit exists to catch.

- The article now carries a credit line, in the caption's own words: *"Poem written by @mochjixx — the painting by Adeena Irfan, presented together"* — with the handle linked to the poet's profile.
- The count followed the truth: the feed credits **fifteen** creators, not fourteen. The ledger, the cover, the community page, the About page, the wall and the footer all now say fifteen — matching the fifteen cards on the wall and the fifteen names in the captions.

## How the technology behaves

- The reading column is still. The words are the only motion.
- The worlds are drawn at 2–5% — texture under the text, never over it.
- The motifs move like their meanings: the clock turns for 3:13, the flame flickers for hope, the seal presses for the letter. Motion is meaning, or it is nothing.
- The finales happen only in the reader's hand, after the story has been read.
- Every writer signs their own feature. Every feature links to its creator. Every creator has a room.
- The only grain left in the house is in the photographs themselves.

When a visitor leaves, what they should remember is not the interface — it is the old man dancing alone in the ballroom, the call at 3:13 in the morning, the garden she prays stays lush, the student painting her worth, and the fifteen names behind them. The website is the frame. The stories are the picture.
